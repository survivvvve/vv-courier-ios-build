(() => {
  'use strict';
  if (window.__vvCompanion) return;
  const documentID = (self.crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
  let serial = 0;
  let disposed = false;
  const pending = new Map();
  const send = value => window.webkit.messageHandlers.vvNative.postMessage({ ...value, documentID });
  const disposeDiagnostics = window.__vvInstallDiagnostics?.({
    send,
    route: () => window.__vvFixtureRoute || location.pathname
  });
  const header = (name, promise, callback = []) => ({ name, methods: [
    ...promise.map(name => ({ name, rtype: 'promise' })),
    ...callback.map(name => ({ name, rtype: 'callback' }))
  ] });
  // Keep the original web platform. Only the two implemented hardware plugins
  // use native dispatch; the site's own storage, routing and maps remain intact.
  const cap = window.Capacitor || (window.Capacitor = {});
  const names = new Set(['Camera', 'BarcodeScanner']);
  cap.PluginHeaders = (cap.PluginHeaders || []).filter(item => !names.has(item.name)).concat([
    header('Camera', ['checkPermissions', 'requestPermissions', 'getPhoto']),
    header('BarcodeScanner', ['prepare', 'checkPermission', 'checkPermissions', 'requestPermissions', 'scan', 'startScan', 'stopScan', 'stopScanning', 'pauseScanning', 'resumeScanning', 'hideBackground', 'showBackground', 'isTorchAvailable', 'getTorchState', 'enableTorch', 'disableTorch', 'toggleTorch', 'removeAllListeners'], ['startScanning', 'addListener', 'removeListener'])
  ]);
  cap.nativePromise = (plugin, method, options = {}) => new Promise((resolve, reject) => {
    if (disposed) { reject(new Error('Страница закрыта.')); return; }
    const callbackID = `${documentID}:${++serial}`;
    pending.set(callbackID, { resolve, reject });
    send({ kind: 'plugin', callbackID, plugin, method, options: options || {} });
  });
  cap.nativeCallback = (plugin, method, options = {}, callback) => {
    if (disposed) throw new Error('Страница закрыта.');
    const callbackID = `${documentID}:${++serial}`;
    if (typeof callback === 'function') pending.set(callbackID, { callback });
    send({ kind: 'plugin', callbackID, plugin, method, options: options || {} });
    if (method === 'removeListener' && options.callbackId) pending.delete(options.callbackId);
    return callbackID;
  };
  window.__vvNativeReceive = message => {
    const entry = pending.get(message.callbackID);
    if (!entry) return;
    if (!message.keepAlive) pending.delete(message.callbackID);
    if (message.success) {
      if (entry.resolve) entry.resolve(message.data || {});
      else if (entry.callback) entry.callback(message.data || {});
    } else {
      const error = new Error(message.error || 'Не удалось выполнить действие на iPhone.');
      error.code = message.code || 'NATIVE_ERROR';
      if (entry.reject) entry.reject(error);
      else if (entry.callback) entry.callback(undefined, error);
    }
  };
  send({ kind: 'boot' });
  let wheelOpen = false;
  let lastState = '';
  const route = () => window.__vvFixtureRoute || location.pathname + location.search;
  const publish = () => {
    const bar = document.querySelector('ion-tab-bar');
    const path = route();
    const visible = !!bar && path.startsWith('/main/');
    const value = { path, barVisible: visible, barHeight: visible ? bar.getBoundingClientRect().height : 0 };
    const signature = JSON.stringify(value);
    if (signature !== lastState) { lastState = signature; send({ kind: 'navigation', ...value }); }
  };
  const wheelIcon = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="2.8"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/></svg>';
  const addButton = (parent, id, label, action) => {
    let button = document.getElementById(id);
    if (!button) {
      button = document.createElement('button'); button.id = id; button.type = 'button'; button.textContent = label;
      button.className = 'vv-companion-action';
      button.addEventListener('click', event => { event.preventDefault(); send({ kind: 'action', action }); });
    }
    if (button.parentElement !== parent) parent.prepend(button);
    return button;
  };
  const watchedPages = new WeakSet();
  let pageObserver;
  const installControls = () => {
    if (pageObserver) {
      document.querySelectorAll('ion-page,.ion-page').forEach(page => {
        if (!watchedPages.has(page)) {
          watchedPages.add(page);
          pageObserver.observe(page, { attributes:true, attributeFilter:['class','aria-hidden'] });
        }
      });
    }
    const bar = document.querySelector('ion-tab-bar');
    if (bar && !document.getElementById('vv-native-wheel')) {
      const button = document.createElement('button');
      button.type = 'button'; button.id = 'vv-native-wheel'; button.className = 'vv-native-wheel';
      button.setAttribute('aria-label', 'Колесо');
      button.innerHTML = `${wheelIcon}<span>Колесо</span>`;
      button.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); send({ kind: 'action', action: 'wheel' }); });
      bar.appendChild(button);
      bar.addEventListener('click', event => {
        if (!event.target.closest('#vv-native-wheel')) send({ kind: 'action', action: 'courier' });
      });
      new ResizeObserver(publish).observe(bar);
    }
    const path = route().split('?')[0];
    const page = Array.from(document.querySelectorAll('ion-content')).find(content =>
      !content.closest('.ion-page-hidden,.ion-page-invisible,[aria-hidden="true"]') && content.getClientRects().length > 0);
    // Put the additions at the top of Profile and Income so the report does
    // not disappear beneath the original receipt list or wheel settings.
    if (path === '/main/profile-tab' && page) {
      let tools = document.getElementById('vv-native-profile-tools');
      if (!tools) { tools = document.createElement('div'); tools.id = 'vv-native-profile-tools'; tools.className = 'vv-companion-tools'; }
      if (tools.parentElement !== page) page.prepend(tools);
      addButton(tools, 'vv-native-profile-income', 'Итоги смены', 'income');
    } else document.getElementById('vv-native-profile-tools')?.remove();
    if (['/income-details', '/income'].includes(path) && page) {
      addButton(page, 'vv-native-income', 'Итоги смены', 'income');
    } else document.getElementById('vv-native-income')?.remove();
    if (bar) {
      bar.classList.toggle('vv-wheel-open', wheelOpen);
      document.getElementById('vv-native-wheel')?.setAttribute('aria-current', wheelOpen ? 'page' : 'false');
    }
    publish();
  };
  let frame = 0;
  const schedule = () => { if (!frame) frame = requestAnimationFrame(() => { frame = 0; installControls(); }); };
  window.__vvCompanion = {
    setWheel(open) { wheelOpen = !!open; installControls(); },
    navigate(path) {
      wheelOpen = false;
      if (window.__vvFixtureNavigate) { window.__vvFixtureNavigate(path); installControls(); return; }
      const tabName = path.startsWith('/main/') ? path.split('/')[2] : '';
      const tab = Array.from(document.querySelectorAll('ion-tab-button')).find(item => item.getAttribute('tab') === tabName || item.getAttribute('href') === path);
      if (tab) tab.click();
      else { history.pushState({}, '', path); dispatchEvent(new PopStateEvent('popstate', { state: history.state })); }
      schedule();
    },
    dispose() { disposed = true; disposeDiagnostics?.(); for (const item of pending.values()) item.reject?.(new Error('Страница закрыта.')); pending.clear(); }
  };
  const storedToken = () => localStorage.getItem('CapacitorStorage.token_courier');
  let observedToken;
  const syncToken = () => {
    const token = storedToken();
    if (token !== observedToken) { observedToken = token; send({ kind: 'token', token: token || '' }); }
  };
  const originalSet = Storage.prototype.setItem;
  const originalRemove = Storage.prototype.removeItem;
  const originalClear = Storage.prototype.clear;
  Storage.prototype.setItem = function(key, value) { originalSet.call(this, key, value); if (this === localStorage && key === 'CapacitorStorage.token_courier') queueMicrotask(syncToken); };
  Storage.prototype.removeItem = function(key) { originalRemove.call(this, key); if (this === localStorage && key === 'CapacitorStorage.token_courier') queueMicrotask(syncToken); };
  Storage.prototype.clear = function() { originalClear.call(this); if (this === localStorage) queueMicrotask(syncToken); };
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const requestToken = storedToken();
    const response = await originalFetch.apply(this, args);
    try {
      const input = args[0], url = new URL(typeof input === 'string' ? input : input.url, location.href);
      if (url.hostname === 'mobile-courier.vkusvill.ru' && /\/couriers\/auth\/?$/.test(url.pathname) && response.ok) {
        response.clone().json().then(data => {
          if (data.token && data.id !== undefined) send({ kind: 'session', token: data.token, courierID: String(data.id) });
        }).catch(() => {});
      } else if (url.hostname === 'delivery-api.vkusvill.ru' && ['/v1/courier/activity', '/v1/courier/courier', '/v1/courier/shops'].includes(url.pathname) && response.ok) {
        response.clone().json().then(data => send({ kind: 'account', endpoint: url.pathname, token: requestToken, data })).catch(() => {});
      }
    } catch (_) { /* Observing a response must never change the site's result. */ }
    return response;
  };
  const setup = () => {
    const style = document.createElement('style'); style.id = 'vv-companion-style';
    style.textContent = `
      ion-tab-bar { overflow:visible!important; }
      ion-tab-bar > ion-tab-button { flex:1 1 0!important; min-width:0!important; max-width:none!important; --padding-start:0; --padding-end:0; }
      ion-tab-bar .toolbar-item { min-width:0!important; }
      ion-tab-bar .toolbar-content { min-width:0!important; width:100%; max-width:100%; padding-left:2px!important; padding-right:2px!important; font-size:clamp(10px,2.75vw,12px)!important; }
      ion-tab-bar .toolbar-label { max-width:100%!important; font-size:clamp(10px,2.75vw,12px)!important; }
      .vv-native-wheel { appearance:none; border:0; margin:4px 0; padding:4px 1px; border-radius:4px; background:transparent; color:var(--ion-color-medium,#999); flex:1 1 0; min-width:0; font:500 clamp(10px,2.75vw,12px) -apple-system,BlinkMacSystemFont,sans-serif; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:3px; align-self:stretch; }
      .vv-wheel-open .vv-native-wheel { color:white; background:#179c49; }
      .vv-wheel-open ion-tab-button { --color-selected:var(--ion-color-medium,#999); }
      .vv-wheel-open ion-tab-button.tab-selected .toolbar-content { background:transparent!important; color:var(--ion-color-medium,#999)!important; }
      .vv-wheel-open ion-tab-button.tab-selected svg [fill]:not([fill="none"]) { fill:currentColor!important; }
      .vv-wheel-open ion-tab-button.tab-selected svg [stroke]:not([stroke="none"]) { stroke:currentColor!important; }
      .vv-companion-action { display:block; width:calc(100% - 32px); margin:14px 16px; padding:12px; border:1px solid #179c49; border-radius:8px; color:#179c49; background:transparent; font:500 16px -apple-system,BlinkMacSystemFont,sans-serif; }
      .vv-companion-tools { margin:12px 16px; border:1px solid #179c49; border-radius:10px; overflow:hidden; }
      .vv-companion-tools .vv-companion-action { width:100%; margin:0; border:0; border-radius:0; padding:14px; text-align:left; }
      .vv-companion-tools .vv-companion-action + .vv-companion-action { border-top:1px solid #179c4940; }
    `;
    document.head.appendChild(style);
    pageObserver = new MutationObserver(schedule);
    new MutationObserver(records => {
      // Map tiles and marker DOM change continuously. They do not require
      // rescanning the page or measuring the hotbar on every animation frame.
      const relevant = records.some(record =>
        (record.target instanceof Element && record.target.closest('ion-tab-bar')) ||
        Array.from(record.addedNodes).some(node => node instanceof Element &&
          (node.matches('ion-tab-bar,ion-content,.ion-page') || node.querySelector('ion-tab-bar'))) ||
        Array.from(record.removedNodes).some(node => node instanceof Element &&
          ['vv-native-income','vv-native-profile-tools','vv-native-wheel'].includes(node.id))
      );
      if (relevant) schedule();
    }).observe(document.body, { childList:true, subtree:true });
    addEventListener('pagehide', () => window.__vvCompanion.dispose(), { once:true });
    addEventListener('pageshow', event => { if (event.persisted) location.reload(); });
    addEventListener('popstate', schedule); addEventListener('hashchange', schedule);
    for (const method of ['pushState','replaceState']) {
      const original = history[method]; history[method] = function(...args) { const result = original.apply(this,args); schedule(); return result; };
    }
    syncToken(); installControls(); send({ kind: 'ready' });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setup, { once:true }); else setup();
})();
