// Injected only by the explicit offline WK integration test. Every fetch is
// intercepted; this fixture cannot contact VV or start a shift.
(() => {
  'use strict';
  const token = 'offline-fixture-token';
  let release;
  window.__vvShiftFixture = {
    mode: 'slow',
    release() { release?.(); },
    load() {
      return fetch('https://delivery-api.vkusvill.ru/v1/courier/tasks', {
        method: 'POST', headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },
        body: JSON.stringify({ courier_id: 'demo' })
      }).then(response => response.json());
    }
  };
  window.fetch = async (input, options) => {
    const url = new URL(typeof input === 'string' ? input : input.url);
    if (url.href !== 'https://delivery-api.vkusvill.ru/v1/courier/tasks' || options?.method !== 'POST') {
      throw new Error('Unexpected request in the offline fixture');
    }
    if (window.__vvShiftFixture.mode === 'failed') {
      return new Response(JSON.stringify({ message: 'Offline rate limit' }), { status: 429, headers: { 'Content-Type': 'application/json' } });
    }
    const stream = new ReadableStream({ start(controller) {
      release = () => { controller.enqueue(new TextEncoder().encode(JSON.stringify([[{ id_task: 302 }]]))); controller.close(); release = undefined; };
    } });
    return new Response(stream, { status: 200, headers: { 'Content-Type': 'application/json' } });
  };
  localStorage.setItem('CapacitorStorage.token_courier', token);
})();
