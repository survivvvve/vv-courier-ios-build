(() => {
  'use strict';
  if (typeof window.__vvInstallDiagnostics === 'function') return;

  // Only sanitized, bounded code metadata crosses the native bridge. Never
  // serialize errors, console arguments, page text, network data or storage.
  const properties = new Set([
    'length', 'map', 'forEach', 'concat', 'filter', 'parcels', 'orders',
    'suborders', 'filterParams', 'renderData', 'shopsData', 'coordinates',
    'latitude', 'longitude', 'checking', 'route', 'checkingOption',
    'parcel_status', 'id_parcel', 'properties_v2', 'current', 'props', 'state', 'children',
    'task_statuses', 'new_statuses', 'pay_way'
  ]);
  const routes = new Set([
    '/start', '/start/auth', '/start/auth/code', '/main/my-tab',
    '/main/done-tab', '/main/prepare-tab', '/main/queue-tab',
    '/main/profile-tab', '/order', '/sub-orders', '/income',
    '/income-details', '/scan', '/scanner', '/packages',
    '/check-packages', '/photo-control'
  ]);
  const genericNames = {
    Error: 'error', TypeError: 'type_error', RangeError: 'range_error',
    ReferenceError: 'reference_error', SyntaxError: 'syntax_error',
    DOMException: 'dom_error', NotFoundError: 'dom_not_found'
  };
  const versionPattern = /^[0-9]{1,4}(\.[0-9]{1,4}){1,3}$/;
  const safeProperty = value => properties.has(value) ? value : undefined;
  const safePath = value => {
    if (typeof value !== 'string') return '/<other>';
    const path = value.slice(0, 1024).split(/[?#]/, 1)[0];
    if (routes.has(path)) return path;
    if (/^\/main\/queue-tab\/cluster\/[0-9]+$/.test(path)) return '/main/queue-tab/cluster/:id';
    return '/<other>';
  };
  const safeFile = value => typeof value === 'string'
    && /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,119}\.(?:m?js)$/.test(value)
    && !/(authorization|cookie|bearer|token|secret|password|phone|address)/i.test(value)
    && !/[0-9]{6}/.test(value);

  const framesFrom = stack => {
    if (typeof stack !== 'string') return [];
    const frames = [], seen = new Set();
    for (const line of stack.slice(0, 16384).split('\n').slice(0, 24)) {
      // Ignore inline page URLs, third-party hosts and arbitrary text that
      // happens to look like a filename. Query values are never retained.
      const match = line.match(/(https:\/\/courier\.vkusvill\.ru\/assets\/[^\s()]+):([0-9]{1,8}):([0-9]{1,8})\)?\s*$/);
      if (!match) continue;
      const path = match[1].split(/[?#]/, 1)[0];
      const file = path.slice(path.lastIndexOf('/') + 1);
      const row = Number(match[2]), column = Number(match[3]);
      if (!safeFile(file) || row < 1 || row > 10000000 || column < 1 || column > 10000000) continue;
      const key = `${file}:${row}:${column}`;
      if (seen.has(key)) continue;
      seen.add(key); frames.push({ file, line: row, column });
      if (frames.length === 6) break;
    }
    return frames;
  };

  const classify = (message, name) => {
    let text = typeof message === 'string' ? message.slice(0, 4096) : '';
    const prefix = text.match(/^(?:Uncaught\s+)?(TypeError|RangeError|NotFoundError):\s*/);
    if (prefix) { name = prefix[1]; text = text.slice(prefix[0].length); }
    let match = text.match(/^Cannot read properties of (undefined|null) \(reading ['"]([A-Za-z_$][A-Za-z0-9_$]{0,63})['"]\)$/);
    if (match) return { category: `type_${match[1]}_property`, property: safeProperty(match[2]) };
    match = text.match(/^Cannot read property ['"]([A-Za-z_$][A-Za-z0-9_$]{0,63})['"] of (undefined|null)$/);
    if (match) return { category: `type_${match[2]}_property`, property: safeProperty(match[1]) };
    match = text.match(/^(undefined|null) is not an object \(evaluating ['"]((?:[A-Za-z_$][A-Za-z0-9_$]*\.)*[A-Za-z_$][A-Za-z0-9_$]*)['"]\)$/);
    if (match) return { category: `type_${match[1]}_property`, property: safeProperty(match[2].split('.').pop()) };
    match = text.match(/^(?:[A-Za-z_$][A-Za-z0-9_$]*\.)+(map|forEach|concat|filter) is not a function\.?$/);
    if (match) return { category: `type_not_function_${match[1]}`, property: match[1] };
    match = text.match(/^Failed to execute ['"](insertBefore|removeChild)['"] on ['"]Node['"]:/);
    if (match) return { category: match[1] === 'insertBefore' ? 'dom_insert_before' : 'dom_remove_child' };
    if (name === 'RangeError' && /^Invalid time value\.?$/.test(text)) return { category: 'range_invalid_time' };
    return { category: genericNames[name] || (name === 'PromiseRejection' ? 'promise_rejection' : 'error') };
  };

  const detailsFrom = (value, fallbackName) => {
    try {
      if (typeof value === 'string') return { ...classify(value, fallbackName || 'Error'), frames: framesFrom(value) };
      if (value && typeof value === 'object') {
        // Do not enumerate or stringify an object: it may be a response or a
        // customer record. Read only primitive code-error fields, defensively.
        const rawName = value.name;
        const name = typeof rawName === 'string' && Object.prototype.hasOwnProperty.call(genericNames, rawName) ? rawName : fallbackName || 'Error';
        const message = typeof value.message === 'string' ? value.message : '';
        const stack = typeof value.stack === 'string' ? value.stack : '';
        return { ...classify(message, name), frames: framesFrom(stack) };
      }
    } catch (_) { /* A hostile getter must not affect the courier website. */ }
    return { category: fallbackName === 'PromiseRejection' ? 'promise_rejection' : 'error', frames: [] };
  };

  let activeDisposer;
  window.__vvInstallDiagnostics = options => {
    if (!options || typeof options.send !== 'function') return () => {};
    if (activeDisposer) activeDisposer();
    const transport = options.send;
    const route = typeof options.route === 'function' ? options.route : () => location.pathname;
    const version = typeof options.version === 'string' && versionPattern.test(options.version) ? options.version : undefined;
    const queue = [], seen = new Map();
    let disposed = false, scheduled = false, normalCount = 0, fatalCount = 0;
    let observer, frame = 0, screenReported = false;
    let latestCause, latestCausePriority = -1;

    const rememberCause = details => {
      // Retain a tiny sanitized record, never the Error or console arguments.
      // Subsequent generic logging must not overwrite a useful typed failure.
      const cause = { category: details.category, frames: [] };
      if (safeProperty(details.property)) cause.property = details.property;
      if (Array.isArray(details.frames)) {
        cause.frames = details.frames.slice(0, 6).map(item => ({
          file: item.file, line: item.line, column: item.column
        }));
      }
      const generic = ['error', 'type_error', 'range_error', 'reference_error',
        'syntax_error', 'dom_error', 'promise_rejection'].includes(cause.category);
      const priority = (generic ? 0 : 2) + (cause.frames.length ? 1 : 0);
      if (priority >= latestCausePriority) {
        latestCause = cause; latestCausePriority = priority;
      }
    };

    const flush = () => {
      scheduled = false;
      if (disposed) { queue.length = 0; return; }
      while (queue.length) {
        const event = queue.shift();
        try { transport(event); } catch (_) { /* No retry or thrown bridge error. */ }
      }
    };
    const emit = (details, fatal = false) => {
      if (disposed) return;
      // Ordinary quota/dedup applies to transport, not to this in-memory cause.
      // A later real render failure can therefore accompany the fatal screen.
      if (!fatal) rememberCause(details);
      if (fatal ? fatalCount >= 2 : normalCount >= 20) return;
      let path = '/<other>';
      try { path = safePath(route()); } catch (_) { }
      const event = { kind: 'diagnostic', category: details.category, fatal, path };
      if (details.property) event.property = details.property;
      if (details.frames && details.frames.length) event.frames = details.frames.slice(0, 6);
      if (version) event.version = version;
      const key = JSON.stringify(event);
      if (seen.has(key)) return;
      if (seen.size === 64) seen.delete(seen.keys().next().value);
      seen.set(key, true);
      if (fatal) fatalCount++; else normalCount++;
      if (queue.length === 8) {
        const ordinary = queue.findIndex(item => !item.fatal);
        queue.splice(ordinary === -1 ? 0 : ordinary, 1);
      }
      queue.push(event);
      if (!scheduled) { scheduled = true; Promise.resolve().then(flush); }
    };
    const onError = event => {
      try {
        const details = detailsFrom(event.error || event.message, 'Error');
        if (!details.frames.length && typeof event.filename === 'string') {
          details.frames = framesFrom(`${event.filename}:${event.lineno}:${event.colno}`);
        }
        emit(details);
      } catch (_) { }
    };
    const onRejection = event => {
      try { emit(detailsFrom(event.reason, 'PromiseRejection')); } catch (_) { }
    };
    addEventListener('error', onError);
    addEventListener('unhandledrejection', onRejection);

    const originalConsoleError = console.error;
    const consoleError = function(...args) {
      try { return originalConsoleError.apply(this, args); }
      finally {
        try {
          const values = args.slice(0, 8).map(value => detailsFrom(value, 'Error'));
          const specific = values.find(value => !['error', 'type_error', 'range_error', 'reference_error', 'syntax_error', 'dom_error'].includes(value.category));
          const chosen = specific || values.find(value => value.frames.length) || values[0] || detailsFrom(null);
          if (!chosen.frames.length) chosen.frames = values.flatMap(value => value.frames).slice(0, 6);
          emit(chosen);
        } catch (_) { }
      }
    };
    console.error = consoleError;

    const title = 'Что-то пошло не так...';
    const explanation = 'Пожалуйста, попробуйте перезагрузить приложение';
    const expected = (title + explanation + 'Рестарт').replace(/\s/g, '');
    const checkScreen = () => {
      frame = 0;
      if (disposed || screenReported || !document.body) return;
      try {
        const buttons = document.querySelectorAll('button,ion-button,[role="button"]');
        for (let i = 0; i < Math.min(buttons.length, 100); i++) {
          const button = buttons[i];
          if ((button.textContent || '').trim() !== 'Рестарт') continue;
          if (typeof button.getClientRects === 'function' && button.getClientRects().length === 0) continue;
          let node = button;
          for (let depth = 0; node && depth < 5; depth++, node = node.parentElement) {
            const text = node.textContent;
            if (typeof text !== 'string' || text.length > 512) break;
            if (text.replace(/\s/g, '') === expected) {
              screenReported = true;
              if (latestCause) emit(latestCause, true);
              emit({ category: 'react_error_screen', frames: [] }, true);
              return;
            }
          }
        }
      } catch (_) { }
    };
    const scheduleScreen = () => {
      if (!frame && !disposed && !screenReported) frame = requestAnimationFrame(checkScreen);
    };
    const relevantNode = node => {
      try {
        const text = node && node.textContent;
        return typeof text === 'string' && text.length <= 512
          && (text.includes(title) || text.includes('Рестарт'));
      } catch (_) { return false; }
    };
    const startDOM = () => {
      if (disposed || !document.body || observer) return;
      observer = new MutationObserver(records => {
        // Inspect only the newly changed nodes. Do not scan the page for map
        // mutations, and do not miss a fatal node at the end of a large batch.
        for (const record of records) {
          if (record.type === 'characterData' && relevantNode(record.target)) { scheduleScreen(); return; }
          const nodes = record.addedNodes || [];
          for (let i = 0; i < nodes.length; i++) {
            if (relevantNode(nodes[i])) { scheduleScreen(); return; }
          }
        }
      });
      observer.observe(document.body, { childList: true, characterData: true, subtree: true });
      checkScreen();
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startDOM, { once: true });
    else startDOM();

    const dispose = () => {
      if (disposed) return;
      disposed = true; queue.length = 0; seen.clear();
      latestCause = undefined; latestCausePriority = -1;
      removeEventListener('error', onError);
      removeEventListener('unhandledrejection', onRejection);
      document.removeEventListener('DOMContentLoaded', startDOM);
      if (observer) observer.disconnect();
      if (frame) cancelAnimationFrame(frame);
      if (console.error === consoleError) console.error = originalConsoleError;
      if (activeDisposer === dispose) activeDisposer = undefined;
    };
    activeDisposer = dispose;
    return dispose;
  };
})();
