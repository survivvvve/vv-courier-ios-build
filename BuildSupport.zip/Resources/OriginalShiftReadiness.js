(() => {
  'use strict';
  // Observe the website's own task load. Never fetch, replay a click, change
  // Redux, or replace the site's disabled/loading state.
  window.__vvInstallShiftReadiness = ({ send, getToken, route }) => {
    let disposed = false;
    let sequence = 0;
    let account;
    let phase = 'waiting';
    let httpStatus;
    let readyTimer;
    let notice;
    let noticeAt = -Infinity;

    const readAccount = () => {
      try {
        const value = getToken();
        return typeof value === 'string' && value.length ? value : null;
      } catch (_) { return undefined; }
    };
    const cancelReady = () => {
      if (readyTimer !== undefined) clearTimeout(readyTimer);
      readyTimer = undefined;
    };
    const accountChanged = () => {
      const current = readAccount();
      if (current !== account) {
        account = current;
        sequence++;
        cancelReady();
        phase = 'waiting';
        httpStatus = undefined;
      }
      return current;
    };
    account = readAccount();
    const current = ticket => !disposed && !!ticket &&
      accountChanged() === ticket.account && !!ticket.account && ticket.sequence === sequence;
    const fail = (ticket, status) => {
      if (!current(ticket)) return;
      cancelReady();
      phase = 'failed';
      httpStatus = status;
    };
    const statusOf = value => Number.isInteger(value) && value >= 100 && value <= 599 ? value : undefined;
    const isCanonical = data => {
      if (!Array.isArray(data) || data.error || data.business_error || data.message) return false;
      if (!data.length) return true;
      const tasks = data[0];
      if (!Array.isArray(tasks)) return false;
      return tasks.every(task => {
        if (!task || typeof task !== 'object' || Array.isArray(task)) return false;
        const id = task.id_task;
        return (typeof id === 'number' || (typeof id === 'string' && /^\d+$/.test(id))) &&
          Number.isSafeInteger(Number(id)) && Number(id) >= 0;
      });
    };
    const begin = (input, init) => {
      try {
        if (disposed) return;
        const source = typeof input === 'string' ? input :
          typeof input?.url === 'string' ? input.url : input?.href;
        const url = new URL(source, location.href);
        const method = init?.method ?? (typeof input?.method === 'string' ? input.method : 'GET');
        if (String(method).toUpperCase() !== 'POST' ||
            url.origin !== 'https://delivery-api.vkusvill.ru' ||
            url.pathname !== '/v1/courier/tasks' || url.search || url.username || url.password) return;
        accountChanged();
        sequence++;
        cancelReady();
        phase = 'loading';
        httpStatus = undefined;
        return { account, sequence };
      } catch (_) { /* An observer cannot change fetch behavior. */ }
    };
    const response = (ticket, value) => {
      try {
        if (!current(ticket)) return;
        const status = statusOf(value.status);
        // The site's mxe parser only fulfills JSON task responses for 200–203.
        // In particular 204 yields undefined, and other 2xx codes reject.
        if (status === undefined || status < 200 || status > 203) {
          fail(ticket, status);
          return;
        }
        const json = value.json;
        if (typeof json !== 'function') { fail(ticket, status); return; }
        // Observe the SDK's actual parser, not a clone racing the SDK. Return
        // its exact Promise and preserve synchronous throws and rejections.
        const observedJSON = function(...args) {
          let result;
          try { result = json.apply(this, args); }
          catch (error) { try { fail(ticket, status); } catch (_) {} throw error; }
          try {
            result.then(data => {
              try {
                if (!current(ticket)) return;
                if (!isCanonical(data)) { fail(ticket, status); return; }
                cancelReady();
                // In the audited 6.16.1/6.16.2 SDK, mxe -> pxe -> TA's maps,
                // setActiveChecks and RTK fulfilled finish in microtasks.
                readyTimer = setTimeout(() => {
                  readyTimer = undefined;
                  try {
                    if (current(ticket)) { phase = 'ready'; httpStatus = undefined; }
                  } catch (_) { /* Keep the original page result intact. */ }
                }, 0);
              } catch (_) { try { fail(ticket, status); } catch (_) {} }
            }, () => { try { fail(ticket, status); } catch (_) {} });
          } catch (_) { try { fail(ticket, status); } catch (_) {} }
          return result;
        };
        Object.defineProperty(value, 'json', { configurable:true, writable:true, value:observedJSON });
      } catch (_) { try { fail(ticket); } catch (_) {} }
    };
    const rejected = ticket => { try { fail(ticket, 0); } catch (_) {} };
    const onClick = event => {
      try {
        if (disposed) return;
        const path = String(route()).split('?')[0];
        if (path !== '/main' && !path.startsWith('/main/')) return;
        const nodes = typeof event.composedPath === 'function' ? event.composedPath() : [];
        let button = nodes.find(node => node instanceof Element && node.localName === 'ion-button');
        if (!button && event.target instanceof Element) button = event.target.closest('ion-button');
        if (!button) return;
        const label = (button.textContent || '').replace(/\s+/g, ' ').trim();
        if (label !== 'Начать смену' && label !== 'Готов брать заказы') return;
        const token = accountChanged();
        if (token && phase === 'ready') return;
        event.preventDefault();
        event.stopImmediatePropagation();
        const value = { kind:'shift-readiness', phase:phase === 'failed' || !token ? 'failed' : 'loading' };
        if (httpStatus === 0 || statusOf(httpStatus) !== undefined) value.status = httpStatus;
        const signature = `${value.phase}:${value.status ?? ''}:${sequence}`;
        const now = Date.now();
        if (notice !== signature || now - noticeAt >= 750) {
          notice = signature; noticeAt = now;
          try { send(value); } catch (_) {}
        }
      } catch (_) { /* Do not interfere with unrelated site actions. */ }
    };
    const onStorage = () => { try { accountChanged(); } catch (_) {} };
    document.addEventListener('click', onClick, true);
    window.addEventListener('storage', onStorage);
    return {
      begin, response, rejected, accountChanged,
      dispose() {
        disposed = true;
        sequence++;
        cancelReady();
        document.removeEventListener('click', onClick, true);
        window.removeEventListener('storage', onStorage);
        account = undefined;
      }
    };
  };
})();
