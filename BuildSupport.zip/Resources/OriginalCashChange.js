(() => {
  'use strict';
  // Read the original order response only. Never fetch, persist payment data,
  // edit the site's inputs or imply that the customer has already paid.
  window.__vvInstallCashChange = ({ getToken, route }) => {
    const id = 'vv-native-cash-change';
    let account, routeKey, data, sequence = 0, frame = 0, disposed = false, observer;
    const token = () => { try { return getToken() || null; } catch (_) { return null; } };
    const orderRoute = () => {
      try {
        const url = new URL(route(), location.href);
        const parcelID = url.searchParams.get('id_parcel');
        return url.pathname === '/order' && parcelID && /^[0-9]{1,30}$/.test(parcelID) ? parcelID : null;
      } catch (_) { return null; }
    };
    const remove = () => document.getElementById(id)?.remove();
    const sync = () => {
      const nextAccount = token(), nextRoute = orderRoute();
      if (nextAccount !== account || nextRoute !== routeKey) {
        account = nextAccount; routeKey = nextRoute; data = undefined; sequence++; remove();
      }
    };
    const cents = raw => {
      if (!['number','string'].includes(typeof raw)) return null;
      const text = String(raw).replace(/[ \u00a0\u202f]/g, '').replace(',', '.');
      if (!/^[0-9]{1,9}(?:\.[0-9]{1,2})?$/.test(text)) return null;
      const [whole, fraction = ''] = text.split('.');
      const value = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
      return Number.isSafeInteger(value) ? value : null;
    };
    const money = value => new Intl.NumberFormat('ru-RU', {
      minimumFractionDigits:value % 100 ? 2 : 0, maximumFractionDigits:2
    }).format(value / 100) + ' ₽';
    const noChange = /(?:без\s+сдачи|сдач[аиу]?\s+не\s+(?:нужн[аоы]?|надо)|не\s+(?:нужн[аоы]?|надо)\s+сдач[аиу]?)/gi;
    const calculate = parcel => {
      if (!parcel || typeof parcel !== 'object' || Array.isArray(parcel)) return null;
      const delivered = parcel.parcel_status === 'delivered';
      const way = delivered && parcel.pay_way_fact !== undefined && parcel.pay_way_fact !== null ? parcel.pay_way_fact : parcel.pay_way;
      if (String(way) !== '4') return null; // The original K.CASH enum.
      const comments = [parcel.comment, parcel.add_comment,
        typeof parcel.comment_client === 'string' && !/^\s*[0-9]+\s*$/.test(parcel.comment_client) ? parcel.comment_client : '']
        .filter(value => typeof value === 'string' && value.trim()).map(value => value.trim());
      const request = comments.some(text => /(?:^|[^а-яё])сдач[а-яё]*(?![а-яё])/i.test(text.replace(noChange, '')));
      if (!request) return { title:'Без сдачи', detail:'Оплата наличными' };
      const unclear = { title:'Сдачу уточни у покупателя', detail:'Сумма в комментарии неоднозначна' };
      if (comments.some(text => { noChange.lastIndex = 0; return noChange.test(text); })) return unclear;
      const due = cents(parcel.pay_summ);
      if (due === null || due <= 0) return { ...unclear, detail:'Не удалось определить сумму к оплате' };
      const pattern = /(?:^|[^а-яё])сдач[ауи]?(?![а-яё])\s+(?:пожалуйста[,\s]+)?(?:с|со)\s+(?:купюры\s+)?[:]?\s*((?:[0-9]{1,3}(?:[ \u00a0\u202f][0-9]{3})+|[0-9]{1,9})(?:[.,][0-9]{1,2})?)\s*(тыс(?:яч(?:и|а)?)?\.?)?(?![0-9]|[.,][0-9])/gi;
      let tendered;
      for (const text of comments) {
        for (const match of text.matchAll(pattern)) {
          let value = cents(match[1]);
          if (value === null) return unclear;
          if (match[2]) value *= 1000;
          const rest = text.slice(match.index + match[0].length);
          const tail = rest.split(/[\n.;]/)[0];
          if (/(?:^|[^а-яё])(?:или|либо)(?![а-яё])/i.test(tail) || /^\s+[0-9]/.test(tail) ||
              /(?:^|[^а-яё])(?:или|либо)\s+(?:(?:с|со)\s+)?[0-9]/i.test(rest) || /^\s*[\/|]\s*[0-9]/.test(rest)) return unclear;
          if (!Number.isSafeInteger(value) || value < due || (tendered !== undefined && tendered !== value)) return unclear;
          tendered = value;
        }
      }
      return tendered === undefined ? unclear : {
        title:'Сдача ' + money(tendered - due), detail:'С ' + money(tendered) + ' · к оплате ' + money(due)
      };
    };
    const schedule = () => {
      if (disposed || frame) return;
      frame = requestAnimationFrame(() => { frame = 0; render(); });
    };
    const watch = () => {
      if (observer || !document.body || typeof MutationObserver !== 'function') return;
      observer = new MutationObserver(records => {
        // Once inserted, map animations and unrelated order content do not need
        // reparsing. Reinsert only if React replaced our host or payment row.
        const card = document.getElementById(id);
        if (!card || !card.isConnected) {
          if (records.some(record => record.target instanceof Element && record.target.closest('.order-page') ||
              [...record.addedNodes].some(node => node instanceof Element && (node.matches('.order-page') || node.querySelector('.order-page'))))) schedule();
        }
      });
      observer.observe(document.body, { childList:true, subtree:true });
    };
    const render = () => {
      if (disposed) return;
      sync(); watch();
      const value = account && routeKey && data ? calculate(data) : null;
      if (!value) { remove(); return; }
      const page = [...document.querySelectorAll('.order-page')].find(node => !node.closest('.ion-page-hidden,.ion-page-invisible,[aria-hidden="true"]'));
      const content = page?.querySelector('ion-content');
      if (!content) { remove(); return; }
      let card = document.getElementById(id);
      if (!card || !content.contains(card)) {
        remove(); card = document.createElement('section'); card.id = id;
        card.setAttribute('role', 'note'); card.setAttribute('aria-label', 'Сдача по комментарию покупателя');
        card.style.cssText = 'margin:12px 16px;padding:14px;border:1px solid var(--ion-color-primary,#179c49);border-radius:10px;color:var(--ion-text-color,inherit);font:16px -apple-system,BlinkMacSystemFont,sans-serif;';
        const title = document.createElement('strong'), detail = document.createElement('div');
        title.style.cssText = 'display:block;font-size:19px;line-height:25px;';
        detail.style.cssText = 'margin-top:4px;font-size:14px;line-height:20px;opacity:.7;';
        card.append(title, detail);
        const payment = content.querySelector('[data-testid="pay-way"]') || content.querySelector('[data-testid="pay-sum"]');
        if (payment) payment.after(card); else content.prepend(card);
      }
      if (card.children[0].textContent !== value.title) card.children[0].textContent = value.title;
      if (card.children[1].textContent !== value.detail) card.children[1].textContent = value.detail;
    };
    const begin = (input, init) => {
      try {
        if (disposed) return;
        sync();
        if (!account || !routeKey) return;
        const source = typeof input === 'string' ? input : input?.url || input?.href;
        const url = new URL(source, location.href);
        const method = String(init?.method || input?.method || 'GET').toUpperCase();
        if (url.origin !== 'https://delivery-api.vkusvill.ru' || url.pathname !== '/v2/courier/get_parcel' || method !== 'POST') return;
        if (typeof init?.body !== 'string' || init.body.length > 20000) return;
        const body = JSON.parse(init.body);
        if (String(body.id_parcel) !== routeKey) return;
        if (init.headers) {
          const authorization = new Headers(init.headers).get('Authorization');
          if (authorization && authorization !== 'Bearer ' + account) return;
        }
        data = undefined; remove();
        return { account, routeKey, sequence:++sequence };
      } catch (_) { /* Never alter a request on observer failure. */ }
    };
    const current = ticket => {
      sync();
      return !disposed && ticket && ticket.account === account && ticket.routeKey === routeKey && ticket.sequence === sequence;
    };
    const observe = (ticket, response) => {
      try {
        if (!current(ticket) || !response.ok) return;
        response.clone().json().then(value => {
          try {
            if (!current(ticket) || !value?.parcel || String(value.parcel.id_parcel) !== routeKey) return;
            const raw = value.parcel;
            // Keep only the fields required for this one visible order.
            data = Object.fromEntries(['pay_way','pay_way_fact','pay_summ','parcel_status','comment','add_comment','comment_client'].map(key => [key,raw[key]]));
            schedule();
          } catch (_) {}
        }).catch(() => {});
      } catch (_) { /* A response clone cannot change the site's result. */ }
    };
    return {
      begin, observe, render, calculate,
      accountChanged() { if (!disposed) { sync(); schedule(); } },
      dispose() { disposed = true; data = undefined; account = undefined; sequence++; remove(); observer?.disconnect(); if (frame) cancelAnimationFrame(frame); }
    };
  };
})();
