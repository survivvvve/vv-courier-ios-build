import Foundation

final class ColdSignalRecorder: @unchecked Sendable {
    private let lock = NSLock()
    private var values: [Bool] = []
    func append(_ value: Bool) { lock.lock(); defer { lock.unlock() }; values.append(value) }
    func snapshot() -> [Bool] { lock.lock(); defer { lock.unlock() }; return values }
}

final class FeedFixtureProtocol: URLProtocol {
    static var handler: ((URLRequest) throws -> [String: Any])!
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let object = try Self.handler(request)
            let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: ["Content-Type": "application/json"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: try JSONSerialization.data(withJSONObject: object))
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

@main struct FeedRegressionTests {
    static func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open(); defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 4096)
            while stream.hasBytesAvailable {
                let count = stream.read(&buffer, maxLength: buffer.count)
                guard count > 0 else { break }
                data.append(contentsOf: buffer.prefix(count))
            }
        }
        return try JSONSerialization.jsonObject(with: data) as! [String: Any]
    }
    static func main() async throws {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [FeedFixtureProtocol.self]
        let transport = URLSession(configuration: configuration)
        defer { transport.invalidateAndCancel() }
        let api = CourierAPI(session: Session(token: "offline-fixture", courierID: "1"), shopNumbers: [101], transport: transport)
        for dictionaryTotal in [true, false] {
            var offsets: [Int] = []
            FeedFixtureProtocol.handler = { request in
                precondition(request.url?.path.hasSuffix(Feed.assembly.endpoint) == true)
                let body = try Self.body(request)
                precondition(body["building"] as? Bool == true && body["waiting"] as? Bool == true && body["sloted"] as? Bool == true, "All assembly categories must be included")
                let pagination = body["pagination"] as! [String: Any]
                let offset = pagination["offset"] as! Int
                offsets.append(offset)
                let end = min(107, offset + 100)
                let rows: [[String: Any]] = (offset..<end).map { ["id_parcel": String($0 + 1), "shopno": 101] }
                return ["parcels": rows, "total": dictionaryTotal ? (["building_count": "7", "waiting_count": "100", "sloted_count": "107"] as Any) : 107,
                        "checking": ["parcels_packages_inspection_after": [String(offset + 1): 1]],
                        "map": ["parcels": [["id_parcel": String(offset + 1), "latitude": "60.07", "longitude": "30.32", "colour_parcel": "violet", "listNumber": offset + 1, "corr_addr": "Учебная улица, 1"]],
                                "shops": [["shopno": 101, "latitude": "60.06", "longitude": "30.31"]]]]
            }
            let result = try await api.feed(.assembly)
            precondition(result.parcels.count == 107 && result.total == 107, "Dictionary totals must not truncate archive to its first page")
            precondition(offsets == [0, 100])
            precondition((result.checking["parcels_packages_inspection_after"] as? [String: Any])?.count == 2, "Checking metadata must survive pagination")
            precondition(result.mapShops.count == 1, "Shop pins must not repeat across pages")
            precondition((result.parcels[100].raw["map_info"] as? [String: Any])?["colour_parcel"] as? String == "violet", "Map colors/positions must survive pagination")
            precondition(result.parcels[0].raw["corr_addr"] as? String == "Учебная улица, 1", "Map address must remain available as a fallback")
        }
        for selected in ["building", "waiting", "sloted"] {
            FeedFixtureProtocol.handler = { request in
                let body = try Self.body(request)
                for key in ["building", "waiting", "sloted"] { precondition(body[key] as? Bool == (key == selected)) }
                return ["parcels": [], "total": ["building_count": "0", "waiting_count": "0", "sloted_count": "0"]]
            }
            let result = try await api.feed(.assembly, assembly: selected)
            precondition(result.parcels.isEmpty && result.total == 0)
        }
        let parcel = Parcel(["id_parcel": "fixture", "task_date_supply_until_courier_rfc": "2026-11-02T10:00:00Z", "date_supply_until_rfc": "2026-11-02T11:00:00Z",
                             "parcel_status": "created", "date_collect_start_rfc": "2026-11-02T09:00:00Z",
                             "orders": [["id_order": "fixture-order", "id_general_view": "12345678", "packages": [["id_package": "a", "id_cell": "CO-1"], ["id_package": "a", "id_cell": "CO-1"], ["id_package": "b", "id_cell": "CZ-2"]]]]])
        precondition(parcel.deadline == timestamp("2026-11-02T10:00:00Z"), "Courier deadline must take precedence over customer slot")
        precondition(parcel.statusTitle == "Собирается")
        let suborders = ParcelSuborder.parse(parcel)
        precondition(suborders.count == 1 && suborders[0].label == "12345678" && suborders[0].packageCount == 2)
        precondition(suborders[0].locations.map(\.id) == ["CO-1", "CZ-2"])
        let coldSignals = ColdSignalRecorder()
        let observer = NotificationCenter.default.addObserver(forName: CourierAPI.coldControlNotification, object: nil, queue: nil) { event in
            precondition(event.userInfo?["courierID"] as? String == "1")
            precondition(event.userInfo?["startedAt"] is Date)
            coldSignals.append(event.userInfo?["required"] as! Bool)
        }
        defer { NotificationCenter.default.removeObserver(observer) }
        FeedFixtureProtocol.handler = { _ in ["business_error": 102] }
        do { _ = try await api.dictionary(CourierAPI.root + "/offline-control"); preconditionFailure("Cold control error must not be accepted as an action success") }
        catch let error as CourierError { precondition(error.businessCode == 102) }
        FeedFixtureProtocol.handler = { _ in ["termocontrol": ["is_need_termocontrol": false]] }
        _ = try await api.dictionary(CourierAPI.root + "/offline-control")
        FeedFixtureProtocol.handler = { _ in ["termocontrol": ["is_need_termocontrol": "true"]] }
        _ = try await api.dictionary(CourierAPI.root + "/offline-control")
        precondition(coldSignals.snapshot() == [true, false], "Incoming task must propagate across any API response; malformed flags must not create a task")
        print("Feed regression tests passed: flags, totals, pagination, package rules, courier deadline and suborders")
    }
}
