import Foundation

private final class TelegramFixtureProtocol: URLProtocol {
    struct Reply {
        var status: Int = 200
        var data: Data
        var error: URLError?
        var responseURL: URL?
        var headers: [String: String] = [:]
        init(_ json: Any, status: Int = 200, headers: [String: String] = [:]) {
            self.status = status; data = try! JSONSerialization.data(withJSONObject: json); self.headers = headers
        }
        init(error: URLError) { data = Data(); self.error = error }
        init(raw: String, status: Int = 200) { data = Data(raw.utf8); self.status = status }
    }
    private static let lock = NSLock()
    private static var replies: [Reply] = []
    private static var requests: [URLRequest] = []
    static func reset(_ responses: [Reply]) { lock.lock(); replies = responses; requests = []; lock.unlock() }
    static var recorded: [URLRequest] { lock.lock(); defer { lock.unlock() }; return requests }
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.lock.lock(); Self.requests.append(request)
        let reply = Self.replies.isEmpty ? Reply(error: URLError(.badServerResponse)) : Self.replies.removeFirst()
        Self.lock.unlock()
        if let error = reply.error { client?.urlProtocol(self, didFailWithError: error); return }
        let response = HTTPURLResponse(url: reply.responseURL ?? request.url!, statusCode: reply.status, httpVersion: "HTTP/1.1", headerFields: reply.headers)!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: reply.data)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() { }
    static func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open(); defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 1024)
            while stream.hasBytesAvailable {
                let count = stream.read(&buffer, maxLength: buffer.count)
                if count <= 0 { break }
                data.append(contentsOf: buffer.prefix(count))
            }
        }
        return try JSONSerialization.jsonObject(with: data) as! [String: Any]
    }
}

@main struct TelegramOrderTests {
    static func main() async throws {
        var checks = 0
        func check(_ condition: @autoclosure () -> Bool, _ message: String) { precondition(condition(), message); checks += 1 }
        func invalidDestination(_ input: String, thread: String = "") -> Bool {
            do { _ = try TelegramChatDestination.parse(input: input, threadInput: thread); return false }
            catch { return error as? TelegramBotError == .invalidDestination }
        }
        func parsed(_ input: String, thread: String = "", chatID: String, threadID: Int? = nil) throws {
            let destination = try TelegramChatDestination.parse(input: input, threadInput: thread)
            check(destination == TelegramChatDestination(chatID: chatID, threadID: threadID), "Destination parsing failed")
        }
        try parsed(" @Courier_Group ", chatID: "@Courier_Group")
        try parsed("-1001234567890", chatID: "-1001234567890")
        try parsed("123456789", chatID: "123456789")
        try parsed(" -000123 ", chatID: "-123")
        try parsed("https://t.me/c/1234567890/42", chatID: "-1001234567890")
        try parsed("t.me/c/1234567890/42", thread: " 17 ", chatID: "-1001234567890", threadID: 17)
        try parsed("https://t.me/Courier_Group", chatID: "@Courier_Group")
        try parsed("https://t.me/Courier_Group/42", chatID: "@Courier_Group")
        try parsed("https://telegram.me/Courier_Group/42", chatID: "@Courier_Group")
        try parsed("https://t.me/s/Courier_Group/42", chatID: "@Courier_Group")
        try parsed("https://t.me/c/1234567890/17/42", chatID: "-1001234567890", threadID: 17)
        try parsed("https://t.me/Courier_Group/17/42", chatID: "@Courier_Group", threadID: 17)
        try parsed("https://t.me/Courier_Group/42?thread=17", chatID: "@Courier_Group", threadID: 17)
        try parsed("https://t.me/c/1234567890/17/42", thread: "18", chatID: "-1001234567890", threadID: 18)
        for input in ["", "0", "-0", "-", "+123", "@", "@bad/name", "@bad name", "@1name", "@кириллица", "https://t.me/+invite", "https://t.me/joinchat/invite", "https://t.me.evil.example/group", "https://evil.example/t.me/group", "https://t.me@evil.example/group", "https://name@t.me/group", "https://t.me:8443/group", "https://t.me/c/123", "https://t.me/c/123/not-a-message", "https://t.me/c/-123/45", "https://t.me/c/9223372036854775807/42", "https://t.me/group/not-a-message", "https://t.me/group/42?thread=zero"] {
            check(invalidDestination(input), "Malformed or non-addressable destination must be rejected")
        }
        for thread in ["0", "-1", "1.5", "abc", "9999999999999999999999999999"] { check(invalidDestination("@group", thread: thread), "Malformed topic must be rejected") }
        let destination = try TelegramChatDestination.parse(input: "https://t.me/c/1234567890/42", threadInput: "17")
        let destinationCopy = try JSONDecoder().decode(TelegramChatDestination.self, from: JSONEncoder().encode(destination))
        check(destinationCopy == destination, "Destination Codable must preserve the topic")

        // Every request is intercepted. There is no fall-through to a real API.
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [TelegramFixtureProtocol.self]
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel() }
        let token = "123456789:TEST_ONLY_NON_SECRET_ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        let api = TelegramBotAPI(token: token, session: session)
        func expect(_ expected: TelegramBotError, _ message: String, _ operation: () async throws -> Void) async {
            do { try await operation(); check(false, message + ": missing error") }
            catch {
                check(error as? TelegramBotError == expected, message)
                let description = error.localizedDescription
                check(!description.contains(token) && !description.contains("https://") && !description.contains("RAW_SECRET_DESCRIPTION"), "Errors must not expose tokens, URLs or raw Telegram descriptions")
            }
        }
        TelegramFixtureProtocol.reset([.init(["ok": true, "result": ["id": Int64(1234567890123), "is_bot": true, "username": "fixture_bot", "first_name": "Тест", "last_name": "Бот"]])])
        let me = try await api.getMe()
        check(me == TelegramBotIdentity(id: 1234567890123, username: "fixture_bot", name: "Тест Бот"), "getMe decodes bot identity")
        let meRequest = TelegramFixtureProtocol.recorded[0]
        check(meRequest.url?.scheme == "https" && meRequest.url?.host == "api.telegram.org" && meRequest.url?.path.hasSuffix("/getMe") == true, "Only the HTTPS Telegram Bot endpoint is used")
        check(meRequest.httpMethod == "POST" && meRequest.value(forHTTPHeaderField: "Content-Type") == "application/json; charset=UTF-8", "Requests use POST JSON")
        check(meRequest.value(forHTTPHeaderField: "Authorization") == nil && meRequest.value(forHTTPHeaderField: "X-VKUSVILL-TOKEN") == nil && !meRequest.httpShouldHandleCookies, "Courier credentials and cookies are not attached")
        let meBody = try TelegramFixtureProtocol.body(meRequest)
        check(meBody.isEmpty, "getMe has no unrelated credentials or payload")

        TelegramFixtureProtocol.reset([.init(["ok": true, "result": ["id": Int64(-1001234567890123), "type": "supergroup", "title": "Курьеры"]])])
        let chat = try await api.getChat(destination)
        check(chat == TelegramChatIdentity(id: -1001234567890123, title: "Курьеры", type: "supergroup"), "getChat preserves large signed identifiers")
        let chatBody = try TelegramFixtureProtocol.body(TelegramFixtureProtocol.recorded[0])
        check(chatBody["chat_id"] as? String == destination.chatID && chatBody.count == 1, "getChat checks the chat, not an unrelated topic")

        TelegramFixtureProtocol.reset([.init(["ok": true, "result": ["message_id": 27]])])
        let plainText = "⚡ Заказ 22421\nВес 3,125 кг · 150,50 ₽ <plain> & _text_"
        try await api.sendMessage(to: destination, text: plainText)
        let sendRequest = TelegramFixtureProtocol.recorded[0]
        let sendBody = try TelegramFixtureProtocol.body(sendRequest)
        check(sendRequest.url?.path.hasSuffix("/sendMessage") == true && sendBody["chat_id"] as? String == destination.chatID, "sendMessage targets the chosen chat")
        check(sendBody["message_thread_id"] as? Int == 17, "sendMessage targets the chosen topic")
        check(sendBody["text"] as? String == plainText && sendBody["parse_mode"] == nil && sendBody.count == 3, "Unicode text is preserved and cannot be interpreted as markup")
        check(TelegramFixtureProtocol.recorded.count == 1, "A send performs one request")
        TelegramFixtureProtocol.reset([.init(["ok": true, "result": ["message_id": 28]])])
        try await api.sendMessage(to: TelegramChatDestination(chatID: "@group"), text: "Проверка")
        let noThreadBody = try TelegramFixtureProtocol.body(TelegramFixtureProtocol.recorded[0])
        check(noThreadBody["message_thread_id"] == nil, "No topic is invented for an ordinary group")

        let discovery: [[String: Any]] = [
            ["update_id": 1, "message": ["chat": ["id": -10, "type": "group", "title": "Первая"], "text": "UNREAD_PRIVATE_MESSAGE"]],
            ["update_id": 2, "my_chat_member": ["chat": ["id": Int64(-1001234567890), "type": "supergroup", "title": "Вторая"], "new_chat_member": ["status": "member"]]],
            ["update_id": 3, "message": ["chat": ["id": -10, "type": "group", "title": "Новое имя"], "text": "UNREAD_PRIVATE_MESSAGE"]],
            ["update_id": 4, "message": ["chat": ["id": 42, "type": "private", "first_name": "Имя"], "text": "UNREAD_PRIVATE_MESSAGE"]],
            ["update_id": 5, "message": ["chat": ["id": -999, "type": "channel", "title": "Канал"]]],
            ["update_id": 6, "inline_query": ["query": "UNREAD_PRIVATE_MESSAGE"]]
        ]
        TelegramFixtureProtocol.reset([.init(["ok": true, "result": discovery])])
        let chats = try await api.discoverChats()
        check(chats == [TelegramChatIdentity(id: -10, title: "Новое имя", type: "group"), TelegramChatIdentity(id: -1001234567890, title: "Вторая", type: "supergroup")], "Discovery uses only group metadata and deduplicates by ID")
        check(!String(describing: chats).contains("UNREAD_PRIVATE_MESSAGE"), "Message text is absent from discovery results")
        let discoveryRequest = TelegramFixtureProtocol.recorded[0]
        let discoveryBody = try TelegramFixtureProtocol.body(discoveryRequest)
        check(discoveryRequest.url?.path.hasSuffix("/getUpdates") == true && discoveryBody["timeout"] as? Int == 0, "Discovery is one short getUpdates request")
        check(discoveryBody.count == 1 && discoveryBody["offset"] == nil && discoveryBody["allowed_updates"] == nil, "Discovery cannot acknowledge updates or change another consumer's filter")

        TelegramFixtureProtocol.reset([.init(["ok": false, "error_code": 409, "description": "RAW_SECRET_DESCRIPTION " + token], status: 409)])
        await expect(.rejected(code: 409, retryAfter: nil), "409 must not overwrite another webhook or poll") { _ = try await api.discoverChats() }
        check(TelegramFixtureProtocol.recorded.count == 1 && TelegramBotError.rejected(code: 409, retryAfter: nil).localizedDescription.contains("webhook"), "409 is actionable and performs no corrective API call")
        TelegramFixtureProtocol.reset([.init(["ok": false, "error_code": 429, "parameters": ["retry_after": 7], "description": "RAW_SECRET_DESCRIPTION"], status: 429)])
        await expect(.rejected(code: 429, retryAfter: 7), "429 is a known refusal with retryAfter") { try await api.sendMessage(to: destination, text: "Тест") }
        check(TelegramFixtureProtocol.recorded.count == 1, "429 is not retried inside the client")
        TelegramFixtureProtocol.reset([.init(["ok": false, "error_code": 429, "parameters": ["retry_after": 9]])])
        await expect(.rejected(code: 429, retryAfter: 9), "Telegram error envelopes are checked even with HTTP 200") { _ = try await api.getMe() }
        TelegramFixtureProtocol.reset([.init(raw: "not-json", status: 429)])
        await expect(.rejected(code: 429, retryAfter: nil), "HTTP 429 remains a known rejection without JSON") { try await api.sendMessage(to: destination, text: "Тест") }
        TelegramFixtureProtocol.reset([.init(["ok": false, "error_code": 403, "description": "RAW_SECRET_DESCRIPTION"], status: 403)])
        await expect(.rejected(code: 403, retryAfter: nil), "Forbidden access is a known refusal") { try await api.sendMessage(to: destination, text: "Тест") }
        TelegramFixtureProtocol.reset([.init(["ok": false, "error_code": 401], status: 401)])
        await expect(.invalidToken, "An unauthorized token is reported without echoing it") { _ = try await api.getMe() }
        TelegramFixtureProtocol.reset([.init(raw: "not-json")])
        await expect(.invalidResponse, "A malformed read response is rejected") { _ = try await api.getMe() }
        TelegramFixtureProtocol.reset([.init(["ok": true, "result": ["id": 1, "is_bot": false]])])
        await expect(.invalidResponse, "getMe must identify a bot") { _ = try await api.getMe() }
        TelegramFixtureProtocol.reset([.init(raw: "not-json")])
        await expect(.uncertain, "A malformed send confirmation cannot be assumed unsent") { try await api.sendMessage(to: destination, text: "Тест") }
        TelegramFixtureProtocol.reset([.init(raw: "gateway error", status: 502)])
        await expect(.uncertain, "A gateway error cannot establish whether sending succeeded") { try await api.sendMessage(to: destination, text: "Тест") }
        for code in [URLError.Code.timedOut, .networkConnectionLost, .cancelled, .cannotConnectToHost] {
            TelegramFixtureProtocol.reset([.init(error: URLError(code, userInfo: [NSLocalizedDescriptionKey: token + " https://RAW_SECRET_DESCRIPTION"]))])
            await expect(.uncertain, "An interrupted send is uncertain") { try await api.sendMessage(to: destination, text: "Тест") }
            check(TelegramFixtureProtocol.recorded.count == 1, "Interrupted sends are never retried")
        }
        TelegramFixtureProtocol.reset([.init(error: URLError(.timedOut))])
        await expect(.invalidResponse, "Read transport errors are sanitized") { _ = try await api.getMe() }
        TelegramFixtureProtocol.reset([])
        for badToken in ["", "token", "1:short", "1:../../escape_to_another_host", "1:" + String(repeating: "A", count: 20) + "/getMe", "0:" + String(repeating: "A", count: 35)] {
            await expect(.invalidToken, "Invalid token syntax never reaches a transport") { _ = try await TelegramBotAPI(token: badToken, session: session).getMe() }
        }
        check(TelegramFixtureProtocol.recorded.isEmpty, "Invalid tokens perform no network request")
        await expect(.invalidDestination, "An invalid decoded topic is checked before sending") { try await api.sendMessage(to: TelegramChatDestination(chatID: "@group", threadID: -1), text: "Тест") }
        await expect(.rejected(code: 400, retryAfter: nil), "Empty messages are rejected before sending") { try await api.sendMessage(to: destination, text: " \n ") }
        await expect(.rejected(code: 400, retryAfter: nil), "Oversized messages are rejected before sending") { try await api.sendMessage(to: destination, text: String(repeating: "я", count: 4097)) }
        check(TelegramFixtureProtocol.recorded.isEmpty, "Invalid destinations and messages perform no request")

        let now = Date(timeIntervalSince1970: 1800000000)
        func parcel(_ id: String, express: Bool = true, weight: Double? = 3.125, reward: Double? = 150.5) -> TelegramOrderRecord {
            TelegramOrderRecord(id: id, label: "#" + id, shopID: 5470, weight: weight, reward: reward, express: express)
        }
        let first = parcel("100022421"), second = parcel("200034233", express: false), third = parcel("300052523"), fourth = parcel("400012345", express: false)
        var ledger = TelegramOrderLedger()
        check(ledger.observe(courierID: "a", shops: [5470], shiftActive: nil, assembling: [first], ready: [], onlyExpress: false, at: now).isEmpty && !ledger.active, "Unknown shift cannot establish a Telegram baseline")
        check(ledger.observe(courierID: "a", shops: [5470], shiftActive: false, assembling: [first], ready: [], onlyExpress: false, at: now).isEmpty, "Inactive shifts cannot notify Telegram")
        check(ledger.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [first], ready: [], onlyExpress: false, at: now).isEmpty, "First Telegram inventory is silent")
        let epoch = ledger.epoch
        let events = ledger.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [first, second, third, third], ready: [], onlyExpress: false, at: now.addingTimeInterval(20))
        check(events.count == 2 && Set(events.map { $0.parcel.id }) == [second.id, third.id], "All-order mode detects regular and express orders without duplicates")
        let ordinary = events.first { !$0.parcel.express }!
        let express = events.first { $0.parcel.express }!
        check(ordinary.messageText == "Новый заказ\nЗаказ 34233 · магазин 5470\nВес 3,125 кг · 150,50 ₽", "Ordinary message is concise, uses last five digits, Russian numbers and full metrics")
        check(express.messageText == "⚡ Оформлен экспресс\nЗаказ 52523 · магазин 5470\nВес 3,125 кг · 150,50 ₽", "Express message has a clear lightning marker")
        check(!express.messageText.contains("#") && !express.messageText.contains(third.id), "Full IDs and hash prefixes do not leak into text")
        check(ledger.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [first, second, third], ready: [], onlyExpress: false, at: now.addingTimeInterval(40)).isEmpty, "Refreshing cannot duplicate Telegram events")
        check(ledger.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [], ready: [], onlyExpress: false, at: now.addingTimeInterval(60)).isEmpty, "Disappearance does not invent readiness")
        let readyRecord = parcel(first.id, weight: 4.25, reward: 200)
        let readyEvents = ledger.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [first], ready: [readyRecord], onlyExpress: false, at: now.addingTimeInterval(80))
        check(readyEvents.count == 1 && readyEvents[0].kind == .ready && readyEvents[0].parcel.weight == 4.25, "Ready events use the current ready snapshot's metadata")
        check(readyEvents[0].messageText == "⚡ Экспресс готов\nЗаказ 22421 · магазин 5470\nВес 4,25 кг · 200,00 ₽", "Ready formatting preserves metadata and trims trailing weight zeros")
        check(express.id.hasPrefix("vv.telegram.") && express.id != readyEvents[0].id, "Telegram events have independent stable IDs per order and transition")
        var restored = try JSONDecoder().decode(TelegramOrderLedger.self, from: JSONEncoder().encode(ledger))
        check(restored.epoch == epoch && restored.active && restored.lastObservedAt == now.addingTimeInterval(80), "Ledger state survives process restart")
        check(restored.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [], ready: [readyRecord], onlyExpress: false, at: now.addingTimeInterval(100)).isEmpty, "Restored events are not resent")
        let copiedEvent = try JSONDecoder().decode(TelegramOrderEvent.self, from: JSONEncoder().encode(readyEvents[0]))
        check(copiedEvent == readyEvents[0] && copiedEvent.messageText == readyEvents[0].messageText, "Event persistence preserves ID and message formatting")
        check(restored.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [fourth], ready: [], onlyExpress: false, at: now.addingTimeInterval(300)).isEmpty, "Returning after a long pause does not announce old inventory")
        check(restored.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [parcel("500001111")], ready: [], onlyExpress: false, at: now.addingTimeInterval(290)).isEmpty, "Clock rollback is baselined silently")
        check(restored.observe(courierID: "b", shops: [5470], shiftActive: true, assembling: [first], ready: [third], onlyExpress: false, at: now.addingTimeInterval(310)).isEmpty && restored.epoch != epoch, "Another account gets a fresh silent epoch")
        check(restored.observe(courierID: "b", shops: [9999], shiftActive: true, assembling: [first, second], ready: [], onlyExpress: false, at: now.addingTimeInterval(330)).isEmpty, "Changing shop scope is silent")
        restored.endShift()
        check(!restored.active && restored.lastObservedAt == nil, "Shift end stops Telegram observation and resets freshness")
        check(restored.observe(courierID: "b", shops: [9999], shiftActive: true, assembling: [first, third], ready: [], onlyExpress: false, at: now.addingTimeInterval(350)).isEmpty, "A new shift cannot replay its starting inventory")

        var filtered = TelegramOrderLedger()
        _ = filtered.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [first, second], ready: [], onlyExpress: true, at: now)
        let expressOnly = filtered.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [first, second, third, fourth], ready: [], onlyExpress: true, at: now.addingTimeInterval(20))
        check(expressOnly.count == 1 && expressOnly[0].parcel.id == third.id, "Express-only mode excludes ordinary orders")
        check(filtered.observe(courierID: "a", shops: [5470], shiftActive: nil, assembling: [first, second, third, fourth], ready: [], onlyExpress: false, at: now.addingTimeInterval(30)).isEmpty, "Unknown shift cannot consume a preference change")
        check(filtered.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [first, second, third, fourth], ready: [], onlyExpress: false, at: now.addingTimeInterval(40)).isEmpty, "Enabling all orders cannot flood preexisting regular orders")
        let fifth = parcel("500008888", express: false)
        check(filtered.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [first, second, third, fourth, fifth], ready: [], onlyExpress: false, at: now.addingTimeInterval(60)).first?.parcel.id == fifth.id, "Later regular orders are detected after mode change")
        check(filtered.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [first], ready: [third], onlyExpress: true, at: now.addingTimeInterval(80)).isEmpty, "Narrowing the filter is also baselined silently")
        check(filtered.observe(courierID: "a", shops: [5470], shiftActive: true, assembling: [parcel("600009999")], ready: [], onlyExpress: true, suppressExisting: true, at: now.addingTimeInterval(100)).isEmpty, "Explicit suppression is respected")

        let noMetrics = TelegramOrderEvent(epoch: "e", courierID: "a", parcel: TelegramOrderRecord(id: "opaque-id", label: "без номера", express: false), kind: .ready, observedAt: now)
        check(noMetrics.messageText == "Заказ готов\nЗаказ —", "Unknown values are omitted rather than invented")
        let invalidMetrics = TelegramOrderEvent(epoch: "e", courierID: "a", parcel: TelegramOrderRecord(id: "123456", label: "", shopID: -1, weight: .infinity, reward: -20, express: false), kind: .created, observedAt: now)
        check(invalidMetrics.messageText == "Новый заказ\nЗаказ 23456", "Invalid metrics are omitted and ID digits are a safe number fallback")
        let zeroMetrics = TelegramOrderEvent(epoch: "e", courierID: "a", parcel: parcel("12345", weight: 0, reward: 0), kind: .created, observedAt: now)
        check(zeroMetrics.messageText.contains("Вес 0 кг · 0,00 ₽"), "Known zero amounts remain distinct from unknown values")
        var collisions = TelegramOrderLedger()
        _ = collisions.observe(courierID: "a", shops: [], shiftActive: true, assembling: [], ready: [], onlyExpress: false, at: now)
        let collisionEvents = collisions.observe(courierID: "a", shops: [], shiftActive: true, assembling: [parcel("1000012345"), parcel("2000012345")], ready: [], onlyExpress: false, at: now.addingTimeInterval(20))
        check(collisionEvents.count == 2 && Set(collisionEvents.map(\.id)).count == 2, "Deduplication uses full IDs even when visible five-digit numbers collide")
        var anonymous = TelegramOrderLedger()
        check(anonymous.observe(courierID: "", shops: [], shiftActive: true, assembling: [first], ready: [], onlyExpress: false, at: now).isEmpty && !anonymous.active, "Anonymous observations cannot establish an active courier")
        _ = anonymous.observe(courierID: "a", shops: [], shiftActive: true, assembling: [], ready: [], onlyExpress: false, at: now)
        check(anonymous.observe(courierID: " \n ", shops: [], shiftActive: nil, assembling: [first], ready: [], onlyExpress: false, at: now).isEmpty && !anonymous.active, "A missing courier identity cannot retain another account's active state")
        print("Telegram transport, parsing, formatting and ledger: \(checks) checks passed; URLProtocol fixtures only, no real API/messages/tokens")
    }
}
