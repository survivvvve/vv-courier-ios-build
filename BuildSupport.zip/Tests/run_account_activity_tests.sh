#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
ACCOUNT_TEST_DIR=$(mktemp -d)
trap 'rm -rf "$ACCOUNT_TEST_DIR"' EXIT
python3 - "$ACCOUNT_TEST_DIR" <<'PY'
from pathlib import Path
import sys
out = Path(sys.argv[1])
# Compile production AppModel verbatim, excluding the unrelated SwiftUI views.
# Only persistence is redirected to a disposable suite and an in-memory keychain.
app = Path('VVCourierApp.swift').read_text()
model = app[app.index('@MainActor final class AppModel'):app.index('\nstruct CourierErrors:')]
model = model.replace('UserDefaults.standard', 'ActivityTestDefaults.shared')
(out / 'AppModel.swift').write_text('import Foundation\nimport Combine\n// UI-only type; the production activity logic below is unchanged.\nenum ColorScheme { case light, dark }\n' + model)
# Keep the actual HTTP/parser/account methods, replacing only URLSession's
# default boundary. Every URL is intercepted, including unexpected hosts.
source = Path('CourierAPI.swift').read_text()
api = source[:source.index('    func feed(')]
api += source[source.index('    func activeShift()'):source.index('    func take(')] + '\n}\n'
api = api.replace('var transport: URLSession = .shared', 'var transport: URLSession = OfflineAccountTransport.shared')
actions = Path('OrderActions.swift').read_text()
(out / 'CourierAPI.swift').write_text(api + actions[actions.index('\nfunc truth('):])
# The monitoring publication must capture its fence before awaiting the poll.
express = Path('ExpressNotifications.swift').read_text()
loop = express[express.index('            while !Task.isCancelled && model.identity == owner {'):express.index('                do { try await Task.sleep', express.index('            while !Task.isCancelled && model.identity == owner {'))]
assert loop.index('let activity = model.activityObservation()') < loop.index('await center.poll(')
assert 'model.observeNativeActivity(active, ifCurrent: activity)' in loop
assert 'model.observeNativeActivity(nil, ifCurrent: activity)' in loop
assert 'model.active =' not in loop and 'model.shiftKnown =' not in loop
PY
xcrun swiftc -swift-version 5 -parse-as-library Models.swift ParcelAddress.swift Demo.swift ColdControlSignal.swift ExpressNotificationState.swift "$ACCOUNT_TEST_DIR/AppModel.swift" "$ACCOUNT_TEST_DIR/CourierAPI.swift" Tests/AccountActivityTests.swift -o "$ACCOUNT_TEST_DIR/AccountActivityTests"
"$ACCOUNT_TEST_DIR/AccountActivityTests"
