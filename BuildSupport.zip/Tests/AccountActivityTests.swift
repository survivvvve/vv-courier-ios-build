import Foundation

enum ActivityTestDefaults {
    static let domain = "vv-account-activity-tests." + UUID().uuidString
    static let shared = UserDefaults(suiteName: domain)!
}

/// No production Keychain or saved VV session is loaded by these tests.
enum SessionStore {
    static var session: Session?
    static func load() -> Session? { session }
    static func save(_ value: Session) throws { session = value }
    static func clear() { session = nil }
}
enum AppAppearance: String { case light }
@MainActor final class ExpressNotificationCenter {
    static let shared = ExpressNotificationCenter()
    func endObservation() { }
}
@MainActor final class InspectionDemoState {
    static let shared = InspectionDemoState()
    var checked: Set<String> = []
}

private struct AccountReply {
    var status = 200
    var object: [String: Any]
}

private final class AccountBackend: @unchecked Sendable {
    static let shared = AccountBackend()
    private let lock = NSLock()
    private var hold: String?
    private var pending: AccountFixtureProtocol?
    private var pendingReply: AccountReply?
    private var nextActivity = AccountReply(object: ["res": 0])
    private var shopReply = AccountReply(object: ["shops": []])
    private var calls: [String] = []
    func reset(hold: String? = nil, active: Bool = false, status: Int = 200) {
        lock.lock(); defer { lock.unlock() }
        precondition(pending == nil)
        self.hold = hold
        nextActivity = AccountReply(status: status, object: status == 200 ? ["res": active ? 1 : 0] : ["error": "Offline failure"])
        shopReply = AccountReply(status: hold == "/v1/courier/shops" ? status : 200, object: ["shops": []])
        calls = []
    }
    var hasPending: Bool { lock.lock(); defer { lock.unlock() }; return pending != nil }
    var requestedPaths: [String] { lock.lock(); defer { lock.unlock() }; return calls }
    func begin(_ protocolInstance: AccountFixtureProtocol) {
        let path = protocolInstance.request.url!.path
        lock.lock()
        calls.append(path)
        let response: AccountReply
        switch path {
        case "/v1/courier/shops": response = shopReply
        case "/v1/courier/courier": response = AccountReply(object: ["id_courier": 1, "name_courier": "Offline"])
        case "/v1/courier/activity":
            precondition(protocolInstance.request.httpMethod == "POST")
            response = nextActivity
        default: preconditionFailure("Unexpected offline account request: \(path)")
        }
        if path == hold {
            pending = protocolInstance; pendingReply = response; hold = nil
            lock.unlock()
        } else { lock.unlock(); protocolInstance.complete(response) }
    }
    func release() {
        lock.lock()
        let instance = pending, reply = pendingReply
        pending = nil; pendingReply = nil
        lock.unlock()
        if let instance, let reply { instance.complete(reply) }
    }
    func stopped(_ instance: AccountFixtureProtocol) {
        lock.lock(); defer { lock.unlock() }
        if pending === instance { pending = nil; pendingReply = nil }
    }
}

private final class AccountFixtureProtocol: URLProtocol {
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() { AccountBackend.shared.begin(self) }
    override func stopLoading() { AccountBackend.shared.stopped(self) }
    func complete(_ reply: AccountReply) {
        let response = HTTPURLResponse(url: request.url!, statusCode: reply.status, httpVersion: nil, headerFields: ["Content-Type": "application/json"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: try! JSONSerialization.data(withJSONObject: reply.object))
        client?.urlProtocolDidFinishLoading(self)
    }
}

enum OfflineAccountTransport {
    static let shared: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [AccountFixtureProtocol.self]
        return URLSession(configuration: configuration)
    }()
}

@main struct AccountActivityTests {
    @MainActor static var checks = 0
    @MainActor static func check(_ value: @autoclosure () -> Bool, _ label: String) {
        checks += 1
        precondition(value(), label)
    }
    @MainActor static func model() throws -> AppModel {
        SessionStore.session = nil
        let value = AppModel()
        try value.finishLogin(Session(token: "offline-account-A", courierID: "offline-A"))
        return value
    }
    @MainActor static func waitForPending() async {
        let limit = Date().addingTimeInterval(5)
        while !AccountBackend.shared.hasPending && Date() < limit { await Task.yield() }
        check(AccountBackend.shared.hasPending, "Offline transport must reach its delayed response")
    }
    @MainActor static func main() async throws {
        defer {
            ActivityTestDefaults.shared.removePersistentDomain(forName: ActivityTestDefaults.domain)
            OfflineAccountTransport.shared.invalidateAndCancel()
        }
        let backend = AccountBackend.shared
        backend.reset()
        let ordinary = try model()
        await ordinary.bootstrap()
        check(!ordinary.active && ordinary.shiftKnown, "An unchanged native bootstrap still publishes an inactive shift")
        check(backend.requestedPaths == ["/v1/courier/shops", "/v1/courier/courier", "/v1/courier/activity"], "Actual bootstrap and HTTP methods execute in order")

        for stale in [false, true] {
            backend.reset(hold: "/v1/courier/activity", active: stale)
            let current = try model()
            let work = Task { await current.bootstrap() }
            await waitForPending()
            current.observeWebsiteActivity(!stale)
            backend.release(); await work.value
            check(current.active == !stale && current.shiftKnown, "A delayed native read must preserve the newer website start or stop")
            check(current.error == nil, "Discarding a stale read must not add an error")
        }
        for path in ["/v1/courier/activity", "/v1/courier/shops"] {
            backend.reset(hold: path, status: 503)
            let current = try model()
            let work = Task { await current.bootstrap() }
            await waitForPending()
            current.observeWebsiteActivity(true)
            backend.release(); await work.value
            check(current.active && current.shiftKnown && current.error == nil, "An older bootstrap failure cannot erase a newer verified web activity")
        }
        backend.reset(hold: "/v1/courier/activity", active: true)
        let loggedOut = try model()
        let logoutWork = Task { await loggedOut.bootstrap() }
        await waitForPending()
        loggedOut.logout(); backend.release(); await logoutWork.value
        check(loggedOut.session == nil && !loggedOut.active && !loggedOut.shiftKnown, "Logout cannot be undone by an old native response")

        backend.reset(hold: "/v1/courier/activity", active: false)
        let switched = try model()
        let oldObservation = switched.activityObservation()
        let oldWork = Task { await switched.bootstrap() }
        await waitForPending()
        try switched.finishLogin(Session(token: "offline-account-B", courierID: "offline-A"))
        switched.observeWebsiteActivity(true)
        backend.release(); await oldWork.value
        check(switched.active && switched.shiftKnown && switched.session?.token == "offline-account-B", "A same-courier relogin rejects the old token's bootstrap")
        check(!switched.observeNativeActivity(false, ifCurrent: oldObservation), "An old token's poll cannot publish after relogin")
        let poll = switched.activityObservation()
        switched.observeWebsiteActivity(true) // same bool still confirms a newer response
        check(!switched.observeNativeActivity(false, ifCurrent: poll), "Even an unchanged website status fences a stale inactive poll")
        check(!switched.observeNativeActivity(nil, ifCurrent: poll), "A stale failed poll cannot change known=true to unknown")
        check(switched.active && switched.shiftKnown, "Stale polling preserves the current activity and validity")
        let currentPoll = switched.activityObservation()
        check(switched.observeNativeActivity(false, ifCurrent: currentPoll) && !switched.active && switched.shiftKnown, "A fresh native poll still updates an actual shift stop")
        check(switched.observeNativeActivity(nil, ifCurrent: switched.activityObservation()) && !switched.shiftKnown, "A current polling error still makes the shift unknown")
        switched.logout()
        check(!switched.observeNativeActivity(true, ifCurrent: currentPoll), "A poll cannot publish after logout")
        switched.observeWebsiteActivity(true)
        check(!switched.active && !switched.shiftKnown, "No-session callers cannot create a shift")
        switched.activateDemo()
        let demo = switched.activityObservation()
        switched.observeWebsiteActivity(true)
        check(!switched.observeNativeActivity(true, ifCurrent: demo) && !switched.active, "Real account observations cannot mutate the demo")
        print("Account activity: \(checks) checks passed; actual AppModel/bootstrap and API bodies, delayed success/failure, start/stop, same-status revision, poll, logout and token switch. No saved session or network.")
    }
}
