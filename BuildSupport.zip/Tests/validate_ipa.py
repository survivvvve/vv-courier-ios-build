"""Inspect the distributable without running or signing it."""
import hashlib
import json
from pathlib import Path
import plistlib
import sys
import zipfile

path = Path(sys.argv[1])
with zipfile.ZipFile(path) as archive:
    assert archive.testzip() is None, "Corrupt IPA"
    names = archive.namelist()
    plists = [n for n in names if n.count('/') == 2 and n.startswith('Payload/') and n.endswith('.app/Info.plist')]
    assert len(plists) == 1, "Expected one application"
    info = plistlib.loads(archive.read(plists[0]))
    app = plists[0].rsplit('/', 1)[0]
    assert info['CFBundleIdentifier'] == 'ru.local.vvcourier.ios'
    assert info['CFBundleShortVersionString'] == '1.2.4'
    assert info['CFBundleVersion'] == '16'
    assert info['CFBundleDisplayName'].isascii() and info['CFBundleName'].isascii(), "SideStore requires ASCII registration names"
    assert info['CFBundleSupportedPlatforms'] == ['iPhoneOS'], "Simulator app must not be distributed"
    assert info.get('NSBluetoothAlwaysUsageDescription')
    assert info.get('NSCameraUsageDescription')
    assert info.get('NSPhotoLibraryUsageDescription')
    assert info.get('NSPhotoLibraryAddUsageDescription')
    assert any(n.endswith('/income-background.png') for n in names), 'Illustrated income poster background missing'
    assert any(n.endswith('/OriginalRuntime.js') for n in names), 'Native web bridge missing'
    assert any(n.endswith('/OriginalShiftReadiness.js') for n in names), 'Shift readiness bridge missing'
    assert any(n.endswith('/OriginalDiagnostics.js') for n in names), 'Web error recovery bridge missing'
    assert any(n.endswith('/OriginalCashChange.js') for n in names), 'Cash change hint missing'
    assert any(n.endswith('/Capacitor-LICENSE.txt') for n in names), 'SDK fixture license missing'
    assert 'bluetooth-central' in info.get('UIBackgroundModes', [])
    assert info.get('NSCameraUsageDescription') and info.get('NSLocationWhenInUseUsageDescription')
    assert app + '/' + info['CFBundleExecutable'] in names
    assert app + '/Assets.car' in names, "Missing icon assets"
    assert not any(n.rsplit('/', 1)[-1].lower() in ['.env', 'ios_development_session.json', 'sessions.json'] for n in names)
result = {'version': info['CFBundleShortVersionString'], 'build': info['CFBundleVersion'],
          'bundle': info['CFBundleIdentifier'], 'display_name': info['CFBundleDisplayName'],
          'minimum_ios': info['MinimumOSVersion'], 'platforms': info['CFBundleSupportedPlatforms'],
          'bluetooth_background': True, 'bytes': path.stat().st_size,
          'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
output = path.with_name('IPA-Validation.json')
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
