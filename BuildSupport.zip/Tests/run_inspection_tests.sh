#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
INSPECTION_TEST_DIR=$(mktemp -d)
trap 'rm -rf "$INSPECTION_TEST_DIR"' EXIT
python3 - "$INSPECTION_TEST_DIR" <<'PY'
from pathlib import Path
import sys
out=Path(sys.argv[1])
(out/'Inspection.swift').write_text(Path('Inspection.swift').read_text().split('#if canImport(SwiftUI)')[0])
for name,marker in [('Terminal','struct TerminalView'),('Schedule','struct ScheduleView')]:
    text=Path(name+'.swift').read_text().split(marker)[0].replace('import SwiftUI','import Foundation').replace('import UIKit\n','').replace('import CoreImage.CIFilterBuiltins\n','')
    (out/(name+'.swift')).write_text(text)
PY
xcrun swiftc -swift-version 5 Models.swift ParcelAddress.swift ParcelMapModels.swift ParcelMapPayload.swift ColdControlSignal.swift CourierAPI.swift OrderActions.swift LocationService.swift QueueModels.swift "$INSPECTION_TEST_DIR"/*.swift Tests/InspectionTests.swift -o "$INSPECTION_TEST_DIR/InspectionTests"
"$INSPECTION_TEST_DIR/InspectionTests"
