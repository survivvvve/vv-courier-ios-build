import Foundation
import JavaScriptCore

@main enum OriginalCashChangeTests {
    static func main() throws {
        let context = JSContext()!
        var failure: String?
        context.exceptionHandler = { _, value in failure = value?.toString() }
        func run(_ text: String) {
            failure = nil
            context.evaluateScript(text)
            if let failure { fatalError(failure) }
        }
        run("""
        var window=globalThis, location={href:'https://courier.vkusvill.ru/order?id_parcel=22421'};
        var currentToken='offline-only',currentRoute='/order?id_parcel=22421';
        var removed=0,frames=[];
        var document={getElementById(){return null},querySelectorAll(){return []},body:null};
        var requestAnimationFrame=f=>{frames.push(f);return frames.length},cancelAnimationFrame=()=>{};
        function assert(v,m){if(!v)throw new Error(m)}
        """)
        // JavaScriptCore alone has no URL/Headers. These small stand-ins model
        // only the route and request metadata used in the offline observer.
        run("""
        class URL {constructor(raw,base){const u=String(raw).split('?');this.pathname=u[0].replace(/^https:\\/\\/[^/]+/,'');this.origin=u[0].startsWith('https://delivery-api.vkusvill.ru')?'https://delivery-api.vkusvill.ru':'https://courier.vkusvill.ru';this.searchParams={get:key=>{let q=(u[1]||'').split('&').find(v=>v.startsWith(key+'='));return q?q.split('=')[1]:null}}}}
        class Headers{constructor(raw){this.raw=raw}get(key){return this.raw[key]||null}}
        """)
        run(try String(contentsOfFile:"Resources/OriginalCashChange.js",encoding:.utf8))
        run("""
        var helper=__vvInstallCashChange({getToken:()=>currentToken,route:()=>currentRoute});
        var parcel={id_parcel:'22421',pay_way:4,pay_summ:'2500',comment:'Нужна сдача с 5000 рублей',comment_courier_address:'Сдача с 10000',reward:138};
        const title=p=>helper.calculate(p)?.title?.replace(/\\u00a0|\\u202f/g,' ');
        assert(title(parcel)==='Сдача 2 500 ₽','Use buyer comment/pay_summ, never courier note/reward');
        assert(title({...parcel,pay_way:0})===undefined,'Online never needs cash');
        assert(title({...parcel,pay_way:3})===undefined,'Terminal never needs cash');
        assert(title({...parcel,pay_way:undefined})===undefined,'Missing method is not cash');
        assert(title({...parcel,parcel_status:'delivered',pay_way_fact:3})===undefined,'Actual terminal method supersedes preferred cash');
        assert(title({...parcel,pay_way:3,parcel_status:'delivered',pay_way_fact:4})==='Сдача 2 500 ₽','Actual archived cash');
        assert(title({...parcel,comment:'Оставить у двери'})==='Без сдачи','No request means exact cash');
        assert(title({...parcel,comment:'Без сдачи'})==='Без сдачи','Explicit exact cash');
        assert(title({...parcel,comment:'Сдача с 5000 или 10000'}).startsWith('Сдачу уточни'),'Alternative cash ambiguous');
        assert(title({...parcel,comment:'Сдача с 5000, сдача с 10000'}).startsWith('Сдачу уточни'),'Conflicting requests');
        assert(title({...parcel,comment:'Сдача с 5000. Или 10000'}).startsWith('Сдачу уточни'),'Alternative amount after sentence boundary');
        assert(title({...parcel,comment:'Сдача с 5000 / 10000'}).startsWith('Сдачу уточни'),'Slash alternative is ambiguous');
        assert(title({...parcel,comment:'Сдача с 1000'}).startsWith('Сдачу уточни'),'Insufficient tendered is not negative change');
        assert(title({...parcel,comment:'Нужна сдача'}).startsWith('Сдачу уточни'),'Missing amount is not exact cash');
        assert(title({...parcel,comment:'Нужна сдача с 5 000 ₽'})==='Сдача 2 500 ₽','Space grouping');
        assert(title({...parcel,comment:'Сдача с 5 тыс. рублей'})==='Сдача 2 500 ₽','Thousands multiplier');
        assert(title({...parcel,comment:'Сдача с 5000,50',pay_summ:'2499,99'})==='Сдача 2 500,51 ₽','Integer kopecks, no floating-point subtraction');
        assert(title({...parcel,comment:'Код 5000, покупка 2500'})==='Без сдачи','Unrelated numbers ignored');
        assert(title({...parcel,comment:'',comment_client:'4313'})==='Без сдачи','Delivery instruction code is not free customer note');
        var init={method:'POST',body:JSON.stringify({id_parcel:'22421'}),headers:{Authorization:'Bearer offline-only'}};
        var ticket=helper.begin('https://delivery-api.vkusvill.ru/v2/courier/get_parcel',init);
        assert(!!ticket,'Actual detail endpoint recognized');
        assert(helper.begin('https://delivery-api.vkusvill.ru/v1/courier/get_parcels_assembled_ext',init)===undefined,'Feed responses ignored');
        var clones=0;
        currentRoute='/order?id_parcel=34233';
        helper.observe(ticket,{ok:true,clone(){clones++;throw Error('Must not read stale order')}});
        assert(clones===0,'Late response cannot attach to next order');
        currentRoute='/order?id_parcel=22421';
        ticket=helper.begin('https://delivery-api.vkusvill.ru/v2/courier/get_parcel',init);
        currentToken='other-account';
        helper.observe(ticket,{ok:true,clone(){clones++;throw Error('Must not read old account')}});
        assert(clones===0,'Old account response discarded');
        assert(helper.begin('https://delivery-api.vkusvill.ru/v2/courier/get_parcel',init)===undefined,'Stale authorization header fenced');
        helper.dispose();
        assert(helper.begin('https://delivery-api.vkusvill.ru/v2/courier/get_parcel',init)===undefined,'Disposed document cannot observe');
        """)
        print("Original cash change: 25 offline buyer/payment/kopeck/ambiguity/request-identity cases passed; no network.")
    }
}
