import Foundation
import JavaScriptCore

@main struct OriginalShiftReadinessTests {
    static func main() throws {
        let context = JSContext()!
        var exception: String?
        context.exceptionHandler = { _, error in exception = error?.toString() }
        let parseURL: @convention(block) (String, String) -> String = { text, base in
            guard let baseURL = URL(string: base), let url = URL(string: text, relativeTo: baseURL)?.absoluteURL,
                  let parts = URLComponents(url: url, resolvingAgainstBaseURL: true),
                  let scheme = parts.scheme?.lowercased(), let host = parts.host?.lowercased() else { return "null" }
            let port = parts.port.flatMap { ($0 == 443 && scheme == "https") || ($0 == 80 && scheme == "http") ? nil : $0 }
            let value: [String: Any] = ["href": url.absoluteString, "hostname": host, "origin": "\(scheme)://\(host)\(port.map { ":\($0)" } ?? "")",
                                       "pathname": parts.percentEncodedPath.isEmpty ? "/" : parts.percentEncodedPath,
                                       "search": parts.percentEncodedQuery.map { "?\($0)" } ?? "",
                                       "username": parts.user ?? "", "password": parts.password ?? ""]
            return String(data: try! JSONSerialization.data(withJSONObject: value), encoding: .utf8)!
        }
        context.setObject(parseURL, forKeyedSubscript: "__parseURL" as NSString)
        @discardableResult func evaluate(_ source: String) throws -> JSValue {
            exception = nil
            let value = context.evaluateScript(source)!
            if let exception { throw NSError(domain: "OriginalShiftReadinessTests", code: 1, userInfo: [NSLocalizedDescriptionKey: exception]) }
            return value
        }
        var checks = 0
        func check(_ source: String, _ label: String) throws {
            checks += 1
            guard try evaluate(source).toBool() else { fatalError(label) }
        }
        try evaluate("""
        var window=globalThis,self=globalThis,events=[],routeValue='/main/my-tab',secret='PRIVATE_TOKEN_A';
        var currentToken=secret,denyToken=false,timers=new Map(),timerSerial=0,domListeners={},globalListeners={};
        var location={href:'https://courier.vkusvill.ru/main/my-tab',pathname:'/main/my-tab',search:''};
        class URL { constructor(value,base=location.href){const parsed=JSON.parse(__parseURL(String(value),base));if(!parsed)throw new TypeError('Invalid URL');Object.assign(this,parsed)}toString(){return this.href} }
        class Request {constructor(url,init={}){this.url=String(url);this.method=init.method||'GET'}}
        class Element {constructor(localName,text='',parent=null){this.localName=localName;this.textContent=text;this.parentElement=parent;this.disabled=false}closest(name){return this.localName===name?this:this.parentElement?.closest(name)}}
        var document={readyState:'loading',
          addEventListener(name,fn,capture){(domListeners[name]||(domListeners[name]=[])).push({fn,capture})},
          removeEventListener(name,fn){domListeners[name]=(domListeners[name]||[]).filter(x=>x.fn!==fn)}};
        function addEventListener(name,fn){(globalListeners[name]||(globalListeners[name]=[])).push(fn)}
        function removeEventListener(name,fn){globalListeners[name]=(globalListeners[name]||[]).filter(x=>x!==fn)}
        function setTimeout(fn){const id=++timerSerial;timers.set(id,fn);return id}function clearTimeout(id){timers.delete(id)}
        function flushTimers(){const work=Array.from(timers.values());timers.clear();for(const fn of work)fn()}
        var queueMicrotask=fn=>Promise.resolve().then(fn);
        function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}}
        function button(text='Начать смену'){return new Element('ion-button',text)}
        function tap(text='Начать смену',shadow=false){const host=button(text),target=shadow?new Element('button',text,host):host;const e={target,blocked:false,preventDefault(){this.blocked=true},stopImmediatePropagation(){this.stopped=true},composedPath(){return shadow?[target,host,document]:[host,document]}};for(const item of(domListeners.click||[]).slice()){item.fn(e);if(e.stopped)break}return e}
        var helper;
        function install(){helper?.dispose();events=[];routeValue='/main/my-tab';currentToken=secret;denyToken=false;helper=__vvInstallShiftReadiness({send:e=>events.push(e),getToken:()=>{if(denyToken)throw Error('PRIVATE_TOKEN_B');return currentToken},route:()=>routeValue});return helper}
        const TASKS='https://delivery-api.vkusvill.ru/v1/courier/tasks';
        function begin(input=TASKS,init={method:'POST'}){return helper.begin(input,init)}
        function bodyResponse(status=200){const body=deferred();let calls=0;const response={status,json(){calls++;return body.promise},get clone(){throw Error('Must never clone')}};return{response,body,calls:()=>calls}}
        function load(ticket=begin(),data=[[{id_task:124}]],status=200){const job=bodyResponse(status);helper.response(ticket,job.response);const promise=job.response.json();job.body.resolve(data);return{...job,promise}}
        """)
        try evaluate(String(contentsOfFile: "Resources/OriginalShiftReadiness.js", encoding: .utf8))
        try check("typeof __vvInstallShiftReadiness==='function' && events.length===0", "Loading helper must not fetch or send anything")
        try evaluate("install();var waiting=tap();")
        try check("waiting.blocked && waiting.stopped && events[0].phase==='loading'", "Block the original early-start race before a task request exists")
        try check("Object.keys(events[0]).sort().join(',')==='kind,phase' && events[0].kind==='shift-readiness'", "Native contract contains no token, route, identifiers or raw data")
        try evaluate("routeValue='/order';var unrelated=tap();routeValue='/main/profile-tab';var closeShift=tap('Закончить смену');")
        try check("!unrelated.blocked && !closeShift.blocked", "Other routes and actions keep their original behavior")
        try evaluate("var shadowClick=tap('Готов брать заказы',true);")
        try check("shadowClick.blocked && shadowClick.stopped", "Guard a real Ionic shadow-DOM composed path")
        try evaluate("install();var ignored=[begin(TASKS,{method:'GET'}),begin(TASKS+'?debug=1'),begin('https://delivery-api.vkusvill.ru/v2/courier/tasks'),begin('https://evil.example/v1/courier/tasks'),begin('https://delivery-api.vkusvill.ru:444/v1/courier/tasks'),begin('https://user:password@delivery-api.vkusvill.ru/v1/courier/tasks')];")
        try check("ignored.every(x=>x===undefined)", "Only the exact POST tasks endpoint affects readiness")
        try check("helper.begin(new Request(TASKS))===undefined && helper.begin(new Request(TASKS,{method:'POST'}),{method:'GET'})===undefined", "Honor Request method and explicit init override")
        try evaluate("var urlTicket=begin(new URL(TASKS));var requestTicket=begin(new Request(TASKS,{method:'POST'}),undefined);")
        try check("!!urlTicket && !!requestTicket", "Support URL and Request input without changing fetch arguments")

        try evaluate("install();var ticket=begin(),slow=bodyResponse();var originalParser=slow.response.json;helper.response(ticket,slow.response);var samePromise=slow.response.json();var pending=tap();")
        try check("samePromise===slow.body.promise && slow.calls()===1 && pending.blocked", "Preserve SDK JSON Promise identity and wait for slow body, not headers")
        try evaluate("slow.body.resolve([[{id_task:124}]]);var beforeTurn=tap();")
        try check("beforeTurn.blocked && timers.size===1", "Wait for the SDK microtask chain after parsed JSON")
        try evaluate("flushTimers();var afterTurn=tap();")
        try check("!afterTurn.blocked", "Enable only after canonical task data and a deferred next turn")
        try evaluate("install();load(undefined,[]);")
        try evaluate("flushTimers();")
        try check("!tap().blocked", "An empty canonical task response is valid")
        for (index, payload) in ["{}", "{message:'PRIVATE_ADDRESS'}", "{business_error:77}", "{error:'PRIVATE_TOKEN_B'}", "[null]", "[[null]]", "[[{id_task:null}]]", "[[{id_task:'PRIVATE_TOKEN_B'}]]", "[[{id_task:1.5}]]"].enumerated() {
            try evaluate("install();load(undefined,\(payload));")
            try evaluate("flushTimers();var malformed=tap();")
            try check("malformed.blocked && events[0].phase==='failed' && events[0].status===200 && !JSON.stringify(events).includes('PRIVATE_')", "Reject malformed/business task response \(index) without leaking its content or bypassing checks")
        }
        try evaluate("install();var http=bodyResponse(429),httpTicket=begin();var httpParser=http.response.json;helper.response(httpTicket,http.response);var rateLimited=tap();")
        try check("http.response.json===httpParser && rateLimited.blocked && events[0].phase==='failed' && events[0].status===429", "HTTP failure keeps the response parser intact and reports only status")
        for status in [204, 205, 206, 400, 403, 500] {
            try evaluate("install();var unsupported=bodyResponse(\(status));helper.response(begin(),unsupported.response);tap();")
            try check("events[0].phase==='failed' && events[0].status===\(status)", "Do not confuse HTTP \(status) with the SDK's fulfilled task state")
        }
        try evaluate("install();var networkTicket=begin();helper.rejected(networkTicket);tap();")
        try check("events[0].phase==='failed' && events[0].status===0", "Network rejection is represented by status zero")
        try evaluate("install();var bad=bodyResponse(),badTicket=begin();helper.response(badTicket,bad.response);var rejection=Error('PRIVATE_ADDRESS'),rejectedIdentity=false;var rejectedPromise=bad.response.json();rejectedPromise.catch(e=>rejectedIdentity=e===rejection);bad.body.reject(rejection);")
        try evaluate("tap();")
        try check("rejectedPromise===bad.body.promise && rejectedIdentity && events[0].phase==='failed'", "Keep the actual SDK JSON rejection object and Promise")
        try evaluate("install();var thrown=Error('PRIVATE_TOKEN_B'),sync={status:200,json(){throw thrown}},syncTicket=begin();helper.response(syncTicket,sync);var syncIdentity=false;try{sync.json()}catch(e){syncIdentity=e===thrown}tap();")
        try check("syncIdentity && events[0].phase==='failed'", "Preserve synchronous parser throws")
        try evaluate("install();var frozen=Object.freeze({status:200,json(){return Promise.resolve([])}}),frozenParser=frozen.json;helper.response(begin(),frozen);tap();")
        try check("frozen.json===frozenParser && events[0].phase==='failed'", "A non-extensible response fails observation without breaking its parser")

        try evaluate("install();var oldTicket=begin(),old=bodyResponse();helper.response(oldTicket,old.response);old.response.json();var newerTicket=begin();helper.rejected(newerTicket);old.body.resolve([]);flushTimers();tap();")
        try check("events[0].phase==='failed' && events[0].status===0", "A stale successful response cannot override a newer failed request")
        try evaluate("install();var staleFailure=begin();load(begin());")
        try evaluate("flushTimers();helper.rejected(staleFailure);")
        try check("!tap().blocked && events.length===0", "A stale rejection cannot invalidate the newer successful task load")
        try evaluate("install();var accountTicket=begin(),accountJob=bodyResponse();helper.response(accountTicket,accountJob.response);accountJob.response.json();currentToken='PRIVATE_TOKEN_B';helper.accountChanged();accountJob.body.resolve([]);flushTimers();tap();")
        try check("events[0].phase==='loading'", "An old account's response cannot enable the new account")
        try evaluate("install();load();")
        try evaluate("currentToken=null;helper.accountChanged();currentToken=secret;helper.accountChanged();flushTimers();tap();")
        try check("events[0].phase==='loading'", "A logout invalidates even an already scheduled ready callback for the same token")
        try evaluate("install();load();")
        try evaluate("flushTimers();denyToken=true;var denied=tap();")
        try check("denied.blocked && events[0].phase==='failed'", "A throwing token getter cannot retain ready state")
        try evaluate("install();load();")
        try evaluate("helper.dispose();flushTimers();var disposedTap=tap();")
        try check("!disposedTap.blocked && events.length===0 && timers.size===0", "Disposal removes listeners and invalidates pending callbacks")
        try check("!JSON.stringify(events).includes('PRIVATE_')", "Never emit private token or body content")

        // Runtime integration, using an entirely synthetic SDK contract. The
        // real-source 6.16.2 replay stays local and is not shipped in this repo.
        try evaluate("""
        helper.dispose();events=[];domListeners={};timers.clear();
        var storageError=Error('PRIVATE_STORAGE_ERROR'),storageDenied=false,failWrite=false;
        class Storage {constructor(){this.data={}}getItem(key){if(storageDenied)throw storageError;return this.data[key]??null}setItem(key,value){if(failWrite)throw storageError;this.data[key]=String(value);return 'set-result'}removeItem(key){delete this.data[key];return 'remove-result'}clear(){this.data={};return 'clear-result'}}
        var localStorage=new Storage();localStorage.setItem('CapacitorStorage.token_courier',secret);
        window.__vvFixtureRoute='/main/my-tab';
        window.webkit={messageHandlers:{vvNative:{postMessage:e=>events.push(e)}}};
        var fetchCalls=[],fetchJob=bodyResponse(),fetchError=null,fetchThis;
        window.fetch=function(...args){fetchCalls.push(args);fetchThis=this;return fetchError?Promise.reject(fetchError):Promise.resolve(fetchJob.response)};
        var originalFetch=window.fetch;
        """)
        try evaluate(String(contentsOfFile: "Resources/OriginalRuntime.js", encoding: .utf8))
        try evaluate("var returnedResponse;var fetchInput=new URL(TASKS);var fetchInit={method:'POST',body:'synthetic-only'};window.fetch(fetchInput,fetchInit).then(r=>returnedResponse=r);")
        try check("returnedResponse===fetchJob.response && fetchCalls.length===1 && fetchCalls[0][0]===fetchInput && fetchCalls[0][1]===fetchInit", "Return the exact response and pass original fetch arguments unchanged")
        try evaluate("events=[];storageDenied=true;fetchError=Error('PRIVATE_NETWORK_ERROR');var fetchRejectedIdentity=false;window.fetch('/unrelated').catch(e=>fetchRejectedIdentity=e===fetchError);")
        try check("fetchCalls.length===2 && fetchRejectedIdentity", "Throwing Storage observer must not prevent fetch or replace its rejection")
        try evaluate("storageDenied=false;fetchError=null;var writeIdentity=false;failWrite=true;try{localStorage.setItem('x','y')}catch(e){writeIdentity=e===storageError}failWrite=false;")
        try check("writeIdentity && localStorage.setItem('x','y')==='set-result'", "Preserve original Storage return and exception identity")
        try evaluate("events=[];fetchJob={response:{status:200,ok:true,json(){return Promise.resolve({res:1})},clone(){return {json:()=>Promise.resolve({res:1})}}}};var nonTaskParser=fetchJob.response.json;var accountInputs=['https://delivery-api.vkusvill.ru/v1/courier/activity',new URL('https://delivery-api.vkusvill.ru/v1/courier/activity'),new Request('https://delivery-api.vkusvill.ru/v1/courier/activity')];for(const input of accountInputs)window.fetch(input);")
        try check("events.filter(x=>x.kind==='account').length===3 && fetchJob.response.json===nonTaskParser", "String, URL and Request account observation preserves unrelated parsers")

        try evaluate("""
        // The SDK loads feature tasks at bootstrap, then dispatches its own
        // required checks. Starting is always a later, explicit user action.
        var sdk={loaded:false,checks:[],shiftPosts:0,confirmations:0,photoChecks:0,genericErrors:0};
        async function sdkLoad(){const r=await fetch(TASKS,{method:'POST',body:'synthetic-only'});const data=await r.json();const taskIDs=(data[0]||[]).map(t=>Number(t.id_task));sdk.checks=taskIDs.includes(124)?['photo']:[];sdk.loaded=true;return taskIDs}
        function sdkClick(){const event=tap();if(event.blocked)return;if(!sdk.loaded){sdk.genericErrors++;return}if(sdk.checks.includes('photo')){sdk.photoChecks++;return}sdk.confirmations++}
        var buttonBefore=button();var disabledBefore=buttonBefore.disabled;
        events=[];fetchJob=bodyResponse();var loadFinished=false;sdkLoad().then(()=>loadFinished=true);sdkClick();
        """)
        try check("sdk.shiftPosts===0 && sdk.confirmations===0 && sdk.genericErrors===0 && events.some(x=>x.kind==='shift-readiness'&&x.phase==='loading')", "Early tap is blocked without sending start or showing upstream's misleading generic error")
        try evaluate("fetchJob.body.resolve([[{id_task:124}]]);")
        try check("loadFinished && sdk.loaded && sdk.checks[0]==='photo' && sdk.photoChecks===0", "Preserve the SDK's own task mapping and checks before ready")
        try evaluate("sdkClick();")
        try check("sdk.photoChecks===0 && sdk.shiftPosts===0", "Do not release the guard in the parser/fulfilled microtask turn")
        try evaluate("flushTimers();")
        try check("sdk.photoChecks===0 && sdk.confirmations===0 && sdk.shiftPosts===0", "Ready never replays the previous tap or automatically starts a shift")
        try evaluate("sdkClick();")
        try check("sdk.photoChecks===1 && sdk.shiftPosts===0 && sdk.confirmations===0", "A new explicit tap still goes through mandatory photo control")
        try evaluate("sdk.checks=[];sdkClick();")
        try check("sdk.confirmations===1 && sdk.shiftPosts===0 && buttonBefore.disabled===disabledBefore", "Preserve confirmation and original disabled state")
        try evaluate("events=[];fetchJob=bodyResponse();sdkLoad().catch(()=>{});localStorage.removeItem('CapacitorStorage.token_courier');localStorage.setItem('CapacitorStorage.token_courier',secret);fetchJob.body.resolve([]);flushTimers();sdkClick();")
        try check("events.some(x=>x.kind==='shift-readiness'&&x.phase==='loading') && sdk.confirmations===1", "Runtime logout hook synchronously invalidates old same-token requests")
        try evaluate("var readinessEvents=events.filter(x=>x.kind==='shift-readiness');")
        try check("readinessEvents.every(x=>typeof x.documentID==='string' && Object.keys(x).every(k=>['kind','phase','status','documentID'].includes(k))) && !JSON.stringify(readinessEvents).includes('PRIVATE_')", "Native messages contain only the bounded contract and runtime document identity")
        try evaluate("window.__vvCompanion.dispose();")
        print("Original shift readiness: \(checks) offline checks passed; no network, account, shift, or order actions.")
    }
}
