# Courier data audit for 1.0

Verified locally with offline URLProtocol fixtures and Foundation/CoreLocation typechecking. No SMS, live VV mutation, GPS request, real receipt, payment or cold-control photo was sent.

Fixed concrete defects:

- `CourierPagination` now accounts for distinct parcel IDs across feed, archive and day totals. Category dictionaries are not scalar totals; a short page with a known larger total continues. Repeated IDs, missing IDs, contradictory totals, an empty incomplete page and the load limit fail explicitly instead of saving/rendering a truncated result. Full-page JSON copies formerly retained by day reports were removed.
- `integer` and `finiteNumber` reject nonfinite/overflow/malformed input. Queue counters no longer trap converting NaN/huge doubles. Unknown terminal status no longer defaults to assigned status0. Malformed financial values cannot silently overwrite a saved total with zero.
- Reports use one explicit Moscow reference date for every request/label in the period. Customer planned delivery slots are not completion times. Idle thresholds compare seconds before rounding to minutes. Incomplete/failed loads retain the previous account-scoped cache. Receipt lists are reset on identity changes and refreshed on a new Moscow day.
- API auth/rate errors never trigger retries or SMS. Cancellation is checked before transport and after it; unknown nonzero business errors reject as errors. Cold-control signals carry a non-secret session fingerprint; stale-token/unauthenticated responses cannot update the current session's assignment.
- Receipt, payment, terminal, archive, schedule and cold-control callbacks capture their originating API/identity and reject stale updates after awaits. Camera/gallery callbacks cannot copy an old identity's image into a new one. Booking/terminal actions guard identity/scope after readback before UI changes.
- Lost payment responses use read-only delivered-state recovery without repeating close. Photo attachment uncertainty blocks another attach until a status read; uploaded IDs and JPEG drafts remain account-scoped. Cold-control uncertainty persists as a status-check requirement across closing/reopening, without persisting the photo or pretending completion.
- A cancelled location consumer releases its pending continuation, rather than keeping the next action blocked until the25s timeout. Coordinate aliases skip empty/malformed primary fields. Invalid absolute schedule intervals cannot become negative intervals by rollover.

Regression commands:

```sh
bash Tests/run_core_tests.sh
bash Tests/run_payment_tests.sh
bash Tests/run_queue_tests.sh
```

Core additionally runs `APIFaultTests`: 401/429/503, malformed200/business errors, cancellation before/during transport, cold identity fingerprints, pagination faults, saved-report preservation, separate accounts, scalar/category totals, Moscow-midnight anchoring, idle boundaries, net/tax and missing actual completion times. Existing address/map/comments/cash/queue and strict cold-control fixtures remain enabled. Main order labels are last5 digits; suborder labels retain the full server number as implemented in0.6.

No TTL response cache or broad request coalescing was added: it would require a separate concurrency verification surface and was not needed to correct these defects. Native camera/GPS permissions, real backend timing, actual payments/receipts and physical courier shift/order flows remain device/account checks. iOS UI compilation and simulator navigation are verified by the release CI.
