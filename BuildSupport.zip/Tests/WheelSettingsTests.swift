import Foundation

@main enum WheelSettingsTests {
    static var checks = 0
    static func check(_ condition: @autoclosure () -> Bool, _ message: String) { checks += 1; guard condition() else { fatalError(message) } }
    static func data(_ hex: String) -> Data { Data(stride(from: 0, to: hex.count, by: 2).map { i in let a = hex.index(hex.startIndex, offsetBy: i); return UInt8(hex[a..<hex.index(a, offsetBy: 2)], radix: 16)! }) }
    static func packet(page: Data, marker: UInt8 = 3, now: Date) -> WheelDecodedPacket {
        var b = [UInt8](repeating: 0, count: 46)
        b[0...3] = [0xDC,0x5A,0x5C,UInt8(46 + page.count)]
        b[4...7] = [0x38,0x72,0,0] //144.5V, stopped
        b[28...29] = [0x17,0x7A] //6010
        b[40...43] = [0x4C,0x43,marker,0x23]
        b += page
        let crc = WheelFrameDecoder.crc32(b)
        b += [UInt8(truncatingIfNeeded: crc >> 24),UInt8(truncatingIfNeeded: crc >> 16),UInt8(truncatingIfNeeded: crc >> 8),UInt8(truncatingIfNeeded: crc)]
        var decoder = WheelFrameDecoder(); return decoder.appendPackets(Data(b), at: now).first!
    }
    static func main() throws {
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        let root = try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))) as! [String: Any]
        let rows = root["settings"] as! [[String: Any]]
        let cases: [String: (WheelSettingKey,Int)] = ["hardness":(.hardness,83),"pedal_angle":(.pedalAngle,-36),"tiltback":(.tiltbackSpeed,42),"tiltback_disabled":(.tiltbackSpeed,200),"pwm":(.pwmTiltback,82),"pwm_disabled":(.pwmTiltback,200),"alarm":(.speedAlarm,35),"alarm_disabled":(.speedAlarm,200),"brightness":(.displayBrightness,70),"transport":(.transport,1),"units":(.units,1),"low_battery":(.lowBattery,1),"voltage_trim":(.voltageTrim,-5),"high_speed":(.highSpeed,1),"lateral_cutoff":(.lateralCutoff,60),"key_volume":(.keyVolume,60),"charge":(.chargeLimit,1512),"stock_assist":(.stockAssist,64),"dip_compensation":(.dipCompensation,25)]
        for row in rows {
            let name = row["setting"] as! String
            if let (key,value) = cases[name] {
                let plan = try WheelSettingsPlan(changes:[key:value],current:[:],token:1234)
                check(plan.frames == [data(row["frame"] as! String)], "Exact-image command fixture \(name)")
                let readback = packet(page:data(row["page8"] as! String),now:now).settings!
                check(readback.values[key] == value, "Actual firmware page8 roundtrip \(name)")
                var snapshot = WheelSettingsSnapshot(); snapshot.merge(readback)
                check(snapshot.value(key,at:now) == value, "Fresh \(name)")
                check(snapshot.value(key,at:now.addingTimeInterval(16)) == nil, "Stale \(name) does not permit writes")
                check(!snapshot.confirms([key:value],after:now,oldPIDGeneration:nil), "Same-age old readback not an acknowledgment")
            }
        }
        let assistRow = rows.first { $0["setting"] as? String == "custom_assist" }!
        let assist = packet(page:data(assistRow["page80"] as! String),now:now).settings!
        let assistExpected: [WheelSettingKey:Int] = [.assistEnabled:1,.assistAcceleration:87,.assistAccelerationLimit:35,.assistBraking:62,.assistBrakingLimit:51]
        check(assistExpected.allSatisfy { assist.values[$0.key] == $0.value }, "Actual packed custom-assist readback")
        let assistPlan = try WheelSettingsPlan(changes:[.assistAcceleration:88],current:assist.values,token:1234)
        check(assistPlan.frames.count == 6 && Array(assistPlan.frames.first!)[8] == 0x31 && Array(assistPlan.frames.first!)[10] == 0, "Assist is disabled before changing profile")
        check(Array(assistPlan.frames.last!)[8] == 0x31 && Array(assistPlan.frames.last!)[10] == 1, "Assist enabled last")
        let pidRow = rows.first { $0["setting"] as? String == "pid_transaction" }!
        let pid = packet(page:data(pidRow["page80"] as! String),now:now).settings!
        check(pid.values[.pidEnabled] == 1 && pid.values[.pidKa] == 2280 && pid.values[.pidKg] == 1170 && pid.values[.pidKc] == -300, "Actual committed PID signed coefficients")
        check(pid.pidGeneration == 1 && pid.pidResult == 1, "PID result/generation")
        let plan = try WheelSettingsPlan(changes:[.pidKc:-301],current:pid.values,token:1234)
        check(plan.frames.count == 6 && Array(plan.frames.first!)[8] == 0x10 && Array(plan.frames.last!)[8] == 0x15, "PID begin/commit transaction")
        check(Array(plan.frames.first!)[10...11] == [210,4] && Array(plan.frames.last!)[10...11] == [210,4], "Same LE16 transaction token")
        var snapshot = WheelSettingsSnapshot(); snapshot.merge(pid)
        let expected = [WheelSettingKey.pidEnabled:1,.pidKa:2280,.pidKg:1170,.pidKc:-300]
        check(snapshot.confirms(expected,after:now.addingTimeInterval(-1),oldPIDGeneration:0), "New generation plus matched coefficients confirms PID")
        check(!snapshot.confirms(expected,after:now.addingTimeInterval(-1),oldPIDGeneration:1), "Repeated generation cannot confirm a new PID transaction")
        let off = try WheelSettingsPlan(changes:[.pidEnabled:0],current:pid.values,token:1234)
        check(off.expected == [.pidEnabled:0], "Stock PID mode does not promise saved override gains")
        check(packet(page:data(pidRow["page80"] as! String),marker:2,now:now).settings == nil, "Wrong custom schema cannot decode settings")
        var unknown = data(assistRow["page80"] as! String); unknown[0] = 9
        check(packet(page:unknown,now:now).settings == nil, "Other BMS page is not settings")
        var sentinel = data(rows[0]["page8"] as! String); sentinel[4] = 128
        let invalid = packet(page:sentinel,now:now).settings!
        var previous = WheelSettingsSnapshot(); previous.merge(packet(page:data(rows[0]["page8"] as! String),now:now).settings!); previous.merge(invalid)
        check(previous.value(.hardness,at:now) == nil, "Sentinel invalidates an old value instead of displaying false zero")
        for key in WheelSettingKey.allCases { check(!key.accepts(key.range.lowerBound - 1), "Lower bound \(key.rawValue)"); check(!key.accepts(key.range.upperBound + 1), "Upper bound \(key.rawValue)") }
        do { _ = try WheelSettingsPlan(changes:[.chargeLimit:1520],current:[:],token:1); fatalError("Overvoltage setting accepted") } catch is WheelSettingsError { checks += 1 }
        print("Wheel settings: \(checks) checks passed against exact-image receiver/readback fixtures.")
    }
}
