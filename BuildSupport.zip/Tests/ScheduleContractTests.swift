import Foundation
import CoreFoundation

// Golden request shape: first-party Wte() -> ste() / D5 in the current
// index-2IuI5q2p.js: POST {shopno, slots:[{date, periods:[{time_from,time_to}]}]}.
// The new time-slot selector uses HH:mm; the separate limited-slot endpoint
// accepts {slot_ids:[number]}. The backend below rejects the old HH:mm:ss wire.
private struct ScheduleContractReply {
    var status = 200
    var object: Any = [:]
}

private final class ScheduleContractProtocol: URLProtocol {
    static var backend: ScheduleContractBackend!
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let reply = try Self.backend.respond(to: request)
            let response = HTTPURLResponse(url: request.url!, statusCode: reply.status, httpVersion: nil, headerFields: ["Content-Type": "application/json"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: try JSONSerialization.data(withJSONObject: reply.object))
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

private final class ScheduleContractBackend: @unchecked Sendable {
    enum Mutation {
        case apply, acknowledgeOnly, timeoutApplied, timeoutAbsent
        case unavailableApplied, unavailableAbsent, reject400, reject401, reject429
    }
    enum ReadbackMismatch { case none, shop, day, start, end }
    struct Call {
        let method: String
        let path: String
        let body: [String: Any]
    }
    let day = "2026-11-02"
    let shop = 101
    var mutation = Mutation.apply
    var mismatch = ReadbackMismatch.none
    var assigned: [[String: Any]] = []
    var free: [[String: Any]] = []
    var flags: [Int] = []
    var editable = true
    var maxDay = "2026-11-08"
    var preflightStatus: Int?
    var postReadbackStatus: Int?
    var postReadbackMalformed = false
    var permitManual = true
    private let lock = NSLock()
    private var history: [Call] = []
    private var rejectedTimes = 0
    private var mutations = 0
    var calls: [Call] { lock.lock(); defer { lock.unlock() }; return history }
    var postCount: Int { calls.filter { $0.method == "POST" }.count }
    var assignmentReads: Int { calls.filter { $0.path == "/v2/couriers/me/schedule" }.count }
    var legacyFormatRejections: Int { lock.lock(); defer { lock.unlock() }; return rejectedTimes }
    var persisted: [[String: Any]] { lock.lock(); defer { lock.unlock() }; return assigned }

    static func row(day: String = "2026-11-02", shop: Int = 101, start: String, end: String, id: Int = 700) -> [String: Any] {
        ["date": day, "slots": [["id": id, "shopno": shop, "shop_name": "Учебная точка", "time_from": start, "time_to": end]]]
    }
    static func slot(id: Any = 71, available: Bool = true, start: String = "09:00:00", end: String = "12:00:00") -> [String: Any] {
        ["slot_id": id, "is_available": available, "time_from": start, "time_to": end]
    }
    static func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open(); defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 4096)
            while stream.hasBytesAvailable {
                let count = stream.read(&buffer, maxLength: buffer.count)
                if count <= 0 { break }; data.append(contentsOf: buffer.prefix(count))
            }
        }
        return data.isEmpty ? [:] : try JSONSerialization.jsonObject(with: data) as! [String: Any]
    }
    private func validClock(_ value: Any?) -> Bool {
        guard let value = value as? String,
              value.range(of: #"^[0-9]{2}:[0-9]{2}$"#, options: .regularExpression) != nil else { return false }
        let parts = value.split(separator: ":").compactMap { Int($0) }
        return parts.count == 2 && (0...23).contains(parts[0]) && (0...59).contains(parts[1])
    }
    func respond(to request: URLRequest) throws -> ScheduleContractReply {
        lock.lock(); defer { lock.unlock() }
        let url = request.url!, path = url.path, method = request.httpMethod ?? "GET"
        let body = try Self.body(request)
        history.append(Call(method: method, path: path, body: body))
        precondition(url.scheme == "https", "Unexpected non-HTTPS fixture request")
        if url.host == "delivery-api.vkusvill.ru", path == "/v1/tasks/active", method == "GET" {
            return ScheduleContractReply(object: flags)
        }
        precondition(url.host == "couriers-schedules.vkusvill.ru", "Unexpected host; no request can reach the network")
        if path == "/v1/couriers/me/schedule/editability", method == "GET" {
            if let status = preflightStatus { return ScheduleContractReply(status: status, object: ["message": "fixture preflight denied"]) }
            return ScheduleContractReply(object: ["is_editable": editable, "change_start": "2026-11-01", "change_end": maxDay])
        }
        if path == "/v2/couriers/me/schedule", method == "GET" {
            if mutations > 0, let status = postReadbackStatus { return ScheduleContractReply(status: status, object: ["message": "fixture readback unavailable"]) }
            if mutations > 0 && postReadbackMalformed { return ScheduleContractReply(object: ["wrong_shape": []]) }
            return ScheduleContractReply(object: ["items": assigned])
        }
        if path == "/v1/couriers/me/schedules/limited-slots/free", method == "GET" {
            let query = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? []
            precondition(query.first { $0.name == "date_from" }?.value == day && query.first { $0.name == "date_to" }?.value == day, "Preflight must request the chosen date")
            return ScheduleContractReply(object: ["items": [["date": day, "shops": [["shopno": shop, "shop_name": "Учебная точка", "slots": free]]]]])
        }
        if path == "/v1/couriers/me/schedules/shops", method == "GET" {
            return ScheduleContractReply(object: ["items": permitManual ? [["shopno": shop]] : []])
        }
        guard method == "POST" else { preconditionFailure("Unexpected read fixture endpoint: " + path) }
        mutations += 1
        let from: String, to: String
        let limited = path == "/v1/couriers/me/schedules/limited-slots"
        if limited {
            guard Set(body.keys) == ["slot_ids"], let ids = body["slot_ids"] as? [Any], ids.count == 1,
                  let id = ids[0] as? NSNumber, CFGetTypeID(id) != CFBooleanGetTypeID(),
                  let slot = free.first(where: { string($0["slot_id"]) == id.stringValue && truth($0["is_available"]) }) else {
                return ScheduleContractReply(status: 400, object: ["message": "invalid or stale slot id"])
            }
            from = String(string(slot["time_from"]).prefix(5)); to = String(string(slot["time_to"]).prefix(5))
        } else {
            precondition(path == "/v1/couriers/me/schedule", "Unexpected mutation endpoint: " + path)
            guard Set(body.keys) == ["shopno", "slots"], let shopNumber = body["shopno"] as? NSNumber, shopNumber.intValue == shop,
                  let slots = body["slots"] as? [[String: Any]], slots.count == 1,
                  Set(slots[0].keys) == ["date", "periods"], slots[0]["date"] as? String == day,
                  let periods = slots[0]["periods"] as? [[String: Any]], periods.count == 1,
                  Set(periods[0].keys) == ["time_from", "time_to"] else {
                return ScheduleContractReply(status: 400, object: ["message": "invalid schedule schema"])
            }
            guard validClock(periods[0]["time_from"]), validClock(periods[0]["time_to"]) else {
                rejectedTimes += 1
                return ScheduleContractReply(status: 400, object: ["message": "invalid time"])
            }
            from = periods[0]["time_from"] as! String; to = periods[0]["time_to"] as! String
        }
        switch mutation {
        case .reject400: return ScheduleContractReply(status: 400, object: ["message": "invalid time"])
        case .reject401: return ScheduleContractReply(status: 401, object: ["message": "unauthorized"])
        case .reject429: return ScheduleContractReply(status: 429, object: ["message": "rate limited"])
        default: break
        }
        switch mutation {
        case .apply, .timeoutApplied, .unavailableApplied:
            var rowDay = day, rowShop = shop, rowFrom = from, rowTo = to
            switch mismatch {
            case .none: break
            case .shop: rowShop = 202
            case .day: rowDay = "2026-11-03"
            case .start: rowFrom = "09:30"
            case .end: rowTo = "19:30"
            }
            // Independent persisted server representation intentionally includes
            // seconds, an assignment ID, and a shop, not the POST JSON shape.
            assigned.append(Self.row(day: rowDay, shop: rowShop, start: rowFrom + ":00", end: rowTo + ":00"))
        default: break
        }
        switch mutation {
        case .timeoutApplied, .timeoutAbsent: throw URLError(.timedOut)
        case .unavailableApplied, .unavailableAbsent: return ScheduleContractReply(status: 503, object: ["message": "fixture timeout after possible commit"])
        default: return ScheduleContractReply(object: limited ? ["status": "created"] : [:])
        }
    }
}

@main enum ScheduleContractTests {
    static func rejected(status: Int? = nil, _ operation: () async throws -> Void) async {
        do { try await operation(); preconditionFailure("Expected schedule rejection") }
        catch {
            if let status { precondition((error as? CourierError)?.statusCode == status, "Wrong rejection type/status: \(error)") }
        }
    }
    static func verifyPending(_ result: ScheduleBookingResult, acknowledged: Bool, readbackSucceeded: Bool) {
        precondition(result.assignments == nil, "An acknowledgement alone must never confirm an assignment")
        precondition(result.acknowledged == acknowledged && result.readbackSucceeded == readbackSucceeded)
        precondition(!result.message.isEmpty, "Pending state must be actionable")
    }
    static func main() async throws {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [ScheduleContractProtocol.self]
        let transport = URLSession(configuration: config)
        defer { transport.invalidateAndCancel() }
        let api = CourierAPI(session: Session(token: "offline-schedule-contract", courierID: "1"), shopNumbers: [101], transport: transport)
        func backend() -> ScheduleContractBackend {
            let value = ScheduleContractBackend(); ScheduleContractProtocol.backend = value; return value
        }
        // Prove the fixture itself detects the exact regression instead of
        // accepting whatever format the app happens to emit.
        do {
            let server = backend()
            await rejected(status: 400) {
                _ = try await api.dictionary(CourierAPI.scheduleRoot + "/me/schedule", body: ["shopno": 101, "slots": [["date": server.day, "periods": [["time_from": "08:00:00", "time_to": "20:00:00"]]]]])
            }
            precondition(server.legacyFormatRejections == 1 && server.persisted.isEmpty)
        }
        // Daytime, overnight, and end-of-day are accepted and actually persisted.
        for (from, to) in [("08:00", "20:00"), ("23:00", "01:00"), ("00:00", "23:59")] {
            let server = backend()
            let result = try await api.book(day: server.day, start: from, end: to, slotID: nil)
            precondition(result.assignments != nil && result.acknowledged && result.readbackSucceeded)
            precondition(scheduleContains(server.persisted, shopID: 101, day: server.day, start: from, end: to))
            precondition(server.postCount == 1 && server.assignmentReads == 2)
            let wire = server.calls.first { $0.method == "POST" }!.body
            let periods = ((wire["slots"] as! [[String: Any]])[0]["periods"] as! [[String: Any]])
            precondition(periods[0]["time_from"] as? String == from && periods[0]["time_to"] as? String == to, "Golden manual POST must contain HH:mm")
        }
        // Bad manual clocks never reach the mutation endpoint.
        for (from, to) in [("24:00", "01:00"), ("08:00", "24:00"), ("08:15", "20:00"), ("08:00", "20:15"), ("23:59", "01:00"), ("08:00:00", "20:00"), ("08:00", "08:00")] {
            let server = backend()
            await rejected { _ = try await api.book(day: server.day, start: from, end: to, slotID: nil) }
            precondition(server.postCount == 0 && server.persisted.isEmpty, "Client time validation must precede POST")
        }
        // A different store and the prior day's overnight exit both block overlap.
        for row in [ScheduleContractBackend.row(shop: 202, start: "10:00:00", end: "12:00:00"),
                    ScheduleContractBackend.row(day: "2026-11-01", shop: 202, start: "23:00:00", end: "10:00:00")] {
            let server = backend(); server.assigned = [row]
            await rejected { _ = try await api.book(day: server.day, start: "08:00", end: "11:00", slotID: nil) }
            precondition(server.postCount == 0 && server.persisted.count == 1)
        }
        for row in [ScheduleContractBackend.row(shop: 202, start: "06:00:00", end: "08:00:00"),
                    ScheduleContractBackend.row(shop: 202, start: "20:00:00", end: "22:00:00")] {
            let server = backend(); server.assigned = [row]
            let result = try await api.book(day: server.day, start: "08:00", end: "20:00", slotID: nil)
            precondition(result.assignments?.count == 2 && server.persisted.count == 2 && server.postCount == 1, "Touching boundaries must preserve the other exit")
        }
        // Final editable day permits 23:59, but not an interval ending tomorrow.
        do {
            let server = backend(); server.maxDay = server.day
            let result = try await api.book(day: server.day, start: "20:00", end: "23:59", slotID: nil)
            precondition(result.assignments != nil && server.postCount == 1)
        }
        do {
            let server = backend(); server.maxDay = server.day
            await rejected { _ = try await api.book(day: server.day, start: "23:00", end: "01:00", slotID: nil) }
            precondition(server.postCount == 0)
        }
        // Server-owned slot time wins over stale UI clocks and ID remains numeric.
        do {
            let server = backend(); server.free = [ScheduleContractBackend.slot()]
            let result = try await api.book(day: server.day, start: "01:00", end: "02:00", slotID: "71")
            precondition(result.assignments != nil && server.postCount == 1)
            precondition(scheduleContains(server.persisted, shopID: 101, day: server.day, start: "09:00", end: "12:00"))
            let post = server.calls.first { $0.method == "POST" }!
            precondition(post.path == "/v1/couriers/me/schedules/limited-slots")
            precondition((post.body["slot_ids"] as? [Int]) == [71] && Set(post.body.keys) == ["slot_ids"])
        }
        for slot in [ScheduleContractBackend.slot(id: 72), ScheduleContractBackend.slot(available: false), ScheduleContractBackend.slot(id: "not-numeric")] {
            let server = backend(); server.free = [slot]
            await rejected { _ = try await api.book(day: server.day, start: "09:00", end: "12:00", slotID: "71") }
            precondition(server.postCount == 0)
        }
        do {
            let server = backend(); server.free = [ScheduleContractBackend.slot(id: "not-numeric")]
            await rejected { _ = try await api.book(day: server.day, start: "09:00", end: "12:00", slotID: "not-numeric") }
            precondition(server.postCount == 0)
        }
        for status in [401, 429, 503] {
            let server = backend(); server.preflightStatus = status
            await rejected(status: status) { _ = try await api.book(day: server.day, start: "08:00", end: "20:00", slotID: nil) }
            precondition(server.postCount == 0 && server.calls.count == 1)
        }
        do {
            let server = backend(); server.editable = false
            await rejected { _ = try await api.book(day: server.day, start: "08:00", end: "20:00", slotID: nil) }
            precondition(server.postCount == 0)
        }
        do {
            let server = backend(); server.flags = [376]; server.permitManual = false
            await rejected { _ = try await api.book(day: server.day, start: "08:00", end: "20:00", slotID: nil) }
            precondition(server.postCount == 0)
        }
        // An empty acknowledgement with no matching stored assignment is pending.
        do {
            let server = backend(); server.mutation = .acknowledgeOnly
            verifyPending(try await api.book(day: server.day, start: "08:00", end: "20:00", slotID: nil), acknowledged: true, readbackSucceeded: true)
            precondition(server.persisted.isEmpty && server.postCount == 1 && server.assignmentReads == 2)
        }
        for mismatch in [ScheduleContractBackend.ReadbackMismatch.shop, .day, .start, .end] {
            let server = backend(); server.mismatch = mismatch
            verifyPending(try await api.book(day: server.day, start: "08:00", end: "20:00", slotID: nil), acknowledged: true, readbackSucceeded: true)
            precondition(server.postCount == 1 && server.persisted.count == 1)
        }
        // Timeout/5xx may occur after the server commits. Only independent GET
        // state decides success; neither path is allowed to replay the POST.
        for mutation in [ScheduleContractBackend.Mutation.timeoutApplied, .timeoutAbsent, .unavailableApplied, .unavailableAbsent] {
            let server = backend(); server.mutation = mutation
            let result = try await api.book(day: server.day, start: "08:00", end: "20:00", slotID: nil)
            let applied = mutation == .timeoutApplied || mutation == .unavailableApplied
            precondition((result.assignments != nil) == applied && !result.acknowledged && result.readbackSucceeded)
            precondition(server.persisted.count == (applied ? 1 : 0) && server.postCount == 1 && server.assignmentReads == 2)
        }
        for (mutation, status) in [(ScheduleContractBackend.Mutation.reject400, 400), (.reject401, 401), (.reject429, 429)] {
            let server = backend(); server.mutation = mutation
            await rejected(status: status) { _ = try await api.book(day: server.day, start: "08:00", end: "20:00", slotID: nil) }
            precondition(server.postCount == 1 && server.assignmentReads == 1 && server.persisted.isEmpty, "A definite 4xx rejection must not trigger a mutation retry")
        }
        for acknowledged in [true, false] {
            let server = backend(); server.mutation = acknowledged ? .apply : .timeoutApplied; server.postReadbackStatus = 503
            verifyPending(try await api.book(day: server.day, start: "08:00", end: "20:00", slotID: nil), acknowledged: acknowledged, readbackSucceeded: false)
            precondition(server.persisted.count == 1 && server.postCount == 1 && server.assignmentReads == 2)
        }
        do {
            let server = backend(); server.postReadbackMalformed = true
            verifyPending(try await api.book(day: server.day, start: "08:00", end: "20:00", slotID: nil), acknowledged: true, readbackSucceeded: false)
            precondition(server.postCount == 1)
        }
        do {
            let server = backend(); server.postReadbackStatus = 401
            await rejected(status: 401) { _ = try await api.book(day: server.day, start: "08:00", end: "20:00", slotID: nil) }
            precondition(server.persisted.count == 1 && server.postCount == 1 && server.assignmentReads == 2)
        }
        for scope in [[], [101, 202]] {
            let server = backend()
            let scoped = CourierAPI(session: api.session, shopNumbers: scope, transport: transport)
            await rejected { _ = try await scoped.book(day: server.day, start: "08:00", end: "20:00", slotID: nil) }
            precondition(server.calls.isEmpty, "A booking must require exactly one selected store")
        }
        print("Schedule contract tests passed: strict HH:mm backend, date/shop/slot, overnight/23:59, cross-store overlap, independent assignment readback, timeout/5xx recovery and one-POST limit")
    }
}
