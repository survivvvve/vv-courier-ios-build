#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
ORIGINAL_TEST_DIR=$(mktemp -d)
trap 'rm -rf "$ORIGINAL_TEST_DIR"' EXIT
xcrun swiftc -swift-version 5 -parse-as-library Tests/OriginalRuntimeTests.swift -o "$ORIGINAL_TEST_DIR/OriginalRuntimeTests"
"$ORIGINAL_TEST_DIR/OriginalRuntimeTests"
