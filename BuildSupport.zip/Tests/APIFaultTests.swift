import Foundation

private struct FaultReply {
    var status = 200
    var object: Any = [:]
    var raw: Data? = nil
}
private final class FaultProtocol: URLProtocol {
    static var handler: ((URLRequest) throws -> FaultReply)!
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let reply = try Self.handler(request)
            let response = HTTPURLResponse(url: request.url!, statusCode: reply.status, httpVersion: nil, headerFields: ["Content-Type": "application/json"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: try reply.raw ?? JSONSerialization.data(withJSONObject: reply.object))
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}
private final class SignalRecorder: @unchecked Sendable {
    private let lock = NSLock()
    private var values: [String] = []
    func append(_ fingerprint: String) { lock.lock(); defer { lock.unlock() }; values.append(fingerprint) }
    func snapshot() -> [String] { lock.lock(); defer { lock.unlock() }; return values }
}

@main enum APIFaultTests {
    static func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open(); defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 4096)
            while stream.hasBytesAvailable {
                let count = stream.read(&buffer, maxLength: buffer.count)
                guard count > 0 else { break }; data.append(contentsOf: buffer.prefix(count))
            }
        }
        return try JSONSerialization.jsonObject(with: data) as! [String: Any]
    }
    static func reject(_ operation: () async throws -> Void) async {
        do { try await operation(); preconditionFailure("Expected a rejected/incomplete result") } catch {}
    }
    static func main() async throws {
        let configuration = URLSessionConfiguration.ephemeral; configuration.protocolClasses = [FaultProtocol.self]
        let transport = URLSession(configuration: configuration); defer { transport.invalidateAndCancel() }
        let owner = "api-audit-" + UUID().uuidString
        let api = CourierAPI(session: Session(token: "offline-only", courierID: owner), shopNumbers: [101], transport: transport)
        let now = timestamp("2026-11-02T12:00:00+03:00")!
        let cacheDay = "2026-11-02", cacheKey = "day.\(owner).2026-11-02"
        defer { UserDefaults.standard.removeObject(forKey: cacheKey); UserDefaults.standard.removeObject(forKey: "day.\(owner).2030-01-03") }
        precondition(integer("nan") == nil && integer("inf") == nil && integer("1e100") == nil && integer("1.5") == nil)
        precondition(integer(true) == nil && integer("2.0") == 2 && finiteNumber("nan") == nil && number("inf") == 0)
        precondition(finiteNumber(true) == nil && finiteNumber("2\u{202f}500,15") == 2500.15)
        precondition(GeoPoint(["latitude": "", "longitude": "bad", "lat": 60.1, "lon": 30.2]) != nil)
        precondition(GeoPoint(["latitude": "nan", "longitude": 30]) == nil)
        let parcel = Parcel(["id_parcel": "1", "id_general_view": "12345678"])
        precondition(parcel.label == "45678" && parcel.fullNumber == "12345678")
        var mapShops: [[String: Any]] = []
        ParcelMapPayload.appendShops([["shopno": 101], ["shopno": 101, "latitude_tt": 60.1, "longitude_tt": 30.2]], to: &mapShops)
        precondition(mapShops.count == 2, "A coordinate-less row must not hide a later valid shop pin")
        precondition(api.sessionFingerprint != CourierAPI(session: Session(token: "relogged", courierID: owner)).sessionFingerprint)
        let recorder = SignalRecorder()
        let observer = NotificationCenter.default.addObserver(forName: CourierAPI.coldControlNotification, object: nil, queue: nil) { event in
            if let fingerprint = event.userInfo?["sessionFingerprint"] as? String { recorder.append(fingerprint) }
        }
        defer { NotificationCenter.default.removeObserver(observer) }
        FaultProtocol.handler = { _ in FaultReply(status: 401, object: ["termocontrol": ["is_need_termocontrol": true], "business_error": 102]) }
        await reject { _ = try await api.profile() }
        precondition(recorder.snapshot().isEmpty, "A rejected session cannot assign cold control to a newly logged-in identity")
        FaultProtocol.handler = { _ in FaultReply(object: ["termocontrol": ["is_need_termocontrol": false]]) }
        _ = try await api.profile()
        _ = try await api.request(CourierAPI.root + "/fixture-auth", auth: false)
        precondition(recorder.snapshot() == [api.sessionFingerprint!], "Only authenticated responses carry their own identity fingerprint")
        FaultProtocol.handler = { _ in FaultReply(object: ["business_error": 999, "parcels": []]) }
        do { _ = try await api.profile(); preconditionFailure("Business error accepted as data") }
        catch let error as CourierError { precondition(error.businessCode == 999) }
        for status in [401, 429, 503] {
            var attempts = 0
            FaultProtocol.handler = { _ in attempts += 1; return FaultReply(status: status, object: ["message": "fixture rejection"]) }
            do { _ = try await api.profile(); preconditionFailure("HTTP rejection accepted") }
            catch let error as CourierError { precondition(error.statusCode == status) }
            precondition(attempts == 1, "Requests never auto-retry SMS, reads or writes on auth/rate/network errors")
        }
        FaultProtocol.handler = { _ in FaultReply(raw: Data("not-json".utf8)) }
        await reject { _ = try await api.profile() }
        var attempts = 0
        FaultProtocol.handler = { _ in attempts += 1; throw URLError(.cancelled) }
        do { _ = try await api.profile(); preconditionFailure("Cancellation accepted") } catch is CancellationError {}
        precondition(attempts == 1)
        attempts = 0
        FaultProtocol.handler = { _ in attempts += 1; return FaultReply() }
        await Task {
            withUnsafeCurrentTask { $0?.cancel() }
            do { _ = try await api.profile(); preconditionFailure("Pre-cancelled request started") } catch is CancellationError {} catch { preconditionFailure("Cancellation changed type") }
        }.value
        precondition(attempts == 0)
        var invalidPage = CourierPagination(limit: 25)
        do { _ = try invalidPage.consume([[:]], reportedTotal: nil); preconditionFailure("Missing parcel ID accepted") } catch is CourierError {}
        var invalidTotal = CourierPagination(limit: 25)
        do { _ = try invalidTotal.consume([], reportedTotal: "1e100"); preconditionFailure("Unrepresentable total accepted") } catch is CourierError {}
        precondition(scheduleInterval(day: "2026-11-02", start: "23:00", end: "01:00") != nil)
        precondition(scheduleInterval(day: "2026-11-02", start: "2026-11-02T23:00:00+03:00", end: "2026-11-01T01:00:00+03:00") == nil, "An invalid absolute interval must not be rolled into a negative duration")

        // A server is allowed to use a smaller effective page size.
        var offsets: [Int] = []
        FaultProtocol.handler = { request in
            let offset = (try Self.body(request)["pagination"] as! [String: Any])["offset"] as! Int
            offsets.append(offset)
            let rows: [[String: Any]] = offset == 0 ? [["id_parcel": "1"]] : [["id_parcel": "2"], ["id_parcel": "3"]]
            return FaultReply(object: ["parcels": rows, "total": 3])
        }
        let complete = try await api.feed(.available)
        precondition(complete.parcels.count == 3 && offsets == [0, 1])
        for archive in [false, true] {
            var calls = 0
            FaultProtocol.handler = { _ in
                calls += 1
                let count = archive ? 25 : 100
                return FaultReply(object: ["parcels": (1...count).map { ["id_parcel": String($0)] }, "total": ["category_count": count + 1]])
            }
            await reject { if archive { _ = try await api.archivedParcels(daysAgo: 0) } else { _ = try await api.feed(.assembly) } }
            precondition(calls == 2, "Repeated IDs stop immediately instead of looping/truncating")
        }
        offsets = []
        FaultProtocol.handler = { request in
            let offset = (try Self.body(request)["pagination"] as! [String: Any])["offset"] as! Int
            offsets.append(offset)
            return FaultReply(object: ["parcels": (offset == 0 ? Array(1...25) : [26]).map { ["id_parcel": String($0)] }, "total": ["category_count": 26]])
        }
        let archiveRows = try await api.archivedParcels(daysAgo: 0)
        precondition(archiveRows.count == 26)
        precondition(offsets == [0, 25], "Dictionary total cannot truncate archive")
        FaultProtocol.handler = { request in
            let offset = (try Self.body(request)["pagination"] as! [String: Any])["offset"] as! Int
            return FaultReply(object: ["parcels": offset == 0 ? [["id_parcel": "1", "reward": 10]] : [], "total": 2])
        }
        await reject { _ = try await api.archivedParcels(daysAgo: 0) }
        let prior = DayTotal(day: cacheDay, gross: 777, count: 7)
        UserDefaults.standard.set(try JSONEncoder().encode(prior), forKey: cacheKey)
        await reject { _ = try await api.dayTotal(offset: 0, relativeTo: now) }
        precondition(api.cachedDay(cacheDay)?.gross == 777, "Incomplete report must not replace a saved total")
        FaultProtocol.handler = { _ in FaultReply(object: ["parcels": [], "courier_profit_sum": "nan"]) }
        await reject { _ = try await api.dayTotal(offset: 0, relativeTo: now) }
        precondition(api.cachedDay(cacheDay)?.gross == 777)
        precondition(CourierAPI(session: Session(token: "offline", courierID: owner + "-other")).cachedDay(cacheDay) == nil)

        for (times, minutes, idle) in [(["10:00:00", "10:30:00", "12:01:00", "12:31:00"], 60, 91), (["10:00:00", "10:30:00", "13:00:00", "13:30:00"], 80, 130), (["10:00:00", "11:30:00"], 90, 0), (["10:00:00", "11:30:01"], 0, 90)] {
            FaultProtocol.handler = { _ in FaultReply(object: ["parcels": times.enumerated().map { ["id_parcel": String($0.offset), "reward": 50, "delivered_at": "2026-11-02T" + $0.element + "+03:00"] }]) }
            let result = try await api.dayTotal(offset: 0, relativeTo: now)
            precondition(result.minutes == minutes && result.idle == idle && result.timedCount == times.count)
            precondition(result.net == result.gross * 0.94 && result.tax == result.gross * 0.06)
        }
        FaultProtocol.handler = { _ in FaultReply(object: ["parcels": [["id_parcel": "1", "reward": 30, "date_supply": "2026-11-02T10:00:00+03:00"], ["id_parcel": "2", "reward": 50, "date_supply": "2026-11-02T11:00:00+03:00"]], "courier_profit_sum": 100]) }
        let priced = try await api.dayTotal(offset: 0, relativeTo: now)
        precondition(priced.gross == 100 && priced.count == 2 && priced.timedCount == 0 && priced.hourly == nil, "Customer planned slot is not delivery completion time")

        FaultProtocol.handler = { _ in FaultReply(object: ["parcels": [
            ["id_parcel": "weight-1", "reward": 10, "weight": "1,250", "time_until_delay_seconds": -20, "delivered_at": "2026-11-02T20:05:00+03:00"],
            ["id_parcel": "weight-2", "reward": 10, "weight": 2.875, "route_time_until_delay": 120, "delivered_at": "2026-11-02T21:05:00+03:00"],
            ["id_parcel": "weight-3", "reward": 10, "weight": "nan", "time_until_delay": -5],
            ["id_parcel": "weight-4", "reward": 10]
        ], "courier_profit_sum": 50]) }
        let weighted = try await api.dayTotal(offset: 0, relativeTo: now)
        precondition(weighted.count == 4 && weighted.gross == 50 && weighted.weight == 4.125)
        precondition(weighted.weightedCount == 2 && weighted.hasPartialWeight && weighted.totalWeightText == "4,125 кг")
        precondition(weighted.late == 2 && weighted.timeRange == "20:05 — 21:05" && weighted.minutes == 60)
        precondition(weighted.grossHourly == 50 && weighted.hourly == 47)
        let restored = api.cachedDay(cacheDay)!
        precondition(restored.weightedCount == 2 && restored.timeRange == weighted.timeRange, "Report metadata must survive cache round-trip")
        FaultProtocol.handler = { _ in FaultReply(object: ["parcels": [["id_parcel": "unknown-weight", "reward": 10, "weight": "nan"]]]) }
        let unknownWeight = try await api.dayTotal(offset: 0, relativeTo: now)
        precondition(unknownWeight.totalWeightText == "—" && unknownWeight.weightedCount == 0 && unknownWeight.hourly == nil)

        let daily = [
            DayTotal(day: "one", gross: 1000, count: 10, weight: 12.3, late: 2, minutes: 60, idle: 95, timedCount: 10, weightedCount: 10),
            DayTotal(day: "two", gross: 500, count: 5, weight: 4.2, late: 1, minutes: 30, timedCount: 5, weightedCount: 5),
            DayTotal(day: "three", gross: 3000, count: 20, weight: 20, minutes: 150, idle: 130, timedCount: 20, weightedCount: 19)
        ]
        var period = DayTotal(day: "selected period", timedCount: 0, weightedCount: 0)
        daily.forEach { period.include($0) }
        precondition(period.gross == 4500 && period.net == 4230 && period.tax == 270)
        precondition(period.count == 35 && abs(period.weight - 36.5) < 0.000001 && period.late == 3)
        precondition(period.minutes == 240 && period.idle == 225 && period.weightedCount == 34 && period.hasPartialWeight)
        precondition(period.grossHourly == 1125 && period.hourly == 1057.5 && period.ordersPerHour == 8.75, "Period rates are recalculated from total active time, not averaged per day")
        var legacy = DayTotal(day: cacheDay, gross: 100, count: 2, weight: 7.5, minutes: 60)
        let legacyData = try JSONEncoder().encode(legacy)
        legacy = try JSONDecoder().decode(DayTotal.self, from: legacyData)
        precondition(legacy.weightedCount == nil && legacy.firstDelivery == nil && legacy.timeRange == nil && legacy.totalWeightText == "7,500 кг")
        period.include(legacy)
        precondition(period.weightedCount == nil && period.count == 37 && period.gross == 4600, "Legacy cached days remain readable without invented coverage metadata")
        FaultProtocol.handler = { _ in FaultReply(object: ["items": [["operation_time": "2026-11-02", "total_amount": "nan"]]]) }
        await reject { _ = try await api.incomes() }
        FaultProtocol.handler = { request in
            let body = try Self.body(request)
            precondition((body["date_time_start"] as? String)?.hasPrefix("2030-01-02T21:00:00") == true)
            return FaultReply(object: ["parcels": []])
        }
        let anchored = try await api.dayTotal(offset: 0, relativeTo: timestamp("2030-01-03T00:01:00+03:00")!)
        precondition(anchored.day == "2030-01-03", "One Moscow reference date must survive midnight independently of the device clock")
        print("API fault checks passed: strict numbers, HTTP/auth/cancellation, complete pagination, report cache/clock/idle and account separation")
    }
}
