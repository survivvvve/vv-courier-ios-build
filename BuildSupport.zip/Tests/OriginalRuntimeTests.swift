import Foundation
import JavaScriptCore

@main struct OriginalRuntimeTests {
    static func main() throws {
        let context = JSContext()!
        var exception: String?
        context.exceptionHandler = { _, value in exception = value?.toString() }
        func evaluate(_ source: String) throws -> JSValue {
            exception = nil
            let value = context.evaluateScript(source)!
            if let exception { throw NSError(domain: "OriginalRuntime", code: 1, userInfo: [NSLocalizedDescriptionKey: exception]) }
            return value
        }
        func check(_ source: String, _ message: String) throws {
            guard try evaluate(source).toBool() else { fatalError(message) }
        }
        _ = try evaluate("""
        var window=globalThis,self=globalThis,requests=[];
        var console={log(){},warn(){},error(){}};
        var document={readyState:'loading',addEventListener(){},removeEventListener(){}};
        var addEventListener=function(){},removeEventListener=function(){};
        var location={pathname:'/start',search:'',href:'https://courier.vkusvill.ru/start'};
        var history={};
        var queueMicrotask=callback=>Promise.resolve().then(callback);
        class Storage{constructor(){this.data={}}getItem(k){return this.data[k]??null}setItem(k,v){this.data[k]=String(v)}removeItem(k){delete this.data[k]}clear(){this.data={}}}
        var localStorage=new Storage();
        window.webkit={messageHandlers:{vvNative:{postMessage(m){requests.push(m)}}}};
        window.fetch=async()=>({ok:true,clone(){return this},json:async()=>({})});
        """)
        _ = try evaluate(String(contentsOfFile: "Resources/OriginalDiagnostics.js", encoding: .utf8))
        let runtime = try String(contentsOfFile: "Resources/OriginalRuntime.js", encoding: .utf8)
        _ = try evaluate(runtime)
        _ = try evaluate("console.error(new TypeError(\"Cannot read properties of undefined (reading 'properties_v2')\"));")
        try check("requests.some(r=>r.kind==='diagnostic'&&r.property==='properties_v2'&&r.documentID===requests.find(b=>b.kind==='boot').documentID)", "Sanitized diagnostics must use the current native bridge document identity.")
        let core = try String(contentsOfFile: "Resources/CapacitorCompatibilityFixture.js", encoding: .utf8)
        _ = try evaluate(core)
        try check("Capacitor.getPlatform()==='web' && !Capacitor.isNativePlatform()", "The original website must stay on web platform.")
        try check("!('bridge' in webkit.messageHandlers)", "Do not impersonate a Capacitor iOS runtime.")
        try check("Capacitor.isPluginAvailable('Camera') && Capacitor.isPluginAvailable('BarcodeScanner') && !Capacitor.isPluginAvailable('LifePay')", "Advertise only implemented native plugins.")
        _ = try evaluate("var camera=__vvRegisterPlugin('Camera');var settled='pending';camera.checkPermissions().then(r=>settled=r.camera,e=>settled=e.message);")
        try check("requests.some(r=>r.plugin==='Camera'&&r.method==='checkPermissions')", "The real SDK must dispatch Camera to Swift.")
        _ = try evaluate("var request=requests.find(r=>r.plugin==='Camera');__vvNativeReceive({callbackID:request.callbackID,success:true,data:{camera:'prompt'}});")
        try check("settled==='prompt'", "Preserve the actual prompt permission result.")
        _ = try evaluate("var failure='';camera.getPhoto({resultType:'dataUrl'}).catch(e=>failure=e.message);")
        _ = try evaluate("var rejected=requests[requests.length-1];__vvNativeReceive({callbackID:rejected.callbackID,success:false,error:'Отменено'});")
        try check("failure==='Отменено'", "Cancellation must reject instead of inventing a photo.")
        _ = try evaluate("var scanner=__vvRegisterPlugin('BarcodeScanner');var codes=[];scanner.startScanning({},r=>codes.push(r.content));")
        _ = try evaluate("var scan=requests[requests.length-1];__vvNativeReceive({callbackID:scan.callbackID,success:true,data:{content:'22421'},keepAlive:true});__vvNativeReceive({callbackID:scan.callbackID,success:true,data:{content:'34233'},keepAlive:true});")
        try check("codes.join(',')==='22421,34233'", "Continuous scan callback must remain alive.")
        _ = try evaluate("__vvNativeReceive({callbackID:scan.callbackID,success:true,data:{content:''},keepAlive:false});__vvNativeReceive({callbackID:scan.callbackID,success:true,data:{content:'stale'},keepAlive:true});")
        try check("!codes.includes('stale')", "A stopped scan must ignore late native callbacks.")
        _ = try evaluate("var events=[];var handle;scanner.addListener('barcodesScanned',r=>events.push(r.barcodes[0].rawValue)).then(r=>handle=r);")
        _ = try evaluate("var listener=requests[requests.length-1];__vvNativeReceive({callbackID:listener.callbackID,success:true,data:{barcodes:[{rawValue:'52523'}]},keepAlive:true});")
        try check("events[0]==='52523' && typeof handle.remove==='function'", "The actual SDK listener wrapper must work.")
        _ = try evaluate("handle.remove();")
        try check("requests[requests.length-1].method==='removeListener' && requests[requests.length-1].options.callbackId===listener.callbackID", "Remove the exact native listener.")
        _ = try evaluate("__vvNativeReceive({callbackID:listener.callbackID,success:true,data:{barcodes:[{rawValue:'late'}]},keepAlive:true});")
        try check("events.length===1", "A removed listener must ignore late frames.")
        _ = try evaluate("localStorage.setItem('CapacitorStorage.token_courier','offline-test-only');")
        try check("requests[requests.length-1].kind==='token' && requests[requests.length-1].token==='offline-test-only'", "Observe a newly persisted website session.")
        _ = try evaluate("localStorage.clear();")
        try check("requests[requests.length-1].kind==='token' && requests[requests.length-1].token===''", "Website logout must invalidate native account state immediately.")
        _ = try evaluate("var disposed='';camera.getPhoto().catch(e=>disposed=e.message);__vvCompanion.dispose();")
        try check("disposed==='Страница закрыта.'", "Document disposal must reject outstanding promises.")
        print("Original runtime: actual Capacitor core, web platform, Camera promise/rejection, continuous barcode, listener removal and disposal passed.")
    }
}
