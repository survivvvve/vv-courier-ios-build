#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
import tempfile, subprocess
# Only framework/keychain/network boundaries are replaced. The production
# Telegram center and both actual shared-poller methods are compiled verbatim.
s = Path('TelegramNotificationCenter.swift').read_text()
center = s.split('#if canImport(SwiftUI)')[0] + '\nimport Combine\n' + s[s.index('@MainActor final class TelegramNotificationCenter'):s.index('/// Keeps the settings')]
express = Path('ExpressNotifications.swift').read_text()
poll = express[express.index('    func poll(session:'):express.index('    private func clearForeground()')]
pause = express[express.index('    func pauseDelivery()'):express.index('    private func persist()')]
poll = pause + poll
poll = poll.replace('TelegramNotificationCenter.shared', 'telegram').replace('TelegramNotificationPreferences.shared', 'telegramPreferences')
assert 'guard anyMonitoringEnabled' in poll
assert 'center.anyMonitoringEnabled else' in express
assert 'guard (self.nativeMonitoringEnabled && self.allowed) || TelegramNotificationPreferences.shared.monitoringEnabled' in express
assert 'let telegramBackground = TelegramNotificationPreferences.shared.monitoringEnabled && TelegramNotificationCenter.shared.active' in express
support = r'''
import Foundation
import Combine
func truth(_ value: Any?) -> Bool { !["", "0", "false", "none", "<null>"].contains(string(value).lowercased()) }
enum SessionStore { static var stored: Session?; static func load() -> Session? { stored } }
struct TelegramNotificationConfiguration: Codable, Equatable {
    let botID: Int64; let botUsername: String; let chat: TelegramChatDestination; let chatTitle: String
}
@MainActor final class TelegramNotificationPreferences: ObservableObject {
    static let shared = TelegramNotificationPreferences()
    @Published var enabled = true
    @Published var created = true
    @Published var ready = true
    @Published var onlyExpress = false
    @Published var revision = 0
    var token: String? = "123456:OFFLINE_FIXTURE_TOKEN"
    var configuration: TelegramNotificationConfiguration? = TelegramNotificationConfiguration(botID: 123456, botUsername: "fixture", chat: TelegramChatDestination(chatID: "-100123"), chatTitle: "Offline")
    var isConfigured: Bool { configuration != nil && token != nil }
    var monitoringEnabled: Bool { enabled && isConfigured && (created || ready) }
}
@MainActor final class VVFixture {
    static let shared = VVFixture()
    var activeReads = 0, assemblyReads = 0, readyReads = 0
    var active = true
    var assembly: [Parcel] = [], ready: [Parcel] = []
    var onActive: (() -> Void)?
    func reset() { activeReads = 0; assemblyReads = 0; readyReads = 0; active = true; assembly = []; ready = []; onActive = nil }
}
@MainActor struct CourierAPI {
    let session: Session?
    var shopNumbers: [Int] = []
    var sessionFingerprint: String? { session.map { $0.courierID + ":" + $0.token } }
    func activeShift() async throws -> Bool { await Task.yield(); let f = VVFixture.shared; f.activeReads += 1; f.onActive?(); return f.active }
    func feed(_ feed: Feed) async throws -> ParcelFeed {
        await Task.yield(); let f = VVFixture.shared
        if feed == .assembly { f.assemblyReads += 1; return ParcelFeed(parcels: f.assembly, checking: [:], total: f.assembly.count) }
        f.readyReads += 1; return ParcelFeed(parcels: f.ready, checking: [:], total: f.ready.count)
    }
}
struct UIApplication { enum State { case active, background }; static let shared = UIApplication(); var applicationState: State { .active } }
struct UINotificationFeedbackGenerator { enum Kind { case success }; func notificationOccurred(_ value: Kind) {} }
enum UIAccessibility { enum Notice { case announcement }; static func post(notification: Notice, argument: String) {} }
class UNMutableNotificationContent {
    enum Sound { case `default` }
    var title = "", body = "", threadIdentifier = ""; var sound: Sound?; var userInfo: [String: Any] = [:]
}
struct UNNotificationRequest { let identifier: String; let content: UNMutableNotificationContent; let trigger: String? }
struct FakeDelivered { let request: UNNotificationRequest }
struct BGTaskScheduler { static let shared = BGTaskScheduler(); func cancel(taskRequestWithIdentifier: String) {} }
@MainActor final class FakeNotifications {
    var added: [UNNotificationRequest] = []
    func deliveredNotifications() async -> [FakeDelivered] { added.map { FakeDelivered(request: $0) } }
    func add(_ value: UNNotificationRequest) async throws { added.append(value) }
    func removePendingNotificationRequests(withIdentifiers: [String]) {}
    func removeDeliveredNotifications(withIdentifiers: [String]) {}
}
final class NativePreferences { var enabled = false, created = true, ready = true; func allows(_ kind: ExpressEventKind) -> Bool { enabled && (kind == .created ? created : ready) } }
@MainActor final class ExpressPollHarness {
    static let backgroundID = "offline-only-refresh"
    let telegram: TelegramNotificationCenter
    let telegramPreferences: TelegramNotificationPreferences
    let preferences = NativePreferences()
    let notifications = FakeNotifications()
    var generation = UUID(), pollID = UUID()
    var pollTask: Task<Bool?, Never>?
    var backgroundPolls: [UUID: UUID] = [:]
    var ledger = ExpressNotificationLedger(), inbox = ExpressForegroundInbox()
    var pending: [ExpressOrderEvent] = [], foregroundEvents: [ExpressOrderEvent] = []
    var observedShift: Bool?, lastCheckedAt: Date?, expiredCourierID: String?
    var freshActiveAt = Date.distantPast, lastSave = Date.distantPast
    var status = "", error: String?
    var allowed = false, backgroundSchedules = 0
    var nativeMonitoringEnabled: Bool { preferences.enabled && (preferences.created || preferences.ready) }
    var anyMonitoringEnabled: Bool { nativeMonitoringEnabled || telegramPreferences.monitoringEnabled }
    init(_ telegram: TelegramNotificationCenter, _ preferences: TelegramNotificationPreferences) { self.telegram = telegram; self.telegramPreferences = preferences }
    func refreshAuthorization() async {}
    func clearForeground() { inbox.reset(); foregroundEvents = [] }
    func persist() { lastSave = Date() }
    func needsQuietResume() -> Bool { ExpressNotificationDelivery.needsQuietResume(lastObservedAt: ledger.lastObservedAt) }
    func stopShift() { telegram.stopShift(); generation = UUID(); pending = []; freshActiveAt = .distantPast; observedShift = false; ledger.endShift(); clearForeground() }
    func scheduleBackgroundRefresh() { backgroundSchedules += 1 }
    func removeExpressNotifications(epoch: String) {}
'''
with tempfile.TemporaryDirectory(prefix='vv-telegram-monitoring-') as folder:
    out = Path(folder)
    (out/'Center.swift').write_text(center)
    (out/'Support.swift').write_text(support + poll + '\n}\n')
    sources = ['Models.swift','ParcelAddress.swift','ExpressNotificationState.swift','TelegramBotAPI.swift','TelegramOrderState.swift']
    subprocess.run(['xcrun','swiftc','-swift-version','5','-parse-as-library']+sources+[str(out/'Center.swift'),str(out/'Support.swift'),'Tests/TelegramMonitoringTests.swift','-o',str(out/'Tests')],check=True)
    subprocess.run([str(out/'Tests')],check=True)
PY
