#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
SHIFT_READINESS_TEST_DIR=$(mktemp -d)
trap 'rm -rf "$SHIFT_READINESS_TEST_DIR"' EXIT
xcrun swiftc -swift-version 5 -parse-as-library Tests/OriginalShiftReadinessTests.swift -o "$SHIFT_READINESS_TEST_DIR/OriginalShiftReadinessTests"
"$SHIFT_READINESS_TEST_DIR/OriginalShiftReadinessTests"
