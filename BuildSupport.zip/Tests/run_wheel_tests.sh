#!/bin/bash
set -euo pipefail
WHEEL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WHEEL_TEST_DIR="$(mktemp -d -t vv-wheel-tests.XXXXXX)"
trap 'rm -rf "$WHEEL_TEST_DIR"' EXIT
swiftc "$WHEEL_ROOT/WheelProtocol.swift" "$WHEEL_ROOT/WheelSettingsProtocol.swift" "$WHEEL_ROOT/Tests/WheelProtocolTests.swift" -o "$WHEEL_TEST_DIR/wheel-tests"
"$WHEEL_TEST_DIR/wheel-tests"
swiftc "$WHEEL_ROOT/WheelProtocol.swift" "$WHEEL_ROOT/WheelSettingsProtocol.swift" "$WHEEL_ROOT/Tests/WheelSettingsTests.swift" -o "$WHEEL_TEST_DIR/wheel-settings-tests"
"$WHEEL_TEST_DIR/wheel-settings-tests" "$WHEEL_ROOT/Tests/WheelFirmwareEvidence.json"

swiftc "$WHEEL_ROOT/WheelProtocol.swift" "$WHEEL_ROOT/WheelSettingsProtocol.swift" "$WHEEL_ROOT/WheelDrivers.swift" "$WHEEL_ROOT/WheelInMotionDriver.swift" "$WHEEL_ROOT/Tests/WheelDriverTests.swift" -o "$WHEEL_TEST_DIR/wheel-driver-tests"
"$WHEEL_TEST_DIR/wheel-driver-tests"

swiftc "$WHEEL_ROOT/WheelProtocol.swift" "$WHEEL_ROOT/WheelSettingsProtocol.swift" "$WHEEL_ROOT/WheelMetrics.swift" "$WHEEL_ROOT/WheelDashboardPreferences.swift" "$WHEEL_ROOT/WheelSpeedPreferences.swift" "$WHEEL_ROOT/WheelRideStore.swift" "$WHEEL_ROOT/WheelAlarmPolicy.swift" "$WHEEL_ROOT/Tests/WheelStateTests.swift" -o "$WHEEL_TEST_DIR/wheel-state-tests"
"$WHEEL_TEST_DIR/wheel-state-tests"

swiftc "$WHEEL_ROOT/WheelProtocol.swift" "$WHEEL_ROOT/WheelSettingsProtocol.swift" "$WHEEL_ROOT/WheelMetrics.swift" "$WHEEL_ROOT/WheelDashboardPreferences.swift" "$WHEEL_ROOT/WheelSpeedPreferences.swift" "$WHEEL_ROOT/WheelRideStore.swift" "$WHEEL_ROOT/WheelAlarmPolicy.swift" "$WHEEL_ROOT/Tests/WheelRideThrottleTests.swift" -o "$WHEEL_TEST_DIR/wheel-ride-throttle-tests"
"$WHEEL_TEST_DIR/wheel-ride-throttle-tests"

swiftc "$WHEEL_ROOT/WheelProtocol.swift" "$WHEEL_ROOT/WheelSettingsProtocol.swift" "$WHEEL_ROOT/WheelDrivers.swift" "$WHEEL_ROOT/WheelInMotionDriver.swift" "$WHEEL_ROOT/Tests/WheelDialectTests.swift" -o "$WHEEL_TEST_DIR/wheel-dialect-tests"
"$WHEEL_TEST_DIR/wheel-dialect-tests"
