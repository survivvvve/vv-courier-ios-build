#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
PAYMENT_TEST_DIR=$(mktemp -d)
trap 'rm -rf "$PAYMENT_TEST_DIR"' EXIT
python3 - "$PAYMENT_TEST_DIR" <<'PY'
from pathlib import Path
import sys
out=Path(sys.argv[1])
for name,marker in [('Inspection','#if canImport(SwiftUI)'),('Terminal','struct TerminalView'),('Schedule','struct ScheduleView')]:
    s=Path(name+'.swift').read_text().split(marker)[0].replace('import SwiftUI','import Foundation').replace('import CoreImage.CIFilterBuiltins\n','')
    (out/(name+'.swift')).write_text(s)
PY
xcrun swiftc -swift-version 5 Models.swift ParcelAddress.swift ParcelMapPayload.swift ColdControlSignal.swift CourierAPI.swift OrderActions.swift LocationService.swift QueueModels.swift PaymentModels.swift PaymentAPI.swift "$PAYMENT_TEST_DIR"/*.swift Tests/PaymentTests.swift -o "$PAYMENT_TEST_DIR/PaymentTests"
"$PAYMENT_TEST_DIR/PaymentTests"
