import Foundation

final class InspectionFixtureProtocol: URLProtocol {
    static var handler: ((URLRequest) throws -> Any)!
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let result = try Self.handler(request)
            client?.urlProtocol(self, didReceive: HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: ["Content-Type": "application/json"])!, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: try JSONSerialization.data(withJSONObject: result))
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

@main struct InspectionTests {
    static func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open(); defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 4096)
            while stream.hasBytesAvailable {
                let count = stream.read(&buffer, maxLength: buffer.count)
                if count <= 0 { break }; data.append(contentsOf: buffer.prefix(count))
            }
        }
        return data.isEmpty ? [:] : try JSONSerialization.jsonObject(with: data) as! [String: Any]
    }
    static func rejects(_ action: () async throws -> Void) async {
        do { try await action(); preconditionFailure("Expected rejection") } catch {}
    }
    static func main() async throws {
        var gate = ScannerCodeGate()
        precondition(gate.accept("  123  ", now: 1) == "123")
        precondition(gate.accept("123", now: 1.5) == nil)
        precondition(gate.accept("124", now: 1.6) == "124")
        precondition(gate.accept("123", now: 2.3) == "123")
        for invalid in ["1e100", "-1e100", "nan", "inf", "1.5", "true", "99"] {
            precondition(!PackageInspectionRules.isChecked(["check": invalid], after: false))
            precondition(!PackageInspectionRules.isChecked(["check_after": invalid], after: true))
        }
        var ownership = InspectionRequestOwnership()
        let old = ownership.begin(owner: "old-account")
        precondition(ownership.accepts(old, owner: "old-account", cancelled: false))
        precondition(!ownership.accepts(old, owner: "new-account", cancelled: false))
        let new = ownership.begin(owner: "new-account")
        precondition(!ownership.accepts(old, owner: "old-account", cancelled: false), "Late old-account readback must never apply even if caller was not cancelled")
        precondition(!ownership.accepts(new, owner: "new-account", cancelled: true))
        let replaced = ownership.begin(owner: "new-account")
        precondition(!ownership.accepts(new, owner: "new-account", cancelled: false), "A newer refresh supersedes an earlier response in the same account")
        ownership.invalidate()
        precondition(!ownership.accepts(replaced, owner: "new-account", cancelled: false))
        let pendingSnapshot = InspectionSnapshot(parcels: [Parcel(["id_parcel": "1"])], rows: [["id_parcel": "1", "id_package": "pending", "check": 0, "cancelled": 0]], mode: 1, after: false)
        precondition(!pendingSnapshot.confirmsScan("pending"), "Unchecked readback cannot suppress rescan or claim successful confirmation")
        let checkedSnapshot = InspectionSnapshot(parcels: pendingSnapshot.parcels, rows: [["id_parcel": "1", "id_package": "pending", "check": 1, "cancelled": 0]], mode: 1, after: false)
        precondition(checkedSnapshot.confirmsScan("pending"))
        precondition(PackageInspectionRules.isChecked(["check": "2"], after: false))
        precondition(!PackageInspectionRules.allChecked([], after: false))
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [InspectionFixtureProtocol.self]
        let transport = URLSession(configuration: configuration)
        defer { transport.invalidateAndCancel() }
        let api = CourierAPI(session: Session(token: "offline-only", courierID: "1"), transport: transport)
        var parcels: [[String: Any]] = (1...8).map { ["id_parcel": String($0), "id_general_view": "0000\($0)", "parcel_status": "pickuped", "shopno": 101] }
        var rows: [[String: Any]] = (1...8).flatMap { id in
            (1...2).map { index in ["id_parcel": String(id), "id_package": "P\(id)-\(index)", "cells": "СО-1-1", "check": 0, "check_after": 0, "cancelled": 0] }
        }
        let allIDs = parcels.map { string($0["id_parcel"]) }
        var mode = 1, skipBefore = false, skipAfter = false
        var writes: [[String: Any]] = [], departures = 0, changes = 0
        var errorOnNextScan = false, timeoutNextScan = false
        var onPackagesRead: (() -> Void)?
        InspectionFixtureProtocol.handler = { request in
            precondition(request.url?.host == "delivery-api.vkusvill.ru", "All requests intercepted offline")
            let path = request.url!.path, body = try body(request)
            if path.hasSuffix(Feed.mine.endpoint) {
                return ["parcels": parcels, "checking": ["all_packages_inspection_before": mode, "parcels_packages_inspection_after": ["1": mode]]]
            }
            if path.hasSuffix("checking/get_packages") {
                onPackagesRead?()
                return ["package_codes": rows + [rows[0], ["id_parcel": "999", "id_package": "FOREIGN", "cells": "CO-X", "check": 0]]]
            }
            if path.hasSuffix("/courier/shops") { return ["shops": [["shopno": 101, "skip_scan_before": skipBefore, "skip_scan_after": skipAfter]]] }
            if path.hasSuffix("checking/package_codes_reasons") { return ["reasons": [["id": 7, "reason": "Стикер повреждён"]]] }
            if path.hasSuffix("checking/parcels/scan_package") {
                writes.append(body)
                precondition(Set((body["parcels"] as! [Int]).map(String.init)) == (truth(body["after"]) ? Set(["1"]) : Set(allIDs)), "Scan must include entire current batch")
                if errorOnNextScan { errorOnNextScan = false; return ["code": 30, "message": "Отсканирован чужой пакет"] }
                let index = rows.firstIndex { string($0["id_package"]) == string(body["id_package"]) }!
                rows[index][truth(body["after"]) ? "check_after" : "check"] = body["check"]
                if timeoutNextScan { timeoutNextScan = false; throw URLError(.timedOut) }
                return ["is_finished": false]
            }
            if path.hasSuffix("courier/activity") { return ["res": 1] }
            if path.hasSuffix("courier/start_delivery") { departures += 1; return [:] }
            if path.hasSuffix("courier/get_parcel") { return ["parcel": parcels.first { string($0["id_parcel"]) == string(body["id_parcel"]) }!] }
            if path.hasSuffix("courier/change_task_status") {
                changes += 1
                let index = parcels.firstIndex { string($0["id_parcel"]) == string(body["id_parcel"]) }!
                parcels[index]["parcel_status"] = body["status"]
                return [:]
            }
            preconditionFailure("Unexpected offline request: " + path)
        }
        let snapshot = try await api.inspectionSnapshot()
        precondition(snapshot.parcels.count == 8 && snapshot.packages.count == 16)
        precondition(Set(snapshot.packages.map(\.id)).count == 16, "Same cell must never merge distinct packages")
        precondition(snapshot.packages.allSatisfy { $0.cell == "СО-1-1" })
        precondition(snapshot.parcels.first?.label == "00001", "Skip groups preserve last five digits")
        // A real URLProtocol response from the previous session arrives after
        // the visible owner changed. The same coordinator used by the view
        // rejects it despite the HTTP read succeeding and Task not cancelling.
        var visibleOwner = "old-account", renderedParcelIDs: [String] = []
        let delayed = ownership.begin(owner: visibleOwner)
        onPackagesRead = { visibleOwner = "new-account"; _ = ownership.begin(owner: visibleOwner) }
        let delayedSnapshot = try await api.inspectionSnapshot()
        if ownership.accepts(delayed, owner: visibleOwner, cancelled: false) { renderedParcelIDs = delayedSnapshot.parcelIDs }
        precondition(renderedParcelIDs.isEmpty && !delayedSnapshot.parcels.isEmpty, "Successful old-owner read must never overwrite new-owner UI")
        onPackagesRead = nil
        let missingPackage = InspectionSnapshot(parcels: snapshot.parcels, rows: [["id_parcel": "1", "id_package": "one", "check": 1]], mode: 1, after: false)
        precondition(!missingPackage.allChecked, "A missing order package list cannot confirm the whole batch")
        await rejects { _ = try await api.scanInspectionPackage(expectedIDs: allIDs, code: "FOREIGN") }
        await rejects { _ = try await api.scanInspectionPackage(expectedIDs: Array(allIDs.dropLast()), code: "P1-1") }
        await rejects { _ = try await api.scanInspectionPackage(expectedIDs: allIDs, code: "P1-1", reasonID: "7") }
        precondition(writes.isEmpty)
        _ = try await api.scanInspectionPackage(expectedIDs: allIDs, code: "ACTUAL-TT-CODE", ttPackageID: "P1-1")
        precondition(number(writes.last?["check"]) == 3 && string(writes.last?["qr"]) == "ACTUAL-TT-CODE")
        await rejects { _ = try await api.scanInspectionPackage(expectedIDs: allIDs, code: "P1-1") }
        skipBefore = true
        _ = try await api.scanInspectionPackage(expectedIDs: allIDs, code: "P1-2", reasonID: "7")
        precondition(number(writes.last?["check"]) == 2 && string(writes.last?["reason"]) == "Стикер повреждён")
        _ = try await api.scanInspectionPackage(expectedIDs: allIDs, code: "P2-1", reasonID: "-1", customReason: "  QR затёрт  ")
        precondition(string(writes.last?["reason"]) == "QR затёрт")
        await rejects { _ = try await api.scanInspectionPackage(expectedIDs: allIDs, code: "P2-2", reasonID: "999") }
        await rejects { _ = try await api.scanInspectionPackage(expectedIDs: allIDs, code: "P2-2", reasonID: "-1", customReason: " ") }
        let count = writes.count
        await rejects { _ = try await api.scanInspectionPackage(expectedIDs: ["1"], code: "P1-1", after: true, parcelID: "1", reasonID: "7") }
        precondition(writes.count == count, "Missing after permission must not produce any mutation")
        skipAfter = true
        _ = try await api.scanInspectionPackage(expectedIDs: ["1"], code: "P1-1", after: true, parcelID: "1", reasonID: "7")
        precondition(truth(writes.last?["after"]))
        errorOnNextScan = true
        await rejects { _ = try await api.scanInspectionPackage(expectedIDs: allIDs, code: "P2-2") }
        precondition(!PackageInspectionRules.isChecked(rows[3], after: false), "HTTP 200 business error is not confirmation")
        timeoutNextScan = true
        let beforeTimeout = writes.count
        await rejects { _ = try await api.scanInspectionPackage(expectedIDs: allIDs, code: "P2-2") }
        precondition(writes.count == beforeTimeout + 1, "Uncertain write must never automatically repeat")
        let readback = try await api.inspectionSnapshot()
        precondition(readback.packages.first { $0.packageID == "P2-2" }?.checked == true)
        mode = 2
        let beforeWrongMode = writes.count
        await rejects { _ = try await api.scanInspectionPackage(expectedIDs: allIDs, code: "P3-1") }
        precondition(writes.count == beforeWrongMode)
        mode = 1
        await rejects { try await api.startDeliveryBatch(expectedParcelIDs: allIDs) }
        precondition(departures == 0 && changes == 0, "Uninspected batch cannot start")
        for index in rows.indices { rows[index]["check"] = 1 }
        try await api.startDeliveryBatch(expectedParcelIDs: allIDs)
        precondition(departures == 1 && changes == 8, "One departure and all eight serial status transitions")
        precondition(parcels.allSatisfy { string($0["parcel_status"]) == "on_the_way" })
        await rejects { try await api.startDeliveryBatch(expectedParcelIDs: allIDs) }
        precondition(departures == 1, "Already departed batch must not send another departure")
        // Real partner flow: fresh membership, explicit arrival receipt when
        // task261 is on, one suborder confirmation, then verified batch start.
        let partner = Parcel(["id_parcel": "88", "id_general_view": "100088", "shopno": 101, "parcel_status": "pickuped", "has_partner_order": true])
        var partnerStatus = "pickuped", partnerChecked = false, arrivalRequired = true
        var partnerWrites = 0, arrivalWrites = 0, partnerDepartures = 0, partnerChanges = 0
        var partnerReadbackStale = false
        func partnerResponse() -> [String: Any] {
            ["parcel_addresses": [["id_partner": 3, "partner_name": "Учебный партнёр", "user_address": "Тестовая улица, 4", "suborders": [["order_id": 99001, "check": partnerChecked && !partnerReadbackStale ? 1 : 0, "collected_pkgs": 2, "order_weight": "1.250"]]]]]
        }
        InspectionFixtureProtocol.handler = { request in
            let path = request.url!.path, body = try body(request)
            var raw = partner.raw; raw["parcel_status"] = partnerStatus
            if path.hasSuffix(Feed.mine.endpoint) { return ["parcels": [raw], "checking": ["all_packages_inspection_before": 0]] }
            if path.hasSuffix("/v1/tasks/active") { return arrivalRequired ? [261] : [] }
            if path.hasSuffix("courier/shops") { return ["shops": [["shopno": 101, "get_order_check": 0]]] }
            if path.hasSuffix("checking/partner_orders/88") { return partnerResponse() }
            if path.hasSuffix("/v1/partner/arrive/99001") { arrivalWrites += 1; return [:] as [String: Any] }
            if path.hasSuffix("checking/update_partner_order") {
                precondition(number(body["parcel_id"]) == 88 && number(body["order_id"]) == 99001)
                precondition(body["check"] as? Bool != nil, "First-party confirmation uses Bool check")
                partnerWrites += 1; partnerChecked = truth(body["check"]); return [:] as [String: Any]
            }
            if path.hasSuffix("courier/activity") { return ["res": 1] }
            if path.hasSuffix("courier/start_delivery") { partnerDepartures += 1; return [:] as [String: Any] }
            if path.hasSuffix("courier/get_parcel") { return ["parcel": raw] }
            if path.hasSuffix("courier/change_task_status") { partnerChanges += 1; partnerStatus = string(body["status"]); return [:] as [String: Any] }
            preconditionFailure("Unexpected partner request " + path)
        }
        let partnerData = try await api.partnerPickupSnapshot(parcelID: "88")
        precondition(!partnerData.allChecked && partnerData.requiresArrival && partnerData.groups.first?.suborders.first?.label == "99001")
        await rejects { try await api.startDeliveryBatch(expectedParcelIDs: ["88"]) }
        precondition(partnerDepartures == 0 && partnerChanges == 0)
        await rejects { try await api.confirmPartnerPickup(parcelID: "88", orderID: "99001", checked: true) }
        precondition(partnerWrites == 0, "Flag261 must require the successful native arrival receipt")
        let arrival = try await api.arriveAtPartner(parcelID: "88", orderID: "99001")
        precondition(arrivalWrites == 1)
        partnerReadbackStale = true
        await rejects { try await api.confirmPartnerPickup(parcelID: "88", orderID: "99001", checked: true, arrival: arrival) }
        precondition(partnerWrites == 1, "Unconfirmed readback must stop without retrying the mutation")
        partnerReadbackStale = false
        let confirmedPartner = try await api.partnerPickupSnapshot(parcelID: "88")
        precondition(confirmedPartner.allChecked)
        try await api.startDeliveryBatch(expectedParcelIDs: ["88"])
        precondition(partnerDepartures == 1 && partnerChanges == 1 && partnerStatus == "on_the_way")
        // An ordinary partner without261 can confirm pickup directly; no fake
        // arrival is created and missing/ambiguous suborders still fail closed.
        partnerStatus = "pickuped"; partnerChecked = false; arrivalRequired = false
        try await api.confirmPartnerPickup(parcelID: "88", orderID: "99001", checked: true)
        precondition(partnerWrites == 2 && arrivalWrites == 1)
        do { _ = try PartnerPickupSnapshot.parse(["parcel_addresses": [["suborders": [["id_order": 1, "check": 0], ["id_order": 1, "check": 1]]]]], parcel: partner); preconditionFailure("Duplicate partner suborder accepted") } catch {}
        print("Inspection tests passed: 8 orders / 16 distinct packages, same cells, full batch, QR/TT/reasons, permissions, stale membership, business errors, timeout no-repeat, serial departure, partner arrival/pickup/readback/departure")
    }
}
