#!/bin/bash
set -euo pipefail
TELEGRAM_TEST_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TELEGRAM_TEST_DIR="$(mktemp -d -t vv-telegram-tests.XXXXXX)"
trap 'rm -rf "$TELEGRAM_TEST_DIR"' EXIT
xcrun swiftc -swift-version 5 "$TELEGRAM_TEST_ROOT/ExpressNotificationState.swift" "$TELEGRAM_TEST_ROOT/TelegramBotAPI.swift" "$TELEGRAM_TEST_ROOT/TelegramOrderState.swift" "$TELEGRAM_TEST_ROOT/Tests/TelegramOrderTests.swift" -o "$TELEGRAM_TEST_DIR/telegram-tests"
"$TELEGRAM_TEST_DIR/telegram-tests"
bash "$TELEGRAM_TEST_ROOT/Tests/run_telegram_monitoring_tests.sh"
