import Foundation

func truth(_ value: Any?) -> Bool { !["", "0", "false", "none", "<null>"].contains(string(value).lowercased()) }

@main enum ParcelCashChangeTests {
    static func main() {
        func result(_ text: String, due: Any = "2500") -> ParcelCashChange? { ParcelCashChange.calculate(comments: [text], amountDue: due) }
        precondition(result("Нужна сдача с 5000 рублей")?.change == 2500)
        precondition(result("Нужна сдача с 5 000 руб.")?.tendered == 5000)
        precondition(result("Сдача с 5\u{202f}000 ₽")?.change == 2500)
        precondition(result("СДАЧА СО 10000")?.change == 7500)
        precondition(result("Сдача с купюры 5000")?.change == 2500)
        precondition(result("Сдача с 5 тыс. рублей")?.change == 2500)
        precondition(result("Сдача с 5000,50 руб.", due: "2499,99")?.change == Decimal(string: "2500.51"))
        precondition(result("Сдача с 2500")?.change == 0)
        precondition(result("Сдача с 1000") == nil)
        precondition(result("Покупки на 5000 рублей, код 2500") == nil)
        precondition(result("Сдача не нужна") == nil)
        precondition(result("Не нужна сдача с 5000") == nil)
        precondition(result("Сдача с -5000") == nil)
        precondition(result("Сдача с 5000 или 10000") == nil)
        precondition(result("Сдача с 5000, сдача с 10000") == nil)
        precondition(result("Сдача с 5000", due: "") == nil)
        precondition(result("Сдача с 5000", due: NSNull()) == nil)
        precondition(result("Сдача с 5000", due: 0) == nil)
        var raw: [String: Any] = ["id_parcel": "cash-fixture", "pay_way": 4, "pay_summ": "2500", "reward": 138, "comment": "Нужна сдача с 5000 рублей", "comment_courier_address": "Нужна сдача с 10000"]
        precondition(Parcel(raw).cashChange?.change == 2500, "Use client comment and payment amount, never courier note or reward")
        raw["pay_way"] = 0
        precondition(Parcel(raw).cashChange == nil, "Online orders do not require cash change")
        precondition(!Parcel(raw).cashWithoutChange)
        raw.removeValue(forKey: "pay_way")
        precondition(Parcel(raw).cashChange == nil, "Only orders explicitly marked cash qualify")
        raw["pay_way"] = 4; raw["comment"] = "Без сдачи"
        precondition(Parcel(raw).cashChange == nil, "Courier note must not supply tendered cash")
        precondition(Parcel(raw).cashWithoutChange)
        raw["comment"] = "Оставить у двери"
        precondition(Parcel(raw).cashWithoutChange, "Cash without a change request means exact cash")
        raw["comment"] = "Сдача с 5000 или 10000"
        precondition(Parcel(raw).cashChange == nil && !Parcel(raw).cashWithoutChange, "Ambiguous request must not be shown as exact cash")
        raw["comment"] = "Нужна сдача с 5000"; raw["parcel_status"] = "delivered"; raw["pay_way_fact"] = 3
        precondition(Parcel(raw).effectivePaymentWay == 3 && Parcel(raw).cashChange == nil, "Closed order uses actual terminal payment, not its initial cash preference")
        raw["pay_way"] = 3; raw["pay_way_fact"] = 4
        precondition(Parcel(raw).cashChange?.change == 2500, "Actual cash payment is preserved in archived cards")
        print("Cash change: explicit buyer request, Decimal subtraction and ambiguity regression cases passed")
    }
}
