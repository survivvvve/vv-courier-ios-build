import Foundation

@main enum OriginalWebDiagnosticsTests {
    static var checks = 0
    static func check(_ condition: @autoclosure () -> Bool, _ label: String) {
        checks += 1
        precondition(condition(), label)
    }
    static func event() -> [String: Any] {
        ["kind": "diagnostic", "category": "type_undefined_property", "fatal": true,
         "path": "/main/my-tab", "property": "parcels", "version": "6.16.1",
         "frames": [["file": "index-2IuI5q2p.js", "line": 17, "column": 42]]]
    }
    static func main() throws {
        let suite = "vv-web-diagnostics-test-" + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = OriginalWebDiagnostics(defaults: defaults)
        let now = Date(timeIntervalSince1970: 1_793_870_000)
        let accepted = store.record(event(), at: now)
        check(accepted?.fatal == true && accepted?.property == .parcels, "Typed event accepted")
        check(accepted?.frames.first?.file == "index-2IuI5q2p.js", "Public basename retained")
        check(store.reportText.contains("type_undefined_property") && store.reportText.contains("/main/my-tab"), "Useful report carries only shape codes and route")

        let secrets = ["Bearer PRIVATE-SESSION", "999999999:DoNotPersistSecretToken", "+79990001234", "Apartment 99 private address"]
        var malicious = event()
        malicious["message"] = secrets[0]
        malicious["stack"] = secrets[1]
        malicious["token"] = secrets[1]
        malicious["headers"] = ["Authorization": secrets[0], "Cookie": secrets[2]]
        malicious["data"] = ["address": secrets[3]]
        malicious["path"] = "/order?id_parcel=555555&token=" + secrets[1]
        malicious["property"] = "Authorization"
        malicious["version"] = "6.16.1 " + secrets[0]
        malicious["frames"] = [["file": "https://courier.vkusvill.ru/assets/index.js?token=" + secrets[1], "line": 7, "column": 2]]
        let scrubbed = store.record(malicious, at: now)!
        check(scrubbed.path == .other && scrubbed.property == nil && scrubbed.version == nil && scrubbed.frames.isEmpty, "Untrusted route/query, identifiers, version and URL dropped")
        let data = defaults.data(forKey: "original.web.diagnostics.v1")!
        let persisted = String(data: data, encoding: .utf8)!
        for secret in secrets {
            check(!persisted.contains(secret) && !store.reportText.contains(secret), "No raw secret in storage or report")
        }
        check(!persisted.contains("headers") && !persisted.contains("message") && !persisted.contains("stack"), "Spoofed extra properties never serialized")

        for category in OriginalWebDiagnosticEvent.Category.allCases {
            var body = event(); body["category"] = category.rawValue
            check(store.record(body, at: now)?.category == category, "Each agreed category accepted")
        }
        for property in OriginalWebDiagnosticEvent.Property.allCases {
            var body = event(); body["property"] = property.rawValue
            check(store.record(body, at: now)?.property == property, "Each allowed property accepted")
        }
        for path in OriginalWebDiagnosticEvent.Path.allCases {
            var body = event(); body["path"] = path.rawValue
            check(store.record(body, at: now)?.path == path, "Each normalized path accepted")
        }
        for field in ["kind", "category", "fatal"] {
            var body = event(); body.removeValue(forKey: field)
            let count = store.events.count
            check(store.record(body, at: now) == nil && store.events.count == count, "Required typed fields reject malformed payload")
        }
        for raw in ["true", 1, 0, NSNull()] as [Any] {
            var body = event(); body["fatal"] = raw
            check(store.record(body, at: now) == nil, "String/integer cannot impersonate a Boolean")
        }
        for raw in ["Bearer PRIVATE-SESSION", "react_error_screen\nprivate", "UNKNOWN", 17] as [Any] {
            var body = event(); body["category"] = raw
            check(store.record(body, at: now) == nil, "Unknown category cannot smuggle text")
        }
        for raw in ["my-name", "__private_secret", "id_parcel?token=secret", String(repeating: "x", count: 10_000)] {
            var body = event(); body["property"] = raw
            check(store.record(body, at: now)?.property == nil, "Unknown ASCII or nonidentifier property omitted")
        }
        for raw in ["6", "v6.16.1", "6..1", "6.16.1?secret", "99999.1", "1.2.3.4.5", String(repeating: "1", count: 10_000)] {
            var body = event(); body["version"] = raw
            check(store.record(body, at: now)?.version == nil, "Version format is bounded digits and dots only")
        }
        for file in ["../index.js", "/var/private/token.js", "https://site/index.js", "index.js?token=abc", "cookie.js", "Bearer.js", "Authorization.js", "password-hash.js", "address.js", "phone.js", "index-75550001234.js", "../../safe.mjs", "🦊.js", ".hidden.js", "index.js\n", String(repeating: "x", count: 121) + ".js"] {
            var body = event(); body["frames"] = [["file": file, "line": 1, "column": 2]]
            check(store.record(body, at: now)?.frames.isEmpty == true, "Filename cannot contain paths, tokens, contacts or control text")
        }
        for raw in [true, "7", 0, -1, 10_000_001, 1.5, Double.nan, Double.infinity] as [Any] {
            var body = event(); body["frames"] = [["file": "index.js", "line": raw, "column": 2]]
            check(store.record(body, at: now)?.frames.isEmpty == true, "Line must be a bounded integer, not Bool/string/nonfinite")
        }
        var many = event()
        many["frames"] = (0..<100).map { ["file": "module.mjs", "line": $0 + 1, "column": 2, "message": secrets[0]] as [String: Any] }
        check(store.record(many, at: now)?.frames.count == 6, "At most six frames accepted without copying extras")
        check(store.record(event(), at: Date(timeIntervalSince1970: .nan)) == nil, "Native invalid date cannot poison report")
        check(store.record(event(), at: Date(timeIntervalSince1970: 1e100)) == nil, "Unrepresentable date cannot enter the report formatter")

        store.clear()
        for index in 0..<27 { _ = store.record(event(), at: now.addingTimeInterval(Double(index))) }
        check(store.events.count == 20 && store.events.first?.recordedAt == now.addingTimeInterval(7), "Ring buffer keeps only latest twenty")
        check(defaults.data(forKey: "original.web.diagnostics.v1")!.count <= OriginalWebDiagnostics.maximumStoredBytes, "Persistent data is byte-bounded")
        let restored = OriginalWebDiagnostics(defaults: defaults)
        check(restored.events == store.events, "Sanitized events persist and restore")
        check(restored.reportText.contains("Событий: 20/20"), "Copyable report is bounded to the retained window")

        // Tampering with the stored envelope does not bypass field validation.
        var object = try JSONSerialization.jsonObject(with: defaults.data(forKey: "original.web.diagnostics.v1")!) as! [String: Any]
        var rows = object["events"] as! [[String: Any]]
        rows[0]["message"] = secrets[0]
        rows[0]["property"] = "Authorization"
        rows[0]["frames"] = [["file": "/private/token.js", "line": 5, "column": 4]]
        rows[1]["kind"] = "spoofed"
        rows[2]["recordedAt"] = 1e100
        object["events"] = rows
        defaults.set(try JSONSerialization.data(withJSONObject: object), forKey: "original.web.diagnostics.v1")
        let revalidated = OriginalWebDiagnostics(defaults: defaults)
        check(revalidated.events.first?.property == nil && revalidated.events.first?.frames.isEmpty == true, "Reload revalidates stored fields")
        check(revalidated.events.count == 18, "Forged kind and unrepresentable stored date rejected on reload")
        check(!String(data: defaults.data(forKey: "original.web.diagnostics.v1")!, encoding: .utf8)!.contains(secrets[0]), "Canonical rewrite removes injected raw fields")
        defaults.set(Data(repeating: 65, count: OriginalWebDiagnostics.maximumStoredBytes + 1), forKey: "original.web.diagnostics.v1")
        check(OriginalWebDiagnostics(defaults: defaults).events.isEmpty && defaults.data(forKey: "original.web.diagnostics.v1") == nil, "Oversized cache removed without parsing")
        defaults.set(Data("not JSON".utf8), forKey: "original.web.diagnostics.v1")
        check(OriginalWebDiagnostics(defaults: defaults).events.isEmpty, "Corrupt cache is harmless")
        restored.clear()
        check(restored.events.isEmpty && defaults.data(forKey: "original.web.diagnostics.v1") == nil, "User clear removes retained diagnostics")
        print("Original web diagnostics: \(checks) checks passed; bounded private-free local persistence, no network.")
    }
}
