#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
CORE_TEST_DIR=$(mktemp -d)
trap 'rm -rf "$CORE_TEST_DIR"' EXIT
python3 - "$CORE_TEST_DIR" <<'PY'
from pathlib import Path
import sys
out=Path(sys.argv[1])
for name,marker in [('Archive','struct ArchiveView'),('IncomeView','struct IncomeView'),('Inspection','#if canImport(SwiftUI)'),('Schedule','struct ScheduleView'),('Terminal','struct TerminalView')]:
    s=Path(name+'.swift').read_text().split(marker)[0].replace('import SwiftUI','import Foundation').replace('import UIKit\n','').replace('import CoreImage.CIFilterBuiltins\n','')
    (out/(name+'.swift')).write_text(s)
(out/'ParcelPackages.swift').write_text(Path('ParcelPackages.swift').read_text().split('import SwiftUI')[0])
PY
xcrun swiftc -swift-version 5 Models.swift ParcelAddress.swift ParcelMapModels.swift ParcelMapPayload.swift ColdControlSignal.swift SessionStore.swift CourierAPI.swift Demo.swift OrderActions.swift LocationService.swift QueueModels.swift "$CORE_TEST_DIR"/*.swift Tests/FeedRegressionTests.swift -o "$CORE_TEST_DIR/FeedRegressionTests"
"$CORE_TEST_DIR/FeedRegressionTests"
xcrun swiftc -swift-version 5 Models.swift ParcelAddress.swift ParcelMapModels.swift ParcelMapPayload.swift ColdControlSignal.swift SessionStore.swift CourierAPI.swift Demo.swift OrderActions.swift LocationService.swift QueueModels.swift "$CORE_TEST_DIR"/*.swift Tests/APIFaultTests.swift -o "$CORE_TEST_DIR/APIFaultTests"
"$CORE_TEST_DIR/APIFaultTests"
xcrun swiftc -swift-version 5 Models.swift ParcelAddress.swift ParcelMapModels.swift ParcelMapPayload.swift ColdControlSignal.swift SessionStore.swift CourierAPI.swift Demo.swift OrderActions.swift LocationService.swift QueueModels.swift "$CORE_TEST_DIR"/*.swift Tests/ShiftActionTests.swift -o "$CORE_TEST_DIR/ShiftActionTests"
"$CORE_TEST_DIR/ShiftActionTests"
xcrun swiftc -swift-version 5 Models.swift ParcelAddress.swift ParcelMapModels.swift ParcelMapPayload.swift ColdControlSignal.swift SessionStore.swift CourierAPI.swift Demo.swift OrderActions.swift LocationService.swift QueueModels.swift "$CORE_TEST_DIR"/*.swift Tests/ScheduleContractTests.swift -o "$CORE_TEST_DIR/ScheduleContractTests"
"$CORE_TEST_DIR/ScheduleContractTests"
xcrun swiftc -swift-version 5 Models.swift ParcelAddress.swift ParcelMapModels.swift Demo.swift Tests/ParcelAddressMapTests.swift -o "$CORE_TEST_DIR/ParcelAddressMapTests"
"$CORE_TEST_DIR/ParcelAddressMapTests"
xcrun swiftc -swift-version 5 Models.swift ParcelAddress.swift ParcelCashChange.swift Tests/ParcelCashChangeTests.swift -o "$CORE_TEST_DIR/ParcelCashChangeTests"
"$CORE_TEST_DIR/ParcelCashChangeTests"
xcrun swiftc -swift-version 5 ColdControlSignal.swift Tests/ColdControlTests.swift -o "$CORE_TEST_DIR/ColdControlTests"
"$CORE_TEST_DIR/ColdControlTests"
Tests/run_queue_tests.sh
