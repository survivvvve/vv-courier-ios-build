import Foundation
import JavaScriptCore

@main struct OriginalDiagnosticsTests {
    static func main() throws {
        let context = JSContext()!
        var exception: String?
        context.exceptionHandler = { _, error in exception = error?.toString() }
        @discardableResult func evaluate(_ source: String) throws -> JSValue {
            exception = nil
            let result = context.evaluateScript(source)!
            if let exception {
                throw NSError(domain: "OriginalDiagnosticsTests", code: 1,
                              userInfo: [NSLocalizedDescriptionKey: exception])
            }
            return result
        }
        var checks = 0
        func check(_ expression: String, _ label: String) throws {
            checks += 1
            guard try evaluate(expression).toBool() else { fatalError(label) }
        }
        try evaluate("""
        var window=globalThis, self=globalThis;
        var transport=[], consoleCalls=[], routeValue='/main/done-tab?token=NEVER_SEND_SECRET';
        var listeners={}, domListeners={}, frames=[], observers=[], buttons=[];
        var console={error:function(...args){consoleCalls.push(args);return 'original-console-result';}};
        var originalConsole=console.error;
        function addEventListener(name,fn){(listeners[name]||(listeners[name]=[])).push(fn)}
        function removeEventListener(name,fn){listeners[name]=(listeners[name]||[]).filter(x=>x!==fn)}
        function fire(name,event){for(const fn of (listeners[name]||[]).slice())fn(event)}
        function requestAnimationFrame(fn){frames.push(fn);return frames.length}
        function cancelAnimationFrame(id){if(frames[id-1])frames[id-1]=null}
        function runFrames(){const f=frames;frames=[];for(const fn of f)if(fn)fn()}
        class MutationObserver{constructor(callback){this.callback=callback;this.live=false;observers.push(this)}observe(){this.live=true}disconnect(){this.live=false}}
        var document={readyState:'complete',body:{},queryCount:0,
          querySelectorAll(){this.queryCount++;return buttons},
          addEventListener(name,fn){domListeners[name]=fn},
          removeEventListener(name,fn){if(domListeners[name]===fn)delete domListeners[name]}};
        function mutate(text){for(const o of observers)if(o.live)o.callback([{type:'childList',addedNodes:[{textContent:text}]}])}
        function start(version='6.16.1'){
          transport=[];
          return __vvInstallDiagnostics({send:event=>transport.push(event),route:()=>routeValue,version});
        }
        function sample(message,name='TypeError',stack='handler@https://courier.vkusvill.ru/assets/index-AbC_1.js?token=NEVER_SEND_SECRET:12:34'){
          return {name,message,stack};
        }
        function screen(text,visible=true){
          const parent={textContent:text,parentElement:null};
          return {textContent:'Рестарт',parentElement:parent,getClientRects(){return visible?[{}]:[]}};
        }
        """)
        let runtime = try String(contentsOfFile: "Resources/OriginalDiagnostics.js", encoding: .utf8)
        try evaluate(runtime)
        try check("typeof __vvInstallDiagnostics==='function' && transport.length===0", "Loading the script must not start network work")
        try evaluate("var stop=start();var result=console.error(sample(\"Cannot read properties of undefined (reading 'parcels')\"));")
        try check("result==='original-console-result' && consoleCalls.length===1", "Preserve original console behavior")
        try check("transport.length===1 && transport[0].category==='type_undefined_property' && transport[0].property==='parcels'", "Classify the actual nullable order field")
        try check("transport[0].kind==='diagnostic' && transport[0].fatal===false && transport[0].path==='/main/done-tab' && transport[0].version==='6.16.1'", "Emit only normalized route and public version")
        try check("transport[0].frames.length===1 && transport[0].frames[0].file==='index-AbC_1.js' && transport[0].frames[0].line===12 && transport[0].frames[0].column===34", "Keep useful frame basename and location")
        try check("!JSON.stringify(transport).includes('NEVER_SEND_SECRET') && !JSON.stringify(transport).includes('https:') && !JSON.stringify(transport).includes('reading')", "Never retain URL, query or raw message")

        try evaluate("fire('error',{error:sample(\"Cannot read properties of undefined (reading 'parcels')\")});")
        try check("transport.length===1", "Deduplicate the same React/window exception")
        try evaluate("console.error(sample(\"null is not an object (evaluating 'state.orders.map')\"));")
        try check("transport[1].category==='type_null_property' && transport[1].property==='map'", "Classify Safari object errors without retaining expression")
        try evaluate("console.error(sample(\"Cannot read property 'length' of null\"));")
        try check("transport[2].category==='type_null_property' && transport[2].property==='length'", "Classify old WebKit nullable property errors")
        try evaluate("console.error(sample(\"Cannot read properties of undefined (reading 'properties_v2')\"));")
        try check("transport[transport.length-1].property==='properties_v2'", "Keep the known order-card field as code metadata")
        for method in ["map", "forEach", "concat", "filter"] {
            try evaluate("console.error(sample('state.parcels.\(method) is not a function'));")
            try check("transport[transport.length-1].category==='type_not_function_\(method)'", "Classify \(method) rather than customer text")
        }
        try evaluate("console.error(sample(\"Failed to execute 'insertBefore' on 'Node': confidential customer text\",'NotFoundError'));")
        try check("transport[transport.length-1].category==='dom_insert_before'", "Capture DOM insertion failures without exception suffix")
        try evaluate("console.error(sample(\"Failed to execute 'removeChild' on 'Node': confidential customer text\",'NotFoundError'));")
        try check("transport[transport.length-1].category==='dom_remove_child'", "Capture DOM removal failures")
        try evaluate("console.error(sample('Invalid time value','RangeError'));console.error('RangeError: Invalid time value');")
        try check("transport.some(e=>e.category==='range_invalid_time')", "Recognize invalid dates")
        try evaluate("fire('unhandledrejection',{reason:{privateData:'NEVER_SEND_SECRET',phone:'+79990000000',address:'PRIVATE_ADDRESS'}});")
        try check("transport[transport.length-1].category==='promise_rejection'", "Capture promise rejection without dumping arbitrary objects")

        try evaluate("stop();stop=start();routeValue='/buyer/79990000000/NEVER_SEND_SECRET?address=PRIVATE_ADDRESS';console.error(sample(\"Cannot read properties of null (reading 'NEVER_SEND_SECRET')\"));")
        try check("transport[0].category==='type_null_property' && !('property' in transport[0]) && transport[0].path==='/<other>'", "Drop unknown property identifiers and arbitrary routes")
        try evaluate("routeValue='/main/queue-tab/cluster/123456?phone=PRIVATE_ADDRESS';console.error(sample('x.map is not a function')); ")
        try check("transport[1].path==='/main/queue-tab/cluster/:id'", "Redact identifiers in recognized dynamic routes")
        try evaluate("stop();stop=start('NEVER_SEND_SECRET');console.error(sample('PRIVATE_ADDRESS +79990000000 token=NEVER_SEND_SECRET','Error')); ")
        try check("!('version' in transport[0]) && transport[0].category==='error'", "Reject non-version values and arbitrary message text")
        try evaluate("console.error(sample('x.filter is not a function','TypeError','at https://courier.vkusvill.ru/assets/BearerSecret.js:5:6\\nat https://courier.vkusvill.ru/assets/79990000000.js:7:8\\nat https://evil.example/assets/index-a1.js?token=NEVER_SEND_SECRET:9:10\\nat https://courier.vkusvill.ru/order?token=NEVER_SEND_SECRET:11:12')); ")
        try check("!('frames' in transport[1])", "Reject credential/phone filenames, non-code routes and third-party URLs")
        try evaluate("fire('error',{message:'Uncaught TypeError: Cannot read properties of null (reading \\\"length\\\")',filename:'https://courier.vkusvill.ru/assets/page-Z1.js?private=NEVER_SEND_SECRET',lineno:81,colno:22});")
        try check("transport[2].category==='type_null_property' && transport[2].frames[0].file==='page-Z1.js'", "Window errors keep sanitized source coordinates")
        try evaluate("var hostile={get name(){throw new Error('NEVER_SEND_SECRET')}};console.error(hostile);fire('unhandledrejection',{reason:hostile});")
        try check("!JSON.stringify(transport).includes('NEVER_SEND_SECRET') && !JSON.stringify(transport).includes('PRIVATE_ADDRESS') && !JSON.stringify(transport).includes('79990000000')", "Hostile getters and all message forms remain private")

        try evaluate("stop();routeValue='/main/my-tab';buttons=[];stop=start();buttons=[screen('Что-то пошло не так...Пожалуйста, попробуйте перезагрузить приложениеРестарт')];mutate('Что-то пошло не так...');runFrames();")
        try check("transport.length===1 && transport[0].category==='react_error_screen' && transport[0].fatal===true", "Detect the exact shipped React error screen")
        try evaluate("mutate('Рестарт');runFrames();")
        try check("transport.length===1", "Repeated error-screen mutations do not flood native logs")
        try evaluate("routeValue='/order';mutate('Рестарт');runFrames();")
        try check("transport.length===1", "A document reports only one fatal screen even if its route changes")
        try evaluate("stop();buttons=[screen('Покупатель написал: Рестарт PRIVATE_ADDRESS')];stop=start();")
        try check("transport.length===0", "A customer comment containing Restart is not a fatal screen")
        try evaluate("stop();buttons=[screen('Что-то пошло не так...Пожалуйста, попробуйте перезагрузить приложениеРестарт',false)];stop=start();")
        try check("transport.length===0", "Hidden error UI is not reported as the current screen")
        try evaluate("stop();buttons=[];stop=start();var queriesBefore=document.queryCount;for(let i=0;i<500;i++)mutate('');runFrames();")
        try check("document.queryCount===queriesBefore && transport.length===0", "Map mutation bursts do not rescan the page")
        try evaluate("buttons=[screen('Что-то пошло не так...Пожалуйста, попробуйте перезагрузить приложениеРестарт')];var records=Array.from({length:100},()=>({type:'childList',addedNodes:[{textContent:''}]}));records.push({type:'childList',addedNodes:[{textContent:'Рестарт'}]});for(const o of observers)if(o.live)o.callback(records);runFrames();")
        try check("transport.length===1 && transport[0].fatal", "A fatal screen after a large map mutation batch is still detected")
        try evaluate("stop();buttons=[];stop=start();for(let i=1;i<=40;i++)console.error(sample('x.map is not a function','TypeError',`https://courier.vkusvill.ru/assets/index-A1.js:${i}:2`));")
        try check("transport.length<=8 && transport.length>0", "The pending queue is bounded under synchronous console flooding")
        try evaluate("buttons=[screen('Что-то пошло не так...Пожалуйста, попробуйте перезагрузить приложениеРестарт')];mutate('Рестарт');runFrames();")
        try check("transport.some(e=>e.fatal===true)", "A fatal screen can still be reported after ordinary error quota is exhausted")
        try check("transport.every(e=>JSON.stringify(e).length<1800 && !('message' in e) && !('stack' in e))", "Records have bounded code metadata only")

        try evaluate("stop();buttons=[];stop=start();for(let i=1;i<=30;i++)console.error(sample('PRIVATE_ADDRESS NEVER_SEND_SECRET','Error',`https://courier.vkusvill.ru/assets/index-Noise.js:${i}:2`));var ordinaryBefore=transport.length;")
        try evaluate("var ordinaryBefore=transport.length;console.error(sample(\"Cannot read properties of undefined (reading 'properties_v2')\",'TypeError','render@https://courier.vkusvill.ru/assets/index-Cause.js?token=NEVER_SEND_SECRET:555:66'));console.error(sample('PRIVATE_ADDRESS NEVER_SEND_SECRET','Error'));fire('unhandledrejection',{reason:{private:'NEVER_SEND_SECRET'}});")
        try check("transport.length===ordinaryBefore", "Errors after the ordinary quota remain in memory only")
        try evaluate("buttons=[screen('Что-то пошло не так...Пожалуйста, попробуйте перезагрузить приложениеРестарт')];mutate('Рестарт');runFrames();")
        try check("transport.filter(e=>e.fatal).length===2 && transport[transport.length-2].category==='type_undefined_property' && transport[transport.length-2].property==='properties_v2' && transport[transport.length-1].category==='react_error_screen'", "Fatal screen includes the actual late typed cause even after ordinary quota")
        try check("transport[transport.length-2].frames[0].file==='index-Cause.js' && transport[transport.length-2].frames[0].line===555 && transport[transport.length-2].frames[0].column===66", "Preserve the late cause's useful code frames")
        try check("!JSON.stringify(transport).includes('NEVER_SEND_SECRET') && !JSON.stringify(transport).includes('PRIVATE_ADDRESS') && !JSON.stringify(transport).includes('https:')", "The retained cause never contains a raw error, URL query or customer text")
        try evaluate("mutate('Рестарт');runFrames();fire('error',{error:sample(\"Cannot read properties of undefined (reading 'properties_v2')\")});mutate('Рестарт');runFrames();")
        try check("transport.filter(e=>e.fatal).length===2", "A repeated fatal screen sends neither the cause nor screen twice")

        try evaluate("stop();const before=transport.length;console.error(sample('x.filter is not a function'));fire('error',{error:sample('x.map is not a function')});mutate('Рестарт');runFrames();var stoppedCount=before;")
        try check("transport.length===stoppedCount && console.error===originalConsole && observers.every(o=>!o.live)", "Disposal restores the console, listeners and DOM observation")
        try evaluate("buttons=[];var oldStop=start();var newStop=start();console.error(sample('x.map is not a function'));")
        try evaluate("oldStop();console.error(sample('x.filter is not a function'));")
        try evaluate("newStop();")
        try check("transport.length===2 && console.error===originalConsole", "Reinstallation and stale disposers do not duplicate or stop the current installation")
        try evaluate("document.readyState='loading';transport=[];buttons=[screen('Что-то пошло не так...Пожалуйста, попробуйте перезагрузить приложениеРестарт')];var delayed=__vvInstallDiagnostics({send:e=>transport.push(e),route:()=>'/order'});var ready=domListeners.DOMContentLoaded;delayed();if(ready)ready();")
        try check("transport.length===0 && !domListeners.DOMContentLoaded", "Disposing before DOM readiness prevents late observation")
        try evaluate("document.readyState='complete';buttons=[];var failure=__vvInstallDiagnostics({send(){throw new Error('bridge absent')},route(){throw new Error('router absent')}});console.error(sample('x.map is not a function'));")
        try evaluate("failure();")
        try check("console.error===originalConsole", "Broken diagnostics transport cannot break the courier website")
        print("Original diagnostics: \(checks) checks passed; typed categories, privacy, exact React screen, dedup/quota and disposal. No network, account or order actions.")
    }
}
