# Cold-pack photo control evidence

Primary source: official courier web client 6.16.1, `/tmp/vv-current.js` in the development workspace. No user account, assignment, photo or live mutation was used for implementation tests.

- `n8` maps task flag 227 to `isPhotoControlOfFreezerBag`.
- The available/assembly/mine feed and queue-clusters loaders inspect the **boolean** `termocontrol.is_need_termocontrol`; the exact source `No` checks `typeof value === "boolean"`. Missing/null/numeric/string values are not assignments.
- `Zn.COLD_ELEMENTS_PHOTO_REQUIRED` is business error **102**; take-order, queue and start-shift flows open the cold-control modal on this response.
- `WZe`/`KZe`/`YZe`/`zZe` implement initial → photograph with pyrometer → photograph without pyrometer → explicitly report no cold packs. With pyrometer, the image must include bag/packs/device, temperature −20…+5 °C. The original capture is rear camera, height1024/quality20; no wheel firmware operations are involved.
- `qf` POSTs to `/v1/courier/{courierID}/freeze_photo` on `delivery-api.vkusvill.ru` with exactly `{photo_file,pirometr,freeze}`. `Xf` removes the dataURL prefix and base64 padding. No-packs sends `photo_file:null,pirometr:true,freeze:false` and tells the shop. Empty `{}` is the original success condition.
- `EI` confirms default API route version1 and route name`courier`; queue clusters use version3.

Native implementation distinguishes upload acknowledgement from subsequent restriction removal. After accepted upload, a status read uses the same queue-clusters response. When readback is true or unavailable, the app offers **status refresh**, never an automatic repeat upload. A false response clears the global incoming-task banner. While required, the task is reachable from that banner and not a permanent profile menu item.

`ColdControlTests.swift` uses an in-memory responder and synthetic JPEG bytes. It verifies strict boolean signals, all three payload branches, exact route, unpadded base64, missing-session rejection, nonempty-response rejection, and accepted-write/readback uncertainty. The physical camera, server assignment arrival, and production upload remain to be tested on iPhone.
