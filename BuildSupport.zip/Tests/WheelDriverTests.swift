import Foundation

@main enum WheelDriverTests {
    static var checks = 0
    static let now = Date(timeIntervalSince1970: 1_800_000_000)
    static func check(_ value: @autoclosure () -> Bool, _ label: String) { checks += 1; precondition(value(), label) }
    static func near(_ a: Double?, _ b: Double) -> Bool { a.map { abs($0-b) < 0.001 } ?? false }
    static func be(_ b: inout [UInt8], _ i: Int, _ value: UInt16) { b[i] = UInt8(truncatingIfNeeded: value >> 8); b[i+1] = UInt8(truncatingIfNeeded:value) }
    static func le(_ b: inout [UInt8], _ i: Int, _ value: UInt16) { b[i] = UInt8(truncatingIfNeeded:value); b[i+1] = UInt8(truncatingIfNeeded:value >> 8) }
    static func le32(_ b: inout [UInt8], _ i: Int, _ value: UInt32) { for n in 0..<4 { b[i+n] = UInt8(truncatingIfNeeded:value >> (n*8)) } }
    static func veteran(_ version: UInt16, legacy: Bool = false) -> Data {
        var b = [UInt8](repeating: 0,count: legacy ? 36 : 75)
        b[0...3] = [0xDC,0x5A,0x5C,legacy ? 32 : 71]
        be(&b,4,legacy ? 9000 : 14450); be(&b,6,UInt16(bitPattern:-123)); be(&b,16,123); be(&b,18,3000); be(&b,28,version)
        if !legacy { be(&b,34,7000); b[40...43] = [0x4C,0x43,3,0x23];b[45]=1;b[46]=8;b[47]=1; let crc=WheelFrameDecoder.crc32(Array(b.prefix(71)));for i in 0..<4 {b[71+i]=UInt8(truncatingIfNeeded:crc >> ((3-i)*8))} }
        return Data(b)
    }
    static func begode(_ tag: UInt8) -> [UInt8] { var b=[UInt8](repeating:0,count:24);b[0]=0x55;b[1]=0xAA;b[18]=tag;b[19]=0x18;b[20...23]=[0x5A,0x5A,0x5A,0x5A];return b }
    static func ks(_ tag: UInt8) -> [UInt8] { var b=[UInt8](repeating:0,count:20);b[0]=0xAA;b[1]=0x55;b[16]=tag;b[17]=0x14;b[18]=0x5A;b[19]=0x5A;return b }
    static func legacyReply(_ id: UInt32, _ payload: [UInt8]) -> Data {
        var b=[UInt8](repeating:0,count:16);le32(&b,0,id);le32(&b,4,UInt32(payload.count));b[12]=0xFE;b[13]=5;b[14]=1;b += payload
        return InMotionWheelDecoder.stuffed(b+[b.reduce(0,&+)],legacy:true)
    }
    static func motionReply(_ command: UInt8, _ data:[UInt8]) -> Data { InMotionWheelDecoder.modernQuery(command: command,data:data) }
    static func allSplits(_ data: Data, transport: WheelTransport, label: String) {
        for split in 0...data.count {
            var hub = WheelDriverHub(); hub.configure(transport)
            let result = hub.append(data.prefix(split),at:now) + hub.append(data.dropFirst(split),at:now)
            check(result.count == 1,"\(label) fragmented at \(split)")
        }
    }
    static func main() {
        for version: UInt16 in [1000,2010,3010,4010,5010,6010,7010,8010,9010,42010,43010,44010,45010] {
            var hub=WheelDriverHub();let sample=hub.append(veteran(version),at:now).first!.telemetry
            check(sample.family == .veteran && sample.firmware == Int(version),"Veteran/NOSFET version")
            check(sample.compatibleAlarm == (version == 6010),"Exact firmware capability isolation")
            check(sample.estimatedBattery != nil,"Known per-model voltage curve")
        }
        allSplits(veteran(6010),transport:.serial,label:"CRC Veteran")
        allSplits(veteran(1000,legacy:true),transport:.serial,label:"Legacy Veteran")
        var old=WheelDriverHub();let oldSample=old.append(veteran(1000,legacy:true),at:now).first!.telemetry
        check(oldSample.pwm == nil && oldSample.integrity == .framingOnly,"Legacy unsupported PWM stays nil")
        var latch=WheelFrameDecoder(acceptLegacy:true); _=latch.append(veteran(6010),at:now)
        check(latch.append(veteran(1000,legacy:true),at:now).isEmpty,"No CRC downgrade within session")
        var a=begode(0);be(&a,2,6000);be(&a,4,1000);be(&a,8,123);be(&a,10,125)
        var b=begode(4);be(&b,4,1000);b[15]=1
        var extra=begode(7);be(&extra,2,UInt16(bitPattern:-100));be(&extra,8,8000)
        var pack=begode(1);be(&pack,6,1340)
        let bg=Data("MPU6500\nNAME RS19\nJN v1.2\n".utf8)+Data(b)+Data(extra)+Data(pack)+Data(a)
        allSplits(bg,transport:.serial,label:"Begode")
        var bh=WheelDriverHub();let bs=bh.append(bg,at:now).first!.telemetry
        check(near(bs.speed,36) && near(bs.phaseCurrent,1.25),"Begode m/s+current scaling")
        check(near(bs.voltage,134) && near(bs.temperature,21) && near(bs.pwm,80),"Begode BMS+IMU+truePWM")
        check(bs.totalMeters == 1000 && bs.tripMeters == 123 && bs.lightOn == true,"Begode counters/light")
        check(near(bs.batteryReading?.power,134),"Battery power uses true current")
        let stale=bh.append(Data(a),at:now.addingTimeInterval(11)).first!.telemetry
        check(stale.voltage == nil && stale.pwm == nil && stale.totalMeters == nil,"Secondary frames do not remain fresh forever")
        check(bh.lightCommand(true,sample:bs) == Data([0x51]),"Begode light Q, not Sherman bytes")
        var km=ks(0xBB);let name=Array("KS-S22-141".utf8);km.replaceSubrange(2..<(2+name.count),with:name)
        var k=ks(0xA9);le(&k,2,12000);le(&k,4,4000);le(&k,6,0x1234);le(&k,8,0x5678);le(&k,10,UInt16(bitPattern:-100))
        var kp=ks(0xF5);kp[15]=83
        let king=Data(km)+Data(kp)+Data(k)
        allSplits(king,transport:.serial,label:"KingSong")
        var kh=WheelDriverHub();let ksamp=kh.append(king,at:now).first!.telemetry
        check(ksamp.modelName == "KS-S22" && ksamp.version == "1.41","KingSong model response")
        check(near(ksamp.speed,40) && near(ksamp.pwm,83) && ksamp.totalMeters == 0x12345678,"KingSong LE and swapped distance")
        check(ksamp.temperature == nil && ksamp.compatibleAlarm == false && kh.lightCommand(true,sample:ksamp) == nil,"Uncertain KS temperature/control not invented")
        check(kh.append(Data(k)+Data(k),at:now).count == 2,"Repeated valid frames remain separate observations")
        var slow=[UInt8](repeating:0,count:132);slow[104]=7;slow[107]=8
        var fast=[UInt8](repeating:0,count:76);le32(&fast,0,65536);le32(&fast,12,38120);le32(&fast,16,38120);le32(&fast,20,1000);le32(&fast,24,8000);fast[32]=30;fast[34]=32;le32(&fast,44,1234);le32(&fast,48,234)
        let im1=legacyReply(0x0F550114,slow)+legacyReply(0x0F550113,fast)
        allSplits(im1,transport:.inMotionV1,label:"InMotion legacy CAN")
        var ih=WheelDriverHub();ih.configure(.inMotionV1);let i1=ih.append(im1,at:now).first!.telemetry
        check(i1.modelName == "InMotion V8S" && near(i1.speed,36),"V1 model+model-specific conversion")
        check(i1.totalMeters == 1234 && i1.pwm == nil && near(i1.pitch,1),"V1 supported vs absent fields")
        var live=[UInt8](repeating:0,count:80);le(&live,0,14000);le(&live,2,123);le(&live,8,3450);le(&live,14,8000);le(&live,28,123);le(&live,34,5000);le(&live,36,5100);for i in 58...63 {live[i]=206};live[76]=2;live[18]=0xAA;live[19]=0xA5
        var totals=[UInt8](repeating:0,count:20);le32(&totals,0,321)
        let im2=motionReply(2,[1,2,9,2,0,0])+motionReply(0x11,totals)+motionReply(4,live)
        allSplits(im2,transport:.inMotionV2,label:"InMotion V2 escaped XOR")
        var mh=WheelDriverHub();mh.configure(.inMotionV2);let i2=mh.append(im2,at:now).first!.telemetry
        check(i2.modelName == "InMotion V14 50S" && near(i2.speed,34.5) && near(i2.pwm,80),"V2 carType+units")
        check(i2.totalMeters == 3210 && i2.tripMeters == 1230 && i2.lightOn == true && near(i2.temperature,30),"V2 stats+temps+light")
        check(i2.estimatedBattery == 51 && !i2.batteryIsEstimated,"V2 reported battery")
        var unknown=WheelDriverHub();unknown.configure(.inMotionV2)
        check(unknown.append(motionReply(2,[1,2,99,9])+motionReply(4,live),at:now).isEmpty,"Unknown V2 model must not fall back to V14")
        var v12=[UInt8](repeating:0,count:56);le(&v12,0,9500);le(&v12,4,4000);le(&v12,8,7000);for i in [40,41,43,44,45] {v12[i]=211}
        var v12h=WheelDriverHub();v12h.configure(.inMotionV2);let v12s=v12h.append(motionReply(2,[1,2,7,1])+motionReply(4,v12),at:now).first!.telemetry
        check(near(v12s.speed,40) && near(v12s.pwm,70) && near(v12s.temperature,35),"V12 has its own field offsets")
        var broken=im2;broken[broken.count-1] ^= 1
        var recovery=WheelDriverHub();recovery.configure(.inMotionV2)
        check(recovery.append(broken,at:now).isEmpty,"Bad XOR rejected")
        check(recovery.append(motionReply(4,live),at:now).count == 1,"Recovery after bad XOR")
        var noisy=WheelDriverHub();check(noisy.append(Data([0xDC,0x5A,0x5C,255])+king,at:now).first?.telemetry.family == .kingSong,"False magic cannot lock wrong driver")
        mh.configure(.serial);check(mh.family == nil && mh.append(Data(im2.suffix(10)),at:now).isEmpty,"Reconnect discards old driver fragments")
        check(InMotionWheelDecoder.modernQuery(command:2,data:[1],flags:0x11) == Data([0xAA,0xAA,0x11,2,2,1,0x10]),"Exact carType read-only query")
        var badBG = a; badBG[23] = 0
        var bgReject = WheelDriverHub()
        check(bgReject.append(Data(badBG),at:now).isEmpty,"Begode invalid footer rejected")
        var badKS = k; badKS[19] = 0
        var ksReject = WheelDriverHub()
        check(ksReject.append(Data(badKS),at:now).isEmpty,"KingSong invalid footer rejected")
        var tooFast = k; le(&tooFast,4,30000)
        check(ksReject.append(Data(tooFast),at:now).isEmpty,"KingSong impossible speed rejected")
        var wrongLegacy = im1; wrongLegacy[wrongLegacy.count-3] ^= 1
        var v1Reject = WheelDriverHub();v1Reject.configure(.inMotionV1)
        check(v1Reject.append(wrongLegacy,at:now).isEmpty,"Legacy CAN bad sum rejected")
        var unknownSlow = slow; unknownSlow[104] = 9;unknownSlow[107] = 9
        var unknownV1 = WheelDriverHub();unknownV1.configure(.inMotionV1)
        check(unknownV1.append(legacyReply(0x0F550114,unknownSlow)+legacyReply(0x0F550113,fast),at:now).isEmpty,"Unknown legacy model has no V8 fallback")
        check(bh.append(Data(a)+Data(a),at:now).count == 2,"Begode repeated frames")
        check(ih.append(legacyReply(0x0F550113,fast)+legacyReply(0x0F550113,fast),at:now).count == 2,"Legacy InMotion repeated frames")
        var repeatedModern = WheelDriverHub();repeatedModern.configure(.inMotionV2)
        check(repeatedModern.append(im2+motionReply(4,live),at:now).count == 2,"Modern InMotion repeated frames")
        print("Wheel drivers: \(checks) checks passed across all protocol families; fixtures only, no BLE.")
    }
}
