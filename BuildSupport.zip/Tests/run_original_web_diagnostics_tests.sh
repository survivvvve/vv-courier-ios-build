#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
DIAGNOSTIC_TEST_DIR=$(mktemp -d)
trap 'rm -rf "$DIAGNOSTIC_TEST_DIR"' EXIT
xcrun swiftc -swift-version 5 -D PURE_LOGIC -parse-as-library OriginalWebDiagnostics.swift Tests/OriginalWebDiagnosticsTests.swift -o "$DIAGNOSTIC_TEST_DIR/OriginalWebDiagnosticsTests"
"$DIAGNOSTIC_TEST_DIR/OriginalWebDiagnosticsTests"
