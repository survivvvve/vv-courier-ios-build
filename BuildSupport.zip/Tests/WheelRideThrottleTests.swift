
import Foundation
import Combine

@main struct RideThrottleTests {
    static func sample(_ date: Date, _ meters: UInt32) -> WheelTelemetry {
        var sample = WheelTelemetry(receivedAt: date, speed: 36, pwm: 25, voltage: nil, temperature: nil, firmware: 0, tripMeters: nil, totalMeters: meters, compatibleAlarm: false, alarm: nil, lightOn: nil)
        sample.odometerQuantumMeters = 1
        return sample
    }
    static func main() throws {
        precondition(Thread.isMainThread)
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("vv-ride-throttle-" + UUID().uuidString)
        let suite = "vv-ride-throttle-" + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { try? FileManager.default.removeItem(at: folder); defaults.removePersistentDomain(forName: suite) }
        let speed = WheelSpeedPreferences(defaults: defaults)
        let store = WheelRideStore(directory: folder, defaults: defaults, speedPreferences: speed)
        let wheel = UUID().uuidString
        let day = WheelRideStore.dayKey()
        store.setContext(courierID: "first", active: true, known: true, demo: false)
        let contextRevision = store.revision
        var publications: [TimeInterval] = []
        let subscription = store.$revision.dropFirst().sink { _ in publications.append(ProcessInfo.processInfo.systemUptime) }
        let start = Date().addingTimeInterval(-0.5)
        for index in 0..<100 { store.receive(sample(start.addingTimeInterval(Double(index) * 0.005), UInt32(1000 + index)), wheelID: wheel) }
        let summary = store.summary(courierID: "first", days: [day])
        precondition(summary.meters == 99 && abs(summary.movingSeconds - 0.495) < 0.00001, "Burst lost raw distance or moving time")
        precondition(store.revision == contextRevision, "Burst published per-frame summary revisions")
        store.flush()
        let restored = WheelRideStore(directory: folder, defaults: defaults, speedPreferences: speed)
        precondition(restored.summary(courierID: "first", days: [day]).meters == 99, "Flush omitted unpublished raw samples")
        RunLoop.main.run(until: Date().addingTimeInterval(1.1))
        precondition(publications.count == 1, "Trailing burst update missing or duplicated")
        RunLoop.main.run(until: Date().addingTimeInterval(0.1))
        precondition(publications.count == 1, "Idle store published repeatedly")

        store.disconnected()
        var frame: UInt32 = 2000
        let until = Date().addingTimeInterval(2.2)
        let firstRawIndex = publications.count
        repeat {
            store.receive(sample(Date(), frame), wheelID: wheel)
            frame += 1
            RunLoop.main.run(until: Date().addingTimeInterval(0.02))
        } while Date() < until
        let sustained = Array(publications.suffix(from: firstRawIndex))
        for (before, after) in zip(publications, publications.dropFirst()) {
            precondition(after - before >= 0.999, "Telemetry summary exceeded 1Hz")
        }
        let rawFrames = Int(frame - 2000)
        precondition(sustained.count >= 2 && sustained.count <= 3, "Unexpected sustained publication rate")
        precondition(store.summary(courierID: "first", days: [day]).meters == Double(99 + rawFrames - 1), "Sustained stream lost samples")

        let beforeContext = store.revision
        store.setContext(courierID: "second", active: true, known: true, demo: false)
        precondition(store.revision == beforeContext + 1 && store.currentCourierID == "second", "Context transition was delayed")
        let afterContext = store.revision
        RunLoop.main.run(until: Date().addingTimeInterval(1.1))
        precondition(store.revision == afterContext, "Old pending revision crossed the context boundary")
        precondition(!store.summary(courierID: "second", days: [day]).hasData, "Summary crossed couriers")
        let finalRestored = WheelRideStore(directory: folder, defaults: defaults, speedPreferences: speed)
        precondition(finalRestored.summary(courierID: "first", days: [day]).meters == Double(99 + rawFrames - 1), "Context transition did not flush all raw samples")
        withExtendedLifetime(subscription) {}
        print("Ride throttle: 100-frame burst + \(rawFrames)-frame sustained stream; <=1Hz telemetry revisions, trailing delivery, raw accounting, flush/reload and context cancellation passed")
    }
}
