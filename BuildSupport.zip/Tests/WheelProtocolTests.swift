import Foundation

@main enum WheelProtocolTests {
    private static var checks = 0
    static func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
        checks += 1
        guard condition() else { fatalError(message) }
    }
    // Test fixture assembled independently from actual firmware 0x08011594
    // layout. CRC values/commands also checked in the firmware software bench.
    static func packet(page: UInt8 = 8, alarm: UInt8 = 1, schema: UInt8 = 3, lamp: UInt8 = 1, firmware: UInt16 = 6010) -> Data {
        var b = [UInt8](repeating: 0x80, count: 75)
        b[0...3] = [0xDC, 0x5A, 0x5C, 71]
        func word(_ offset: Int, _ value: UInt16) { b[offset] = UInt8(truncatingIfNeeded: value >> 8); b[offset + 1] = UInt8(truncatingIfNeeded: value) }
        word(4, 14450); word(6, UInt16(bitPattern: -251)); word(18, 3250)
        word(28, firmware); word(34, 7350)
        b[8...11] = [0x34, 0x56, 0, 0x12]
        b[12...15] = [0x78, 0x9A, 0, 0x56]
        b[40...43] = [0x4C, 0x43, schema, 0x23]; b[45] = alarm; b[46] = page; b[47] = lamp
        let crc = WheelFrameDecoder.crc32(Array(b.prefix(71)))
        b[71...74] = [UInt8(truncatingIfNeeded: crc >> 24), UInt8(truncatingIfNeeded: crc >> 16), UInt8(truncatingIfNeeded: crc >> 8), UInt8(truncatingIfNeeded: crc)]
        return Data(b)
    }
    static func hex(_ data: Data) -> String { data.map { String(format: "%02x", $0) }.joined() }
    static func main() {
        expect(WheelFrameDecoder.crc32(Array("123456789".utf8)) == 0xCBF43926, "CRC32 standard vector")
        expect(hex(ShermanLCommands.alarm(true)) == "4c644170100061030103010074380996", "Exact image receiver accepted arm frame")
        expect(hex(ShermanLCommands.alarm(false)) == "4c64417010006103010300006d2338d7", "Exact image receiver accepted disarm frame")
        expect(hex(ShermanLCommands.light(true)) == "4c6441700c00020156d8b497", "Stock lamp setter ON frame")
        expect(hex(ShermanLCommands.light(false)) == "4c6441700c00020021df8401", "Stock lamp setter OFF frame")
        let now = Date(timeIntervalSince1970: 1_800_000_000), bytes = packet()
        var decoder = WheelFrameDecoder()
        let sample = decoder.append(bytes, at: now).first!
        expect(sample.speed == -25.1 && sample.pwm == 73.5, "Signed speed / duty scaling")
        expect(sample.voltage == 144.5 && sample.temperature == 32.5, "Voltage / temperature scaling")
        expect(sample.tripMeters == 0x123456 && sample.totalMeters == 0x56789A, "Word-swapped odometer")
        expect(sample.isShermanL && sample.compatibleAlarm && sample.alarm == .armed && sample.lightOn == true, "Exact custom marker + page8 readback")
        expect(sample.version == "006.0.10", "Version decoding")
        expect(sample.estimatedBattery.map { (0...100).contains($0) } == true, "SOC estimate clamped")
        expect(sample.isFresh(at: now.addingTimeInterval(3)), "Fresh boundary")
        expect(!sample.isFresh(at: now.addingTimeInterval(3.01)) && !sample.isFresh(at: now.addingTimeInterval(-1)), "Stale/future sample not live")
        for split in 0...bytes.count {
            var d = WheelFrameDecoder()
            let one = d.append(bytes.prefix(split), at: now), two = d.append(bytes.dropFirst(split), at: now)
            expect(one.count + two.count == 1, "BLE notification split \(split)")
        }
        for state in UInt8(0)...3 {
            var d = WheelFrameDecoder(); let s = d.append(packet(alarm: state), at: now).first!
            expect(s.alarm?.rawValue == state, "Exact firmware disarmed/armed/warning/siren readback")
        }
        var unknown = WheelFrameDecoder()
        let incompatible = unknown.append(packet(schema: 2), at: now).first!
        expect(incompatible.isShermanL && !incompatible.compatibleAlarm && incompatible.alarm == nil, "Wrong ABI does not authorize alarm control")
        var wrongVersion = WheelFrameDecoder()
        expect(wrongVersion.append(packet(firmware: 6011), at: now).first?.compatibleAlarm == false, "Unknown firmware cannot authorize custom writes")
        var sentinel = WheelFrameDecoder()
        expect(sentinel.append(packet(lamp: 0x80), at: now).first?.lightOn == nil, "Unknown lamp sentinel not interpreted as OFF")
        var nonSettings = WheelFrameDecoder()
        expect(nonSettings.append(packet(page: 0x50), at: now).first?.lightOn == nil, "Alarm/PID custom page must not masquerade as lamp state")
        var corrupt = bytes; corrupt[10] ^= 1
        var resync = WheelFrameDecoder()
        expect(resync.append(Data([0, 1, 0xDC]) + corrupt + bytes, at: now).count == 1 && resync.rejectedFrames > 0, "CRC rejection + noisy stream resynchronization")
        var combined = WheelFrameDecoder()
        expect(combined.append(bytes + bytes, at: now).count == 2, "Multiple packets per notification")
        var partial = WheelFrameDecoder(); _ = partial.append(bytes.prefix(35)); partial.reset()
        expect(partial.append(bytes.dropFirst(35)).isEmpty, "Disconnect reset discards old connection fragment")
        print("Wheel protocol: \(checks) checks passed; no BLE hardware or writes used.")
    }
}
