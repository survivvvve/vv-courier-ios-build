#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
EXPRESS_TEST_DIR=$(mktemp -d)
trap 'rm -rf "$EXPRESS_TEST_DIR"' EXIT
xcrun swiftc -swift-version 5 ExpressNotificationState.swift Tests/ExpressNotificationTests.swift -o "$EXPRESS_TEST_DIR/express-tests"
"$EXPRESS_TEST_DIR/express-tests"
