import Foundation

@main struct QueueParserTests {
    static func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
        if !condition() { fatalError(message) }
    }
    static func main() throws {
        let duplicatedShops: [[String: Any]] = [
            ["shop_number": 101, "lat": 60.05, "lon": 30.33, "gettype": 1],
            ["shop_number": 101, "lat": 60.06, "lon": 30.34, "gettype": 2]
        ]
        let fixture: [String: Any] = ["clusters": [
            ["cluster_id": 11, "name": "Очередь А 101", "shops": duplicatedShops, "count": 2, "parcels_count": 4, "geo_check": false, "active_queue": false],
            ["cluster_id": 12, "name": "Очередь Б 101", "shops": duplicatedShops, "count": 1, "parcels_count": 2, "geo_check": true, "queue_qr_scan": true, "active_queue": true],
            ["cluster_id": 13, "name": "Отдельная очередь", "shops": duplicatedShops, "count": 0, "parcels_count": 3],
            ["cluster_id": 13, "name": "Duplicate server item", "shops": duplicatedShops]
        ]]
        let catalog = try QueueParser.catalog(fixture, shops: [101])
        expect(catalog.map(\.id) == ["11", "12", "13"], "Queues sharing a store must remain separate and preserve server order")
        expect(catalog[0].title == "Очередь А 101", "Queue name must come from `name`")
        expect(catalog[0].shops == [101], "Repeated shop descriptors must not repeat display numbers")
        expect(catalog[0].locations.count == 2, "All coordinate candidates remain available for actual geo check")
        expect(catalog[0].shopSubtitle == nil, "Do not append a shop number already present in queue name")
        expect(catalog[2].shopSubtitle == "Магазин №101", "A shop number absent from the name appears only as secondary metadata")
        expect(!catalog[0].requiresGeoCheck && catalog[1].requiresGeoCheck, "Geo requirement is per queue, never unconditional")
        expect(catalog[1].requiresQR && catalog[1].isActive, "Queue flags must remain attached to their queue ID")
        let filtered = try QueueParser.catalog(fixture, shops: [202])
        expect(filtered.isEmpty, "Shop selection filters catalog, not merges queues")

        let detail: [String: Any] = ["data": [
            ["courier_id": 8, "fio": "Яков Тестовый", "current_count": 3, "limit": 6],
            ["courier_id": "2", "fio": "Анна Тестовая", "current_count": "1", "limit": "4"],
            ["courier_id": 8, "fio": "Duplicate", "current_count": 0, "limit": 0]
        ], "parcels_count": 7, "parcels_count_terminal": 2, "queue_qr_scan": false]
        let result = try QueueParser.detail(detail, summary: catalog[1], courierID: "2")
        expect(result.id == "12" && result.title == "Очередь Б 101", "Detail identity must stay with selected queue")
        expect(result.people.map(\.id) == ["8", "2"], "People must preserve server order, without duplicate rows")
        expect(result.people[1].isMe && !result.people[0].isMe, "Own row matches ID, not name")
        expect(result.people[1].taken == 1 && result.people[1].limit == 4, "Taken/limit supports server numeric strings")
        expect(result.orders == 7 && result.terminalOrders == 2 && !result.requiresQR, "Use selected queue detail counters and QR flag")
        let empty = try QueueParser.detail(["data": [], "parcels_count": 3], summary: catalog[2], courierID: "2")
        expect(empty.people.isEmpty && empty.orders == 3, "An empty courier queue may still contain orders")
        do {
            _ = try QueueParser.detail(["data": "wrong"], summary: catalog[0], courierID: nil)
            fatalError("Unknown response shape must not be reported as empty queue")
        } catch is CourierError { }
        do {
            _ = try QueueParser.detail(["data": [["fio": "No ID"]]], summary: catalog[0], courierID: nil)
            fatalError("A malformed courier row must not silently alter positions")
        } catch is CourierError { }

        let pickupClusters: [[String: Any]] = [
            ["cluster_id": 11, "take_check": true, "shops": [["shop_number": 101, "gettype": 3]]],
            ["cluster_id": 12, "take_check": false, "shops": [["shop_number": 202, "gettype": 0]]]
        ]
        let parcel: [String: Any] = ["shopno": "101", "gettype": "3"]
        expect(QueuePickupRules.requiresMembership(parcel: parcel, profileQueueCheck: true, clusters: pickupClusters), "Matching take_check shop/gettype requires membership")
        expect(!QueuePickupRules.requiresMembership(parcel: parcel, profileQueueCheck: false, clusters: pickupClusters), "Profile queue_check=false bypasses only queue gate")
        expect(!QueuePickupRules.requiresMembership(parcel: ["shopno": 101, "gettype": 4], profileQueueCheck: true, clusters: pickupClusters), "Do not impose membership on other gettypes")
        expect(!QueuePickupRules.requiresMembership(parcel: ["shopno": 202, "gettype": 3], profileQueueCheck: true, clusters: pickupClusters), "Do not impose membership when take_check=false")
        expect(!QueuePickupRules.requiresMembership(parcel: ["shopno": 303, "gettype": 3], profileQueueCheck: true, clusters: pickupClusters), "Do not impose membership on other shops")
        let wildcard: [[String: Any]] = [["take_check": true, "shops": [["shop_number": 101, "gettype": 0]]]]
        expect(QueuePickupRules.requiresMembership(parcel: ["shopno": 101, "gettype": 9], profileQueueCheck: true, clusters: wildcard), "Descriptor gettype=0 matches any order type")
        expect(QueuePickupRules.hasMembership(["cluster_id": 999]) && QueuePickupRules.hasMembership(["cluster_id": "12"]), "Any current queue membership passes global official gate, not only a guessed matching queue")
        expect(!QueuePickupRules.hasMembership([:]) && !QueuePickupRules.hasMembership(["cluster_id": NSNull()]) && !QueuePickupRules.hasMembership(["cluster_id": 0]), "Missing/zero queue status means not in queue")
        let timed = Parcel(["id_parcel": "timer", "task_date_supply_until_courier_rfc": "2026-11-02T12:10:00+03:00", "date_supply_until_rfc": "2026-11-02T13:00:00+03:00"])
        expect(timed.deadline == timestamp("2026-11-02T12:10:00+03:00"), "Courier task deadline must take precedence over customer slot end")
        let legacy = Parcel(["id_parcel": "legacy", "task_date_supply_until_courier_rfc": "", "task_date_supply_untill": "2026-11-02T12:15:00", "date_supply_until_rfc": "2026-11-02T13:00:00+03:00"])
        expect(legacy.deadline == timestamp("2026-11-02T12:15:00"), "Empty new field falls back to valid legacy task deadline")
        let fallback = Parcel(["id_parcel": "fallback", "date_supply_until_rfc": "2026-11-02T13:00:00+03:00"])
        expect(fallback.deadline == timestamp("2026-11-02T13:00:00+03:00"), "Old response without task deadline retains customer deadline fallback")
        expect(Shop(["shopno": 101, "Adress": "Тестовый адрес"])?.address == "Тестовый адрес", "Official capitalized Adress field must remain visible")

        let demo = QueueDemo.catalog(joined: ["demo-empty"])
        expect(Set(demo.map(\.id)).count == 3, "Demo must exercise independent queue IDs")
        let north = QueueDemo.detail(demo[0], joined: ["demo-empty"], taken: 2)
        let south = QueueDemo.detail(demo[1], joined: ["demo-empty"], taken: 2)
        let joined = QueueDemo.detail(demo[2], joined: ["demo-empty"], taken: 2)
        expect(north.people.map(\.id) == ["demo-n1", "demo-n2"] && south.people.map(\.id) == ["demo-s1"], "Queue membership must not bleed between same-store queues")
        expect(joined.people.count == 1 && joined.people[0].isMe, "Joining demo empty queue affects only that queue")
        print("Queue parser: all regression cases passed")
    }
}
