import Foundation

@main enum WheelStateTests {
    static var checks = 0
    static func check(_ condition: @autoclosure () -> Bool,_ label:String) { checks += 1;precondition(condition(),label) }
    static let id = "AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"
    static let second = "BBBBBBBB-BBBB-BBBB-BBBB-BBBBBBBBBBBB"
    static func sample(_ date:Date, _ meters:UInt32?, pwm:Double?=nil) -> WheelTelemetry {
        var value=WheelTelemetry(receivedAt:date,speed:40,pwm:pwm,voltage:nil,temperature:nil,firmware:0,tripMeters:nil,totalMeters:meters,compatibleAlarm:false,alarm:nil,lightOn:nil)
        value.family = .begode;return value
    }
    static func main() throws {
        let name="vv-wheel-fixtures-"+UUID().uuidString
        let defaults=UserDefaults(suiteName:name)!
        let directory=FileManager.default.temporaryDirectory.appendingPathComponent(name)
        defer { defaults.removePersistentDomain(forName:name);try? FileManager.default.removeItem(at:directory) }
        defaults.set(id,forKey:"wheel.sherman.peripheral")
        let speed=WheelSpeedPreferences(defaults:defaults)
        check(speed.percentage == 100,"Calibration default100")
        check(speed.setPercentage(95) && speed.corrected(40)==38,"40 at95%=38")
        check(!speed.setPercentage(.nan) && !speed.setPercentage(151),"Calibration invalid/bounds")
        check(WheelSpeedPreferences(defaults:defaults).percentage==95,"Offline calibration reload")
        speed.selectWheel(id:second);check(speed.percentage==100,"UUID isolation")
        speed.selectWheel(id:id);check(speed.percentage==95,"First wheel factor retained")
        let layout=WheelDashboardPreferences(defaults:defaults)
        layout.add(.phaseCurrent);layout.move(from:IndexSet(integer:layout.metrics.count-1),to:0)
        check(layout.metrics.first == .phaseCurrent,"Metric reorder")
        check(WheelDashboardPreferences(defaults:defaults).metrics.first == .phaseCurrent,"Layout persisted")
        for metric in WheelMetric.allCases { layout.remove(metric) }
        check(layout.metrics.count==1,"Cannot remove last tile")
        layout.restore();check(layout.metrics==WheelDashboardPreferences.defaults,"Restore layout")
        let now=Date(),raw=sample(now,100)
        check(WheelMetric.pwm.value(sample:raw,battery:nil,fresh:true,at:now,demo:false)=="—","Missing PWM not zero")
        check(WheelMetric.temperature.value(sample:raw,battery:nil,fresh:true,at:now,demo:false)=="—","Missing temperature not zero")
        check(WheelMetric.speed.value(sample:raw,battery:nil,fresh:true,at:now,demo:false,speedPercentage:95)=="38.0","Corrected numeric tile")
        check(WheelMetric.speed.value(sample:raw,battery:nil,fresh:false,at:now,demo:false)=="—","Stale tile hidden")
        let inputs=WheelAlarmInputs(sample:raw,demo:false,at:now,percentage:95)
        check(inputs?.speed==38 && inputs?.pwm==nil,"Generic-family phone alert inputs")
        check(WheelAlarmInputs(sample:raw,demo:true,at:now,percentage:95)==nil,"No automatic demo alarm")
        check(WheelAlarmInputs(sample:raw,demo:false,at:now.addingTimeInterval(3.1),percentage:95)==nil,"No stale alarm")
        var latch=WheelAlarmLatch();let rule=WheelPhoneAlarmRule(enabled:true,threshold:80,repeatInterval:5)
        latch.evaluate(value:81,rule:rule);check(latch.active,"Alarm threshold")
        latch.evaluate(value:79,rule:rule);check(latch.active,"Hysteresis prevents chatter")
        latch.lastSound=now;latch.evaluate(value:78,rule:rule);check(!latch.active && latch.lastSound==now,"Reset preserves cooldown")
        latch.evaluate(value:90,rule:rule);latch.evaluate(value:nil,rule:rule);check(!latch.active,"Absent PWM never triggers")
        let store=WheelRideStore(directory:directory,defaults:defaults,speedPreferences:speed)
        let day=WheelRideStore.dayKey();let start=now.addingTimeInterval(-0.8)
        for mode in 0..<3 {
            store.setContext(courierID:"courier",active:mode != 0,known:mode != 1,demo:mode==2)
            store.receive(sample(start,100),wheelID:id)
            check(!store.summary(courierID:"courier",days:[day]).hasData,"Inactive/unknown/demo excluded")
        }
        store.setContext(courierID:"courier",active:true,known:true,demo:false)
        store.receive(sample(start,100),wheelID:id)
        store.receive(sample(start.addingTimeInterval(0.2),102),wheelID:id)
        store.receive(sample(start.addingTimeInterval(0.2),102),wheelID:id)
        var summary=store.summary(courierID:"courier",days:[day])
        check(summary.meters==2 && abs(summary.movingSeconds-0.2)<0.001,"Duplicate distance+time protection")
        check(abs(summary.averageSpeed!-38)<0.001 && summary.maxPWM==nil && summary.maxTemperature==nil,"Corrected speeds, unknown maxima nil")
        _=speed.setPercentage(90)
        store.receive(sample(start.addingTimeInterval(0.4),104),wheelID:id)
        summary=store.summary(courierID:"courier",days:[day])
        check(abs(summary.averageSpeed!-37.5)<0.001,"Factor change affects new interval only")
        store.disconnected();store.receive(sample(start.addingTimeInterval(0.5),1000),wheelID:id)
        check(store.summary(courierID:"courier",days:[day]).meters==4,"Reconnect no counter catchup")
        store.receive(sample(start.addingTimeInterval(0.6),10),wheelID:id)
        store.receive(sample(start.addingTimeInterval(0.7),100000),wheelID:id)
        check(store.summary(courierID:"courier",days:[day]).meters==4,"Reset and jump rejected")
        store.setContext(courierID:"other",active:true,known:true,demo:false)
        store.receive(sample(start,40000),wheelID:id)
        store.receive(sample(start.addingTimeInterval(0.2),40002),wheelID:id)
        check(store.summary(courierID:"other",days:[day]).meters==2 && store.summary(courierID:"courier",days:[day]).meters==4,"Courier account isolation")
        store.setContext(courierID:"no-odo",active:true,known:true,demo:false)
        store.receive(sample(start,nil),wheelID:second);store.receive(sample(start.addingTimeInterval(0.2),nil),wheelID:second)
        summary=store.summary(courierID:"no-odo",days:[day])
        check(summary.meters==0 && summary.movingSeconds>0 && summary.hasGaps,"Missing odometer doesn't fabricate distance")
        store.flush()
        let restored=WheelRideStore(directory:directory,defaults:defaults,speedPreferences:speed)
        check(restored.summary(courierID:"courier",days:[day]).meters==4,"Persisted ride restored")
        restored.setContext(courierID:"courier",active:true,known:true,demo:false);restored.receive(sample(Date(),99999),wheelID:id)
        check(restored.summary(courierID:"courier",days:[day]).meters==4,"Restart no catchup")
        let foreignName=name+"-foreign";let foreign=UserDefaults(suiteName:foreignName)!
        defer { foreign.removePersistentDomain(forName:foreignName) }
        let denied=WheelRideStore(directory:directory,defaults:foreign,speedPreferences:speed)
        check(!denied.summary(courierID:"courier",days:[day]).hasData && denied.storageError != nil,"Installation owner isolation")
        let boundary=ISO8601DateFormatter().date(from:"2026-12-31T21:30:00Z")!
        check(WheelRideStore.dayKey(at:boundary)=="2027-01-01","Moscow day across year boundary")
        print("Wheel state: \(checks) checks passed; isolated defaults/files, no BLE/audio.")
    }
}
