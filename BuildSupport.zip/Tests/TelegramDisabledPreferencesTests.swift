import Foundation

/// Actual production preferences use a fake Keychain boundary in the runner.
@main struct TelegramDisabledPreferencesTests {
    @MainActor static func main() throws {
        let domain = "telegram-disabled-preferences." + UUID().uuidString
        let defaults = UserDefaults(suiteName: domain)!
        defer { defaults.removePersistentDomain(forName: domain) }
        let config = TelegramNotificationConfiguration(botID: 123456, botUsername: "fixture_bot",
            chat: TelegramChatDestination(chatID: "-100123"), chatTitle: "Offline fixture")
        defaults.set(true, forKey: "telegram.notifications.v1.enabled")
        defaults.set(try JSONEncoder().encode(config), forKey: "telegram.notifications.v1.configuration")
        defaults.set(Data("old-delivery-ledger".utf8), forKey: "telegram.notifications.delivery.v1")
        defaults.set("untouched", forKey: "vv.session.sentinel")
        defaults.set(true, forKey: "express.notifications.enabled")
        defaults.set("keep-wheel-settings", forKey: "wheel.fixture")
        let deletes = TelegramNotificationTokenStore.deletes
        let preferences = TelegramNotificationPreferences(defaults: defaults)
        precondition(!preferences.enabled && !preferences.monitoringEnabled && !preferences.isConfigured && preferences.token == nil)
        precondition(preferences.configuration == nil && !defaults.bool(forKey: "telegram.notifications.v1.enabled"))
        precondition(defaults.object(forKey: "telegram.notifications.v1.configuration") == nil && defaults.object(forKey: "telegram.notifications.delivery.v1") == nil)
        precondition(TelegramNotificationTokenStore.secret == nil && TelegramNotificationTokenStore.deletes == deletes + 1)
        precondition(TelegramNotificationTokenStore.reads == 0 && TelegramNotificationTokenStore.writes == 0,
            "Disabled preferences must not read or create a credential")
        preferences.enabled = true
        precondition(!preferences.monitoringEnabled && preferences.token == nil, "An old caller cannot reenable integration")
        do {
            try preferences.save(token: "OFFLINE_REJECTED_TOKEN",
                bot: TelegramBotIdentity(id: 123456, username: "fixture_bot", name: "Fixture"),
                chat: TelegramChatIdentity(id: -100123, title: "Fixture", type: "supergroup"))
            preconditionFailure("Removed integration must reject a saved destination")
        } catch {
            precondition(error.localizedDescription.contains("отключена") && !error.localizedDescription.contains("OFFLINE_REJECTED_TOKEN"))
        }
        precondition(TelegramNotificationTokenStore.writes == 0 && preferences.configuration == nil)
        precondition(defaults.string(forKey: "vv.session.sentinel") == "untouched" && defaults.bool(forKey: "express.notifications.enabled") && defaults.string(forKey: "wheel.fixture") == "keep-wheel-settings",
            "Telegram cleanup must not affect VV session, native express notices or wheel settings")
        print("Telegram disabled preferences passed: legacy settings/keychain cleanup, save refusal, no reactivation and unrelated VV/native/wheel state preserved; fake Keychain only.")
    }
}
