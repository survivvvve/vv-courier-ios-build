#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
QUEUE_TEST_DIR=$(mktemp -d)
trap 'rm -rf "$QUEUE_TEST_DIR"' EXIT
python3 - "$QUEUE_TEST_DIR" <<'PY'
from pathlib import Path
import sys
out=Path(sys.argv[1])
s=Path('QueueModels.swift').read_text()
(out/'QueueCore.swift').write_text(s.split('extension CourierAPI {')[0] + s[s.index('enum QueueDemo {'):])
s=Path('LocationService.swift').read_text()
(out/'GeoPoint.swift').write_text(s.split('@MainActor final class LocationService')[0])
s=Path('OrderActions.swift').read_text()
(out/'Truth.swift').write_text('import Foundation\n' + s[s.index('func truth('):])
PY
xcrun swiftc Models.swift ParcelAddress.swift "$QUEUE_TEST_DIR/GeoPoint.swift" "$QUEUE_TEST_DIR/Truth.swift" "$QUEUE_TEST_DIR/QueueCore.swift" Tests/QueueParserTests.swift -o "$QUEUE_TEST_DIR/QueueParserTests"
"$QUEUE_TEST_DIR/QueueParserTests"
