import Foundation

private struct ShiftReply {
    var object: Any = [:]
    var raw: Data? = nil
    var status = 200
}

private final class ShiftFixtureProtocol: URLProtocol {
    static var handler: ((URLRequest) throws -> ShiftReply)!
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let reply = try Self.handler(request)
            let response = HTTPURLResponse(url: request.url!, statusCode: reply.status, httpVersion: nil, headerFields: ["Content-Type": "application/json"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: try reply.raw ?? JSONSerialization.data(withJSONObject: reply.object))
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

private final class ShiftFixture {
    var active = false
    var flags: [Int] = []
    var tmc: [String: Any] = ["Сумка": true]
    var kisStatus = "ok"
    var slotOffset: TimeInterval = 3600
    var serverTimeText = "2035-05-10T10:00:00+03:00"
    var terminal: [String: Any] = ["res": 1, "terminal_id": "0"]
    var queueJoined = false
    var shiftTimesOut = false
    var shiftTimeoutChangesState = true
    var deletionTimesOut = false
    var deletionChangesState = true
    var parcelStatus: String? = nil
    var writes: [(String, [String: Any])] = []
    var requests: [String] = []

    func respond(_ request: URLRequest) throws -> ShiftReply {
        let path = request.url!.path
        requests.append(path)
        switch path {
        case "/v1/courier/activity": return ShiftReply(object: ["res": active ? 1 : 0])
        case "/v1/courier/courier": return ShiftReply(object: ["courier_active": true])
        case "/v1/tasks/active": return ShiftReply(object: flags)
        case "/v1/courier/me/required_tmc": return ShiftReply(object: ["tmc": tmc])
        case "/v1/rnis-provider/start_shift", "/v2/rnis-provider/start_shift":
            writes.append((path, try ShiftActionTests.body(request)))
            return ShiftReply(object: ["status": kisStatus])
        case "/v1/couriers/me/schedules/slots/assignments":
            let now = timestamp("2035-05-10T10:00:00+03:00")!
            let iso = ISO8601DateFormatter()
            return ShiftReply(object: ["schedules": [["date": "2035-05-10", "slots": [["id": 1, "time_from": iso.string(from: now.addingTimeInterval(slotOffset)), "time_to": iso.string(from: now.addingTimeInterval(slotOffset + 7200))]]]]])
        case "/time":
            precondition(request.value(forHTTPHeaderField: "Authorization") == nil)
            return ShiftReply(raw: Data(serverTimeText.utf8))
        case "/v1/courier/terminal/getreturn": return ShiftReply(object: terminal)
        case "/v1/courier/get_parcels_assigned_to_me_ext":
            let rows: [[String: Any]] = parcelStatus.map { [["id_parcel": "123", "parcel_status": $0]] } ?? []
            return ShiftReply(object: ["parcels": rows, "total": rows.count])
        case "/v2/courier/get_parcel": return ShiftReply(object: ["parcel": ["id_parcel": "123", "parcel_status": parcelStatus ?? "reposted"]])
        case "/v1/tasks/get_return_reasons": return ShiftReply(object: ["before_delivery": [["id": 0, "return_reason": "Другое"]], "after_delivery": [["id": 0, "return_reason": "Другое"]]])
        case "/v1/tasks/set_task_return_reason":
            writes.append((path, try ShiftActionTests.body(request))); return ShiftReply()
        case "/v2/courier/change_task_status":
            let body = try ShiftActionTests.body(request)
            writes.append((path, body)); parcelStatus = nil; return ShiftReply()
        case "/v2/courier/session_courier":
            let body = try ShiftActionTests.body(request)
            writes.append((path, body))
            if !shiftTimesOut || shiftTimeoutChangesState { active = integer(body["shift"]) == 1 }
            if shiftTimesOut { throw URLError(.timedOut) }
            return ShiftReply(object: ["description": "fixture acknowledgement", "courier_active": true])
        case "/v3/courier/queue/clusters/1": return ShiftReply(object: ["clusters": [["cluster_id": 10, "active_queue": queueJoined]]])
        case "/v2/courier/queue/1":
            precondition(request.httpMethod == "DELETE")
            writes.append((path, [:]))
            if deletionChangesState { queueJoined = false }
            if deletionTimesOut { throw URLError(.timedOut) }
            return ShiftReply()
        default: preconditionFailure("Unexpected fixture request: " + path)
        }
    }
    var shiftWrites: Int { writes.filter { $0.0 == "/v2/courier/session_courier" }.count }
    var queueWrites: Int { writes.filter { $0.0 == "/v2/courier/queue/1" }.count }
}

@main enum ShiftActionTests {
    static func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open(); defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 4096)
            while stream.hasBytesAvailable {
                let count = stream.read(&buffer, maxLength: buffer.count)
                guard count > 0 else { break }; data.append(contentsOf: buffer.prefix(count))
            }
        }
        return try JSONSerialization.jsonObject(with: data) as! [String: Any]
    }
    @discardableResult static func reject(_ operation: () async throws -> Void) async -> String {
        do { try await operation(); preconditionFailure("Expected rejection") }
        catch { return error.localizedDescription }
    }
    static func main() async throws {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [ShiftFixtureProtocol.self]
        let transport = URLSession(configuration: configuration)
        defer { transport.invalidateAndCancel() }
        let api = CourierAPI(session: Session(token: "offline-fixture-only", courierID: "1"), transport: transport)
        func use(_ fixture: ShiftFixture) { ShiftFixtureProtocol.handler = { try fixture.respond($0) } }

        // Active KIS and satisfied TMC must pass; feature flags alone do not block.
        for version in [1, 2] {
            let fixture = ShiftFixture(); fixture.flags = [164, 175, 357] + (version == 2 ? [267] : [])
            use(fixture)
            try await api.changeShift(active: true)
            precondition(fixture.active && fixture.shiftWrites == 1)
            let kis = fixture.writes.first!
            precondition(kis.0 == "/v\(version)/rnis-provider/start_shift" && integer(kis.1["courier_id"]) == 1)
            precondition(fixture.requests.contains("/time"), "Gate must use server time, not the phone clock")
        }
        for status in ["inactive_warning", "inactive_blocked", "validation_error", "unexpected"] {
            let fixture = ShiftFixture(); fixture.flags = [164]; fixture.kisStatus = status; use(fixture)
            _ = await reject { try await api.changeShift(active: true) }
            precondition(!fixture.active && fixture.shiftWrites == 0)
        }
        let missing = ShiftFixture(); missing.flags = [164, 175]; missing.tmc = ["Сумка": false]; use(missing)
        let missingMessage = await reject { try await api.changeShift(active: true) }
        precondition(missingMessage.contains("Сумка") && missing.writes.isEmpty, "Missing equipment must block before KIS acknowledgement")
        let invalid = ShiftFixture(); invalid.flags = [175]; invalid.tmc = ["Сумка": 1]; use(invalid)
        _ = await reject { try await api.changeShift(active: true) }; precondition(invalid.writes.isEmpty)
        let tooEarly = ShiftFixture(); tooEarly.flags = [357]; tooEarly.slotOffset = 3601; use(tooEarly)
        _ = await reject { try await api.changeShift(active: true) }; precondition(tooEarly.writes.isEmpty)
        let invalidClock = ShiftFixture(); invalidClock.flags = [357]; invalidClock.serverTimeText = "invalid time"; use(invalidClock)
        _ = await reject { try await api.changeShift(active: true) }; precondition(invalidClock.writes.isEmpty)

        let assigned = ShiftFixture(); assigned.active = true; assigned.terminal = ["res": 2, "terminal_id": "888", "shopno": 101]; use(assigned)
        let terminalMessage = await reject { try await api.changeShift(active: false) }
        precondition(terminalMessage.contains("888") && assigned.shiftWrites == 0 && assigned.queueWrites == 0)
        for timedOut in [false, true] {
            let fixture = ShiftFixture(); fixture.active = true; fixture.queueJoined = true; fixture.shiftTimesOut = timedOut; use(fixture)
            try await api.changeShift(active: false)
            precondition(!fixture.active && !fixture.queueJoined && fixture.shiftWrites == 1 && fixture.queueWrites == 1)
            precondition(fixture.requests.firstIndex(of: "/v2/courier/session_courier")! < fixture.requests.firstIndex(of: "/v2/courier/queue/1")!)
        }
        let unknown = ShiftFixture(); unknown.active = true; unknown.queueJoined = true; unknown.shiftTimesOut = true; unknown.shiftTimeoutChangesState = false; use(unknown)
        _ = await reject { try await api.changeShift(active: false) }
        precondition(unknown.active && unknown.queueJoined && unknown.shiftWrites == 1 && unknown.queueWrites == 0, "Never leave queue until closure is confirmed")
        let uncertainDelete = ShiftFixture(); uncertainDelete.active = true; uncertainDelete.queueJoined = true; uncertainDelete.deletionTimesOut = true; use(uncertainDelete)
        try await api.changeShift(active: false)
        precondition(uncertainDelete.shiftWrites == 1 && uncertainDelete.queueWrites == 1 && !uncertainDelete.queueJoined, "Readback resolves a successful timed-out deletion without replay")
        let failedDelete = ShiftFixture(); failedDelete.active = true; failedDelete.queueJoined = true; failedDelete.deletionChangesState = false; use(failedDelete)
        let cleanupMessage = await reject { try await api.changeShift(active: false) }
        precondition(cleanupMessage.contains("Смена уже закрыта") && !failedDelete.active && failedDelete.queueJoined && failedDelete.shiftWrites == 1)
        failedDelete.deletionChangesState = true
        try await api.changeShift(active: false)
        precondition(failedDelete.shiftWrites == 1 && !failedDelete.queueJoined, "Explicit cleanup retry must not close the shift twice")

        let custom = ShiftFixture(); custom.parcelStatus = "pickuped"; use(custom)
        _ = await reject { try await api.orderAction("123", action: "cancel", reasonID: "0", reasonText: " \n ", expectedStatus: "pickuped") }
        precondition(custom.writes.isEmpty)
        try await api.orderAction("123", action: "cancel", reasonID: "0", reasonText: "  Покупатель отказался от повреждённой упаковки  ", expectedStatus: "pickuped")
        let reason = custom.writes.first!.1
        precondition(string(reason["return_reason"]) == "Покупатель отказался от повреждённой упаковки")
        precondition(integer(reason["reason_id"]) == 0 && reason["before_delivery"] as? Bool == true)
        let stale = ShiftFixture(); stale.parcelStatus = "on_the_way"; use(stale)
        _ = await reject { try await api.orderAction("123", action: "cancel", reasonID: "0", reasonText: "Проверенный текст", expectedStatus: "pickuped") }
        precondition(stale.writes.isEmpty)
        let intent = ParcelActionIntent(action: "cancel", parcelID: "123", expectedStatus: "pickuped", identity: "account-A", demo: false, reasonID: "0", reasonText: "Текст")
        do { try intent.validate(identity: "account-B", parcelID: "123", status: "pickuped"); preconditionFailure("Stale account accepted") } catch is CancellationError {}
        do { try intent.validate(identity: "account-A", parcelID: "123", status: "arrived"); preconditionFailure("Stale parcel status accepted") } catch is CourierError {}
        print("Shift/action fixtures passed: KIS versions/states, TMC, server one-hour window, terminal, confirmed closure/queue cleanup, timeout readback, custom reason, stale account/status. No live network.")
    }
}
