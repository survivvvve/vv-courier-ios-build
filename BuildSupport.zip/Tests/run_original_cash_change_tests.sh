#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
CASH_CHANGE_TEST_DIR=$(mktemp -d /tmp/vv-cash-change.XXXXXX)
trap 'rm -rf "$CASH_CHANGE_TEST_DIR"' EXIT
xcrun swiftc -swift-version 5 -parse-as-library -framework JavaScriptCore Tests/OriginalCashChangeTests.swift -o "$CASH_CHANGE_TEST_DIR/cash-change-tests"
"$CASH_CHANGE_TEST_DIR/cash-change-tests"
