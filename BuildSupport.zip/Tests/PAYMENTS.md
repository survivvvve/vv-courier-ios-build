# Terminal completion and receipt contracts

Primary source inspected: official `courier.vkusvill.ru` JS build 6.16.1, locally captured `/tmp/vv-current.js`. No login, live order closure, acquiring operation or real photo upload was performed during implementation.

The first-party `MI`, `qje`, `Ep`, `j8`, `ei`, `TS`, `NU`, `Xd` functions establish:

- `pay_way`: online0, offline1, no-payment2, terminal3, cash4, B2B5, link9.
- SBER terminal and terminal QR are **manual confirmation of an already performed physical-terminal payment**. LIFE PAY and NFC use separate acquiring integrations. Those unavailable integrations have no buttons in this client.
- Assigned terminal is checked via `terminal/getreturn`, `only_check=1`. Only `res=0/2` with terminal ID and shop qualifies. An ID containing `s` is LIFE PAY in the first-party code and is not treated as SBER.
- Completion uses `/v3/courier/change_task_status`, `id_courier`, `id_parcel`, `status=delivered`, decimal-string `sum_pay`. Terminal adds `pay_way=3,id_terminal`; terminal QR also adds `type_id=2`; cash uses `pay_way=4` and, with task flag100, `cash_received` equal to the order price in kopecks (not the tendered banknote).
- Native confirmation re-fetches My membership, current parcel, amount, terminal, package inspection and actual geolocation rules. A price change rejects before the status mutation. No geolocation or package confirmation is fabricated.
- The successful empty v3 response is the first-party acknowledgement. The receipt UI follows this success. Lost response triggers read-only status verification and never an automatic repeated close. Uncertain outcome instructs a refresh of My/archive.
- Terminal completion then opens receipt photo. The original permits Later; archived completed terminal cards retain receipt entry.
- Upload: `/v1/courier/upload_parcel_receipt_photo`, JSON `{file:<unpadded base64>,format:"jpeg",id_courier}` → `{id}`. Attach: `/v1/courier/change_parcel_receipt_photos`, JSON `{id_courier,id_parcel,add:[ids],remove:[]}` → `check_photo:[{id_photo,url_photo}]`.
- Photos are not treated as saved until every uploaded ID appears in `check_photo`. Local drafts preserve JPEG and acknowledged upload IDs, so an attachment retry does not upload the image again. Refresh reconciles a lost attachment response. This version adds photos and removes unsent drafts; it does not delete already attached customer evidence.

`bash Tests/run_payment_tests.sh` exercises actual API request construction with an offline URLProtocol transport: money and kopecks, terminal/QR/cash, current-state race rejection, v3 acknowledgement, timeout→delivered readback without repeated close, unpadded upload/attach and persisted draft recovery. Simulator UI tests exercise explicit demo payment and educational photo only. Physical terminal, real receipts and live delivery remain device/account checks by the owner.
