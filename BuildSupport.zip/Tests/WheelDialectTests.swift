import Foundation

@main enum WheelDialectTests {
    static var checks = 0
    static let now=Date(timeIntervalSince1970:1_800_000_000)
    static func check(_ value:@autoclosure ()->Bool,_ label:String) { checks += 1;precondition(value(),label) }
    static func near(_ value:Double?,_ expected:Double)->Bool { value.map { abs($0-expected)<0.001 } ?? false }
    static func hex(_ string:String)->[UInt8] { stride(from:0,to:string.count,by:2).map { let a=string.index(string.startIndex,offsetBy:$0);let b=string.index(a,offsetBy:2);return UInt8(string[a..<b],radix:16)! } }
    static func reply(_ command:UInt8,_ data:[UInt8],flags:UInt8=0x12)->Data { InMotionWheelDecoder.modernQuery(command:command,data:data,flags:flags) }
    static func splits(_ data:Data,_ label:String) {
        for split in 0...data.count {
            var driver=WheelDriverHub();driver.configure(.inMotionV2)
            let samples=driver.append(data.prefix(split),at:now)+driver.append(data.dropFirst(split),at:now)
            check(samples.count==1,label+" fragment \(split)")
        }
    }
    static func main() {
        // Verbatim97-byte riding body published in the primary source's
        // InMotionV2P6TelemetryTest.kt (labelled btsnoop). Envelope rebuilt here.
        // github.com/eried/eucplanet/blob/main/app/src/test/java/com/eried/eucplanet/ble/InMotionV2P6TelemetryTest.kt
        let p6=hex("3e51f401000000009911000091063e0b0f044c038e12eb11983a773a6f35c7cbcb02bb13c001f401060056000000070000000600000005010000816d0400d657d000169d10004848010061c00300f9004900000000000000000000009b05b90be0")
        let p6wire=reply(0x21,[2,0x87,1,0]+p6)
        splits(p6wire,"Capture P6")
        var p6hub=WheelDriverHub();p6hub.configure(.inMotionV2)
        let sample=p6hub.append(p6wire,at:now).first!.telemetry
        check(sample.modelName=="InMotion P6","P6 identified by response, not BLE name")
        check(near(sample.voltage,207.98) && near(sample.speed,45.05) && near(sample.pwm,28.78),"P6 captured units")
        check(near(sample.batteryReading?.current,5) && near(sample.batteryReading?.power,1039),"P6 captured true battery power")
        check(sample.totalMeters==2901770 && sample.tripMeters==nil,"P6 lifetime0.01km counter, no invented trip")
        check(sample.temperature==nil && sample.pitch==nil && sample.phaseCurrent==nil,"P6 ambiguous/derived fields kept absent; TPMS isn't temp")
        check(p6hub.pollQueries(tick:1)==[InMotionWheelDecoder.routedQuery(7)],"P6 correct read-only poll")
        check(p6hub.lightCommand(true,sample:sample)==nil && !sample.compatibleAlarm,"P6 cannot receive Sherman controls")
        var p6bad=p6wire;p6bad[p6bad.count-1] ^= 1
        var rejected=WheelDriverHub();rejected.configure(.inMotionV2)
        check(rejected.append(p6bad,at:now).isEmpty,"P6 bad checksum rejected")
        check(p6hub.append(p6wire+p6wire,at:now).count==2,"P6 repeated frames")
        // Real66-byte V6 moving body and first24-byte stats payload from the
        // primary InMotionV6Test.kt capture. Temperature sensor identity unclear.
        // github.com/eried/eucplanet/blob/main/app/src/test/java/com/eried/eucplanet/ble/InMotionV6Test.kt
        let v6=hex("f113120038025100cf07090005000000770064007f000500051b621ab80b3a09dc05000000000000cfb000cfb0ccb000000000000000490000000000000000000000")
        let stats=hex("f10100003d5700003f060000cb080000974100002fff0000")
        let car=reply(2,[0x82,1,2,14,1,1,1,0],flags:0x12)
        let v6wire=car+reply(0x21,[2,0x91]+stats)+reply(0x21,[2,0x84]+v6)
        splits(v6wire,"Capture V6")
        var v6hub=WheelDriverHub();v6hub.configure(.inMotionV2)
        let v=v6hub.append(v6wire,at:now).first!.telemetry
        check(v.modelName=="InMotion V6" && near(v.speed,5.68) && near(v.voltage,51.05),"V6 captured identity and speed/V")
        check(near(v.pwm,19.99) && near(v.batteryReading?.current,0.18),"V6 captured PWM/current")
        check(v.tripMeters==50 && v.totalMeters==4970,"V6 capture metres vs0.01km")
        check(v.temperature==nil && v.lightOn==nil && v.phaseCurrent==nil,"Unknown V6 sensor/control fields aren't zeros")
        check(v6hub.pollQueries(tick:1)==[Data(hex("aaaa13040200000217"))],"V6 exact initial session challenge query")
        let key=[UInt8](0..<16)
        check(v6hub.append(reply(2,[0x80,2]+key,flags:0x12),at:now).isEmpty,"Auth response is not realtime")
        let echo=InMotionWheelDecoder.modernQuery(command:2,data:[0,0,0x82]+key,flags:0x13)
        check(v6hub.pollQueries(tick:2)==[echo],"V6 echoes only actual wheel challenge")
        check(v6hub.pollQueries(tick:3)==[Data(hex("aaaa160302210432"))],"V6 exact realtime query")
        check(v6hub.pollQueries(tick:8)==[Data(hex("aaaa160302211127"))],"V6 exact stats query")
        check(v6hub.pollQueries(tick:21)==[Data(hex("aaaa13040200000217"))],"V6 session renewal5s")
        check(v6hub.lightCommand(false,sample:v)==nil && !v.compatibleAlarm,"V6 has no guessed actuator commands")
        var unproved=WheelDriverHub();unproved.configure(.inMotionV2)
        check(unproved.append(reply(0x21,[2,0x84]+v6),at:now).isEmpty,"V6 layout requires confirmed carType")
        check(unproved.append(reply(2,[0x80,2]+key,flags:0x12),at:now).isEmpty,"Unknown wheel challenge ignored")
        check(!unproved.pollQueries(tick:1).contains(echo),"Unknown wheel gets no auth echo")
        check(v6hub.append(reply(0x21,[2,0x84]+v6)+reply(0x21,[2,0x84]+v6),at:now).count==2,"V6 repeated frames")
        var v6bad=v6wire;v6bad[v6bad.count-1] ^= 1
        var v6Reject=WheelDriverHub();v6Reject.configure(.inMotionV2)
        check(v6Reject.append(v6bad,at:now).isEmpty,"V6 bad checksum rejected")
        // Current primary writer leaves checksum raw; prose permits escaping.
        // Both AA and A5 must work at checksum position, including splits.
        for target:UInt8 in [0xAA,0xA5] {
            var payload=[UInt8(0x14),UInt8(p6.count+5),0x21,2,0x87,1,0]+p6
            payload[payload.count-1] ^= payload.reduce(0,^) ^ target
            var raw=InMotionWheelDecoder.stuffed(payload,legacy:false);raw.append(target)
            splits(raw,"Raw special checksum \(target)")
            splits(InMotionWheelDecoder.stuffed(payload+[target],legacy:false),"Escaped checksum \(target)")
        }
        v6hub.configure(.inMotionV2)
        check(v6hub.append(reply(2,[0x80,2]+key,flags:0x12),at:now).isEmpty && !v6hub.pollQueries(tick:2).contains(echo),"Disconnect clears V6 identity/challenge")
        print("Wheel P6/V6 dialects: \(checks) checks passed from published capture bodies; no BLE.")
    }
}
