# Sherman L integration contract

This client targets the owner's running Sherman L 006.0.10 firmware. The owner confirms telemetry and parking alarm have worked on the wheel for almost a month. The BIN filename's old `experimental` suffix is not used as a product status label. The owner has now confirmed the 0.3.0 iPhone client connects to the physical wheel and displays telemetry. The new settings writes in 0.4.0 still require phone/wheel verification; this software bench does not claim to perform it.

The user-supplied image is **not included** in this repository or IPA. Its SHA256 is `d82deab1e736d7acb96717d4c3b2863babbe4b26ec83b19ecf5be7ea57f305d6`, 103940 bytes, loaded at0x08004000, ARM Thumb. All addresses below refer only to that exact image.

Public framing reference: https://github.com/eried/eucplanet/blob/main/docs/protocols/veteran.md . It documents GATT service FFE0 / notify+write FFE1, DC5A5C telemetry, CRC32 and baseline fields. Implementation is independent Swift code; no third-party adapter source or firmware image is bundled.

## Exact-image evidence

`verify_sherman_firmware.py` runs the image's actual ring-buffer command receiver0x08009816 and dispatcher0x08019C34 in Unicorn. Receiver copies wire payload starting at5 into decoded structure+0x12 and validates CRC. The image's receiver magic is `LdAp` at0x08012990.

The custom dispatcher requires selector0x61 and schema byte3. The provided filename says ABI2, but the running machine-code contract and signature are authoritative. Alarm class3/subcommand1 uses a LE16 boolean. The alarm handler0x08018F88 enforces parking status0xE9C2 before arming. This app does not issue a parking-mode command; the owner explicitly enables P on the wheel first.

Confirmed wire frames:

- Arm: `4c644170100061030103010074380996`
- Disarm: `4c64417010006103010300006d2338d7`
- Lamp on: `4c6441700c00020156d8b497`
- Lamp off: `4c6441700c00020021df8401`

The lamp dispatcher0x08009670 selector2 sends its first field to0x08007160, writing byte0x200001AD. Other fields remain sentinel0x80 because omitted payload bytes are padded by the surrounding receiver. Configuration page8 emits this lamp flag at absolute telemetry offset47 (builder0x0800FF64). Lamp state is confirmed only by a fresh page8 response, never by the Bluetooth write acknowledgment.

Readback hook0x08019C18 injects `4C 43 03 23` into absolute realtime offsets40..43. It calls0x08018B94, which places alarm state at45:0=off,1=armed,2=warning,3=siren. This is **not** an offset inside custom page0x50. Swift accepts the alarm schema only when firmware6010 and this exact marker match.

The software bench verifies arm/disarm, warning/siren readback, lamp setters, rejection of nonparking arm, wrong schema and corrupted CRC. See `WheelFirmwareEvidence.json`. Hardware CRC peripheral is replaced by equivalent zlib CRC32, persistent record write by success, and buzzer by a no-op. BLE radio, actual flash writes, controller physics and phone installation are outside this bench.

## Tests

`bash Tests/run_wheel_tests.sh` runs100 protocol plus159 settings Foundation-only Swift assertions without BLE: standard CRC vector, exact command fixtures, byte splits at every position, noise/CRC recovery, sign/units/odometer, all alarm states, unknown schema/version, lamp sentinel/page distinction and stale timestamps. CI needs only Swift; it does not need the owner's firmware.

Optional reproduction of the firmware evidence, with Python's `unicorn` package installed:

```sh
python3 Tests/verify_sherman_firmware.py /path/to/original-image.bin
```

## Runtime behavior

BLE manager is initialized after an explicit first connection, or when reconnecting an already remembered wheel. The explicit offline demo never initializes CoreBluetooth. There is no auto-selection of a nearby stranger's device, and model identification requires a CRC-valid Sherman L packet.

Manual disconnect disables automatic reconnection. Connection loss clears pending commands; they are never replayed. App background restoration is supported by CoreBluetooth's restoration identifier and `bluetooth-central`; iOS can still terminate the app. Fresh telemetry is required for controls; speed/duty disappear after3 seconds. Custom writes require known6010+LC0323. Arming additionally requires fresh stationary speed; the firmware checks actual P state. Command progress remains pending until a matching fresh wheel readback or an8-second timeout (20seconds for a settings transaction). Lamp state expires after15 seconds without a settings-page update.

Firmware flashing, calibration, and power-off are outside this module. The0.4 update adds readback-confirmed stock settings, split assist and transactional PID as requested by the owner.


## Settings in0.4

Stock selector2 payload positions are independently checked through the exact receiver and actual page8 builder0x0800FCE4. Important: payload positions are not equal to the corresponding readback positions. This version's firmware facts take precedence over generic family documentation.

| Setting | Payload byte | Page8 byte (relative to pageID at46) |
|---|---:|---:|
| Hardness |5|4|
| Pedal angle, signed0.1deg |6|5|
| Speed tiltback |7|6|
| PWM tiltback |8|7|
| Speed alarm |9|8|
| Display brightness, step5 |10|9|
| Transport |12|11|
| Display units |13|12|
| Voltage trim, signed0.1percent |14|13|
| Low-battery start |15|14|
| High-speed mode |16|15|
| Lateral cutoff angle |17|16|
| Key tone volume |18|17|
| Charge scalar above145.0V,0.1V |19|18, base145 at19|
| Stock assist |21|20|
| Dip compensation |23|22|

The UI caps charging at151.2V for36S. The controller's broader raw range is not exposed. Disabling speed/alarm writes101; controller normalizes it to200 in readback. Disabling PWM writes96; controller likewise returns200. Re-enabling each is also covered by the firmware bench.

Custom page0x50 is parsed only at its complete115-byte CRC-bearing layout and known6010+LC0323 identity. Active PID mode is byte47; coefficients are BE16 at56/58/60, signed Kc. Result is103; generation is104..105. Split-assist acceleration107, packed enable+acceleration-limit108, braking109, braking-limit110. Enable occupies the high two bits of108, acceleration limit the low six.

Assist writes class4/selectors31..35. It is disabled before changing fields and enabled last; every selected target is then checked against a fresh full custom page. PID uses begin10/token, Ka11, Kg12, Kc13, mode14, commit15 with the same LE16token. Success requires result1, a changed generation and matching fresh mode/gains. Turning PID off confirms only the disabled mode; it does not falsely claim unused gains were saved as overrides.

All settings are drafts until the owner reviews the before/after list and confirms the wheel is stopped inP. Fresh stationary telemetry is checked before application and every write chunk. The actual firmware additionally rejects PID commit outside its allowed parking state. Settings frames are split into<=20-byte writes and sent serially, respecting write acknowledgments/backpressure. Writes interrupted by motion, stale telemetry or a disconnect stop without replay. Partial application is explicitly reported, not rolled back using guessed state.

The extended firmware bench now verifies19stock cases, disable/re-enable normalization, split-assist packed readback and the complete staged PID commit. It additionally forces the ordinary settings-page selector to8 to execute the actual field serializer, without simulating unrelated BMS page scheduling. `WheelFirmwareEvidence.json` supplies independent fixtures for159 Swift settings checks.

## Automatic connection

The main app calls `WheelConnection.shared.activate(demo:)` on launch and foreground entry, even before opening the wheel tab. After the first explicit device selection, auto-connect defaults on. It retrieves the saved peripheral and leaves an OS connection request pending until the wheel becomes available, rather than cancelling it after20seconds. Manual disconnect disables that intention; the visible toggle re-enables it. First-use scanning remains explicit and does not auto-select strangers. Discovered devices are selectable immediately at the top of the screen while scanning continues. Selecting one stops scanning; there is no12-second wait. A manual stop-search control is provided. No repeating scan timer is used.
