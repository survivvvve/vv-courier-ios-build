import Foundation

/// Real TelegramNotificationCenter + real Express.poll/performPoll bodies.
/// The runner supplies fake VV, system-notification, preferences and sender
/// boundaries. No Keychain, authorization, Telegram or courier request is made.
@main struct TelegramMonitoringTests {
    @MainActor static func parcel(_ id: String, express: Bool = false) -> Parcel {
        Parcel(["id_parcel": id, "id_general_view": "721100" + id, "shopno": 101, "weight": 1.25, "reward": 145.5, "fast_delivery": express ? 1 : 0])
    }
    @MainActor static func main() async throws {
        let domain = "telegram-monitor-fixture." + UUID().uuidString
        let defaults = UserDefaults(suiteName: domain)!
        defer { defaults.removePersistentDomain(forName: domain) }
        let session = Session(token: "offline-session", courierID: "1")
        SessionStore.stored = session
        let prefs = TelegramNotificationPreferences()
        var messages: [String] = []
        var uncertain = false
        let center = TelegramNotificationCenter(defaults: defaults, preferences: prefs, sessionProvider: { SessionStore.load() }, sender: { _, destination, text in
            precondition(destination.chatID == "-100123")
            precondition(text.utf16.count <= 3500 && !text.contains("#") && !text.contains("721100"))
            let saved = defaults.data(forKey: "telegram.notifications.delivery.v1")!
            let object = try JSONSerialization.jsonObject(with: saved) as! [String: Any]
            precondition(!(object["attempted"] as! [String: Any]).isEmpty, "Delivery intent must be saved before sender starts")
            messages.append(text)
            if uncertain { throw TelegramBotError.uncertain }
        })
        center.configure(session: session, shops: [101], demo: false, known: true, active: true)
        let poller = ExpressPollHarness(center, prefs)
        let vv = VVFixture.shared; vv.reset(); vv.assembly = [parcel("1")]
        precondition(!poller.preferences.enabled && !poller.allowed, "Fixture covers native disabled and UN permission denied")
        _ = await poller.poll(session: session, shops: [101])
        precondition(messages.isEmpty && vv.assemblyReads == 1 && vv.readyReads == 1 && vv.activeReads == 2, "First inventory must be quiet")
        vv.assembly = [parcel("1"), parcel("2"), parcel("3", express: true)]
        let sent = await poller.poll(session: session, shops: [101])
        precondition(sent == true && messages.count == 1 && messages[0].contains("11002") && messages[0].contains("11003"), "Telegram must receive all-order events despite native being off")
        precondition(vv.assemblyReads == 2 && vv.readyReads == 2 && vv.activeReads == 5, "One shared feed pair plus fresh active check before the send")
        precondition(poller.notifications.added.isEmpty && poller.backgroundSchedules > 0)
        _ = await poller.poll(session: session, shops: [101])
        precondition(messages.count == 1, "Same inventory must not send twice")
        vv.ready = [parcel("2")]
        vv.assembly = [parcel("1"), parcel("3", express: true)]
        _ = await poller.poll(session: session, shops: [101])
        precondition(messages.count == 2 && messages.last!.contains("Заказ готов"), "Ready requires a successful ready snapshot")
        // Coalescing executes the production pollTask code, not a second VV loop.
        let beforeCoalesce = vv.assemblyReads
        async let a = poller.poll(session: session, shops: [101])
        async let b = poller.poll(session: session, shops: [101])
        _ = await (a, b)
        precondition(vv.assemblyReads == beforeCoalesce + 1, "Concurrent callers must share the same successful feed pair")
        // A closed shift on the immediate pre-send check blocks delivery.
        let beforeClosed = messages.count
        let activeBefore = vv.activeReads
        vv.assembly.append(parcel("4"))
        vv.onActive = { if vv.activeReads == activeBefore + 3 { vv.active = false } }
        let closed = await poller.poll(session: session, shops: [101])
        precondition(closed == false && messages.count == beforeClosed && !center.active)
        vv.onActive = nil; vv.active = true
        center.configure(session: session, shops: [101], demo: false, known: true, active: true)
        _ = await poller.poll(session: session, shops: [101])
        precondition(messages.count == beforeClosed, "New shift must baseline quietly")
        // Live preferences changing during the fresh VV check must prevent send.
        let activeAtSettings = vv.activeReads
        vv.assembly.append(parcel("5"))
        vv.onActive = { if vv.activeReads == activeAtSettings + 3 { prefs.enabled = false; prefs.revision += 1 } }
        _ = await poller.poll(session: session, shops: [101])
        precondition(messages.count == beforeClosed)
        vv.onActive = nil; prefs.enabled = true; prefs.revision += 1
        center.configure(session: session, shops: [101], demo: false, known: true, active: true)
        _ = await poller.poll(session: session, shops: [101])
        // An ambiguous timeout is attempted once, persisted, and never replayed.
        uncertain = true; vv.assembly.append(parcel("6"))
        _ = await poller.poll(session: session, shops: [101])
        let uncertainCount = messages.count
        _ = await poller.poll(session: session, shops: [101])
        precondition(messages.count == uncertainCount && center.lastSentAt != nil)
        let restored = TelegramNotificationCenter(defaults: defaults, preferences: prefs, sessionProvider: { SessionStore.load() }, sender: { _, _, text in messages.append(text) })
        restored.configure(session: session, shops: [101], demo: false, known: true, active: true)
        let restoredPoller = ExpressPollHarness(restored, prefs)
        _ = await restoredPoller.poll(session: session, shops: [101])
        precondition(messages.count == uncertainCount, "Restart must neither replay uncertain sends nor announce old inventory")
        // Expired/replaced VV session is checked again immediately before send.
        let identityReads = vv.activeReads
        vv.assembly.append(parcel("7"))
        vv.onActive = { if vv.activeReads == identityReads + 3 { SessionStore.stored = Session(token: "other-session", courierID: "2") } }
        _ = await restoredPoller.poll(session: session, shops: [101])
        precondition(messages.count == uncertainCount)
        vv.onActive = nil; SessionStore.stored = session
        restored.endObservation()
        precondition(!restored.active)
        restored.configure(session: session, shops: [101], demo: true, known: true, active: true)
        precondition(!restored.active)
        // Native notices must be delivered before the Telegram await begins.
        let nativePrefs = TelegramNotificationPreferences()
        var nativePoller: ExpressPollHarness!
        var nativeAndTelegramSends = 0
        let nativeCenter = TelegramNotificationCenter(defaults: defaults, preferences: nativePrefs, sessionProvider: { SessionStore.load() }, sender: { _, _, _ in
            precondition(nativePoller.notifications.added.count == 1, "Native UN delivery must not wait behind Telegram network delivery")
            nativeAndTelegramSends += 1
        })
        nativeCenter.configure(session: session, shops: [101], demo: false, known: true, active: true)
        nativePoller = ExpressPollHarness(nativeCenter, nativePrefs)
        nativePoller.preferences.enabled = true; nativePoller.allowed = true
        _ = await nativePoller.poll(session: session, shops: [101])
        vv.assembly.append(parcel("30", express: true))
        _ = await nativePoller.poll(session: session, shops: [101])
        precondition(nativeAndTelegramSends == 1)
        nativePoller.preferences.enabled = false; nativePoller.pauseDelivery()
        vv.assembly.append(parcel("31"))
        _ = await nativePoller.poll(session: session, shops: [101])
        precondition(nativeAndTelegramSends == 2, "Production native pause must leave Telegram delivery running")
        // Batches are bounded and carry every distinct event once.
        let many = (0..<160).map { index in
            TelegramOrderEvent(epoch: "fixture", courierID: "1", parcel: TelegramOrderRecord(id: String(index), label: "00000" + String(index), shopID: 101, weight: 3.25, reward: 150.25, express: true), kind: .created, observedAt: Date())
        }
        let batches = TelegramNotificationBatch.make(many)
        precondition(batches.count > 1 && batches.allSatisfy { $0.text.utf16.count <= 3500 })
        precondition(Set(batches.flatMap(\.eventIDs)) == Set(many.map(\.id)))
        print("Telegram monitoring passed: actual shared poll, native-off/permission-independent delivery, quiet base, batching, fresh shift/session/settings guards, one uncertain attempt, persistence and no replay")
    }
}
