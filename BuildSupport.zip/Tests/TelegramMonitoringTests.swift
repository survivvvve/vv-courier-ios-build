import Foundation

/// Actual disabled Telegram center and Express poll/pause bodies; no network.
@main struct TelegramMonitoringTests {
    @MainActor static func parcel(_ id: String, express: Bool = false) -> Parcel {
        Parcel(["id_parcel": id, "id_general_view": "721100" + id, "shopno": 101, "weight": 1.25, "reward": 145.5, "fast_delivery": express ? 1 : 0])
    }
    @MainActor static func main() async throws {
        let domain = "telegram-disabled-fixture." + UUID().uuidString
        let defaults = UserDefaults(suiteName: domain)!
        defer { defaults.removePersistentDomain(forName: domain) }
        let session = Session(token: "offline-session", courierID: "1")
        SessionStore.stored = session
        // Deliberately enabled legacy configuration: the production center's
        // own hard guard must prevent direct-call delivery, not just a UI flag.
        let prefs = TelegramNotificationPreferences()
        precondition(prefs.enabled && prefs.monitoringEnabled && prefs.isConfigured)
        var sends = 0, telegramShiftChecks = 0
        let center = TelegramNotificationCenter(defaults: defaults, preferences: prefs,
            sessionProvider: { SessionStore.load() }, sender: { _, _, _ in sends += 1 })
        center.configure(session: session, shops: [101], demo: false, known: true, active: true)
        precondition(!center.monitoringEnabled && !center.active)
        for (assembling, ready) in [([parcel("1")], []), ([parcel("1"), parcel("2", express: true)], []), ([], [parcel("2", express: true)])] {
            _ = try await center.consume(session: session, shops: [101], assembling: assembling, ready: ready,
                quiet: false, confirmedAt: Date(), isCurrent: { true }, confirmActive: { telegramShiftChecks += 1; return true })
        }
        precondition(sends == 0 && telegramShiftChecks == 0, "Direct stale callers must not send or cause Telegram-specific VV reads")
        let poller = ExpressPollHarness(center, prefs)
        let vv = VVFixture.shared; vv.reset(); vv.assembly = [parcel("1", express: true)]
        let disabled = await poller.poll(session: session, shops: [101])
        precondition(disabled == nil && vv.activeReads == 0 && vv.assemblyReads == 0 && vv.readyReads == 0,
            "Saved Telegram settings cannot keep VV polling alive when native notices are off")
        precondition(poller.backgroundSchedules == 0 && sends == 0)
        poller.preferences.enabled = true
        _ = await poller.poll(session: session, shops: [101])
        precondition(poller.foregroundEvents.isEmpty && vv.activeReads == 2, "Native first inventory stays quiet")
        vv.assembly.append(parcel("2", express: true))
        _ = await poller.poll(session: session, shops: [101])
        precondition(poller.foregroundEvents.count == 1 && poller.foregroundEvents[0].parcel.id == "2",
            "Native in-app notice still works with denied iOS notification permission")
        precondition(poller.notifications.added.isEmpty && sends == 0 && telegramShiftChecks == 0)
        let reads = vv.activeReads
        poller.allowed = true; vv.assembly.append(parcel("3", express: true))
        _ = await poller.poll(session: session, shops: [101])
        precondition(poller.notifications.added.count == 1 && vv.activeReads == reads + 2,
            "Native system notice works without a third Telegram-specific shift read")
        precondition(poller.backgroundSchedules > 0 && sends == 0)
        _ = await poller.poll(session: session, shops: [101])
        precondition(poller.notifications.added.count == 1, "Same native inventory does not notify twice")
        vv.ready = [parcel("3", express: true)]; vv.assembly.removeAll { $0.id == "3" }
        _ = await poller.poll(session: session, shops: [101])
        precondition(poller.notifications.added.count == 2 && poller.notifications.added.last?.content.title == ExpressEventKind.ready.title,
            "Native express-ready transition remains operational")
        let beforeCoalesce = vv.assemblyReads
        async let a = poller.poll(session: session, shops: [101])
        async let b = poller.poll(session: session, shops: [101])
        _ = await (a, b)
        precondition(vv.assemblyReads == beforeCoalesce + 1, "Native callers still coalesce one complete feed pair")
        let beforeClosed = poller.notifications.added.count, activeBefore = vv.activeReads
        vv.assembly.append(parcel("4", express: true))
        vv.onActive = { if vv.activeReads == activeBefore + 2 { vv.active = false } }
        let closed = await poller.poll(session: session, shops: [101])
        precondition(closed == false && poller.notifications.added.count == beforeClosed && poller.foregroundEvents.isEmpty,
            "Shift closing during feeds blocks native delivery")
        vv.onActive = nil; vv.active = true
        _ = await poller.poll(session: session, shops: [101])
        precondition(poller.notifications.added.count == beforeClosed, "New shift baselines old orders quietly")
        let identityReads = vv.activeReads
        vv.assembly.append(parcel("5", express: true))
        vv.onActive = { if vv.activeReads == identityReads + 2 { SessionStore.stored = Session(token: "other-session", courierID: "2") } }
        _ = await poller.poll(session: session, shops: [101])
        precondition(poller.notifications.added.count == beforeClosed, "Replaced session blocks native notice")
        vv.onActive = nil; SessionStore.stored = session
        poller.preferences.enabled = false; poller.pauseDelivery()
        let pausedReads = vv.activeReads
        _ = await poller.poll(session: session, shops: [101])
        precondition(vv.activeReads == pausedReads && poller.foregroundEvents.isEmpty && !poller.ledger.active,
            "Native pause leaves no Telegram-only poll behind")
        precondition(sends == 0 && telegramShiftChecks == 0)
        print("Telegram disabled monitoring passed: stale config/direct calls cannot send or poll; native baseline, foreground/system, ready, coalescing, shift/session guards and pause preserved; no network.")
    }
}
