#!/usr/bin/env python3
"""Read-only software evidence for the user's exact Sherman L image.

Requires the reputable PyPI unicorn package; never connects to BLE or flashes a
wheel. Firmware itself is not included. Run with the original .bin path.
The actual ring-buffer receiver, dispatcher and readback hook execute. Hardware
CRC peripheral is replaced by equivalent zlib CRC32, persistent record writer by
success, and buzzer by a no-op. Thus this is NOT a physical hardware validation.
"""
import hashlib
import json
from pathlib import Path
import struct
import sys
import zlib
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS, UC_HOOK_CODE
from unicorn.arm_const import UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_SP, UC_ARM_REG_LR, UC_ARM_REG_PC

EXPECTED_SHA = 'd82deab1e736d7acb96717d4c3b2863babbe4b26ec83b19ecf5be7ea57f305d6'
class ImageBench:
    def __init__(self, image):
        self.cpu = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
        self.cpu.mem_map(0x08000000, 0x40000)
        self.cpu.mem_write(0x08004000, image)
        self.cpu.mem_map(0x20000000, 0x10000)
        self.cpu.mem_map(0x09000000, 0x1000)
        self.cpu.mem_write(0x09000000, b'\x00\xbe')
        self.cpu.hook_add(UC_HOOK_CODE, self.hardware_stubs)
        self.put(0x20004067, 'B', 1)
        self.put(0x20004088, 'I', 0x028C9464)
        self.put(0x20000096, 'H', 0xE9C2)
    def hardware_stubs(self, cpu, address, size, context):
        if address == 0x0800811C:
            cpu.reg_write(UC_ARM_REG_R0, 8)
            cpu.reg_write(UC_ARM_REG_PC, cpu.reg_read(UC_ARM_REG_LR))
        if address == 0x08005994:
            pointer, length = cpu.reg_read(UC_ARM_REG_R0), cpu.reg_read(UC_ARM_REG_R1)
            cpu.reg_write(UC_ARM_REG_R0, zlib.crc32(bytes(cpu.mem_read(pointer, length))))
            cpu.reg_write(UC_ARM_REG_PC, cpu.reg_read(UC_ARM_REG_LR))
        if address in (0x0801990C, 0x0801A90C):
            cpu.reg_write(UC_ARM_REG_R0, 1)
            cpu.reg_write(UC_ARM_REG_PC, cpu.reg_read(UC_ARM_REG_LR))
    def put(self, address, fmt, value):
        self.cpu.mem_write(address, struct.pack('<' + fmt, value))
    def get(self, address, fmt):
        return struct.unpack('<' + fmt, self.cpu.mem_read(address, struct.calcsize('<' + fmt)))[0]
    def call(self, address, *args):
        self.cpu.reg_write(UC_ARM_REG_SP, 0x2000F000)
        self.cpu.reg_write(UC_ARM_REG_LR, 0x09000001)
        for register, value in zip((UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3), args):
            self.cpu.reg_write(register, value)
        self.cpu.emu_start(address | 1, 0x09000000, count=10000)
        assert self.cpu.reg_read(UC_ARM_REG_PC) == 0x09000000, 'Instruction limit exceeded'
        return self.cpu.reg_read(UC_ARM_REG_R0)
    def receive(self, frame):
        self.cpu.mem_write(0x20005000, frame + bytes(256 - len(frame)))
        self.cpu.mem_write(0x20006000, bytes(256))
        self.cpu.mem_write(0x20006012, bytes([128] * 80))
        success = []
        for index in range(len(frame)):
            self.put(0x2000F000, 'I', 0x20006000)
            if self.call(0x08009816, 0x20005000, 256, index, 0x08012990) == 1:
                success.append(index)
        if success:
            assert success == [len(frame) - 1], success
            self.call(0x08019C34, 0x20006000)
        return success
    def stock_page(self):
        self.call(0x0800FCE4, 0x20006500)
        return bytes(self.cpu.mem_read(0x20006500, 25))
    def custom_page(self):
        self.put(0x20004068, 'B', 8)
        self.call(0x08019B24, 0x20006500)
        return bytes(self.cpu.mem_read(0x20006500, 65))
    def alarm_header(self):
        self.cpu.mem_write(0x20006600, bytes([128] * 6))
        self.call(0x08019C18, 0x20006600)
        return bytes(self.cpu.mem_read(0x20006600, 6)).hex()

def command(payload):
    data = b'LdAp' + bytes([len(payload) + 9]) + bytes(payload)
    return data + struct.pack('>I', zlib.crc32(data))

def main():
    image = Path(sys.argv[1]).read_bytes()
    assert hashlib.sha256(image).hexdigest() == EXPECTED_SHA, 'Image differs from verified contract'
    results = []
    bench = ImageBench(image)
    for target in (True, False):
        wire = command([0, 0x61, 3, 1, 3, int(target), 0])
        assert bench.receive(wire)
        assert bench.get(0x20004012, 'H') == int(target)
        header = bench.alarm_header()
        assert header == ('4c4303238001' if target else '4c4303238000')
        results.append(dict(action='arm' if target else 'disarm', frame=wire.hex(), readback=header))
    for phase in (1, 2):
        bench.receive(command([0, 0x61, 3, 1, 3, 1, 0]))
        bench.put(0x20004002, 'H', phase)
        assert bench.alarm_header() == f'4c430323800{phase + 1}'
    for target in (True, False):
        wire = command([0, 2, int(target)])
        assert bench.receive(wire)
        assert bench.get(0x200001AD, 'B') == int(target)
        results.append(dict(action='lamp_on' if target else 'lamp_off', frame=wire.hex(), lamp_byte=int(target)))
    rolling = ImageBench(image)
    rolling.put(0x20000096, 'H', 60001)
    rolling.receive(command([0, 0x61, 3, 1, 3, 1, 0]))
    assert rolling.get(0x20004012, 'H') == 0
    wrong_abi = ImageBench(image)
    wrong_abi.receive(command([0, 0x61, 3, 1, 2, 1, 0]))
    assert wrong_abi.get(0x20004012, 'H') == 0
    corrupt = bytearray(command([0, 0x61, 3, 1, 3, 1, 0]))
    corrupt[-1] ^= 1
    assert not ImageBench(image).receive(bytes(corrupt))
    settings = []
    # key, payload position, wire value, page8 position, expected raw readback
    stock_cases = [('hardness',5,83,4,83),('pedal_angle',6,-36,5,220),('tiltback',7,42,6,42),('tiltback_disabled',7,101,6,200),('pwm',8,82,7,82),('pwm_disabled',8,96,7,200),('alarm',9,35,8,35),('alarm_disabled',9,101,8,200),('brightness',10,70,9,70),('transport',12,1,11,1),('units',13,1,12,1),('low_battery',15,1,14,1),('voltage_trim',14,-5,13,251),('high_speed',16,1,15,1),('lateral_cutoff',17,60,16,60),('key_volume',18,60,17,60),('charge',19,62,18,62),('stock_assist',21,64,20,64),('dip_compensation',23,25,22,25)]
    for key, position, value, page_offset, expected in stock_cases:
        payload = [128] * (position + 1); payload[0:2] = [0,2]; payload[position] = value & 255
        wire = command(payload); assert bench.receive(wire)
        readback = bench.stock_page(); assert readback[0] == 8 and readback[page_offset] == expected, (key,readback.hex())
        settings.append(dict(setting=key,frame=wire.hex(),page8=readback.hex()))
    # Re-enable values after the firmware-normalized disabled sentinels.
    for position,page_offset,value in [(7,6,45),(8,7,85),(9,8,40)]:
        payload=[128]*(position+1);payload[0:2]=[0,2];payload[position]=value
        bench.receive(command(payload));assert bench.stock_page()[page_offset]==value
    for selector,value in zip(range(0x31,0x36),[1,87,35,62,51]):
        assert bench.receive(command([0,0x61,4,selector,3,value,0]))
    custom=bench.custom_page();assert list(custom[61:65])==[87,99,62,51],custom.hex()
    settings.append(dict(setting='custom_assist',page80=custom.hex()))
    # PID is staged and committed with one exact token; active values are not
    # changed by the prepare/individual parameter frames.
    for selector,value in [(0x10,1234),(0x11,2280),(0x12,1170),(0x13,-300),(0x14,1)]:
        assert bench.receive(command([0,0x61,4,selector,3,value&255,(value>>8)&255]))
    assert bench.get(0x2000401E,'B')==0
    bench.receive(command([0,0x61,4,0x15,3,210,4]))
    pid=bench.custom_page();assert pid[1]==1 and pid[57]==1 and pid[58:60]==b'\x00\x01',pid.hex()
    assert list(struct.unpack('>hhh',pid[10:16]))==[2280,1170,-300],pid.hex()
    settings.append(dict(setting='pid_transaction',page80=pid.hex()))
    print(json.dumps(dict(image_sha256=EXPECTED_SHA, hardware_tested=False,
                         stubs=['hardware_crc32_via_zlib', 'persistent_record_writer_success', 'buzzer_noop', 'page_selector_forced_to_settings_page8'],
                         checks=['arm', 'disarm', 'warning_readback', 'siren_readback', 'lamp_on', 'lamp_off', 'reject_nonparking_arm', 'reject_wrong_abi', 'reject_corrupted_crc'],
                         traces=results, settings=settings), indent=2))
if __name__ == '__main__':
    main()
