import Foundation

final class PaymentFixtureProtocol: URLProtocol {
    static var handler: ((URLRequest) throws -> Any)!
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let object = try Self.handler(request)
            let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil, headerFields: ["Content-Type": "application/json"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: try JSONSerialization.data(withJSONObject: object))
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

@main enum PaymentTests {
    static func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open(); defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 4096)
            while stream.hasBytesAvailable {
                let count = stream.read(&buffer, maxLength: buffer.count)
                guard count > 0 else { break }
                data.append(contentsOf: buffer.prefix(count))
            }
        }
        return try JSONSerialization.jsonObject(with: data) as! [String: Any]
    }
    static func rejects(_ action: () throws -> Void) {
        do { try action(); preconditionFailure("Expected a validation rejection") } catch {}
    }
    static func main() async throws {
        let terminal: [String: Any] = ["res": 2, "terminal_id": "12345678", "shopno": 101]
        let parcel: [String: Any] = ["id_parcel": "123", "shopno": 101, "pay_way": 3, "pay_summ": "2500.01", "parcel_status": "arrived"]
        precondition(DeliveryPaymentRules.methods(terminal: terminal) == [.terminal, .cash, .terminalQR])
        precondition(DeliveryPaymentRules.methods(terminal: ["res": 2, "terminal_id": "S-123", "shopno": 101]) == [.cash], "Do not imitate LifePay acquiring")
        precondition(DeliveryPaymentRules.methods(terminal: [:]) == [.cash])
        precondition(DeliveryPaymentRules.methods(terminal: ["terminal_id": "12345678", "shopno": 101]) == [.cash], "Missing res must not become assigned status0")
        precondition(DeliveryPaymentRules.methods(terminal: ["res": "nan", "terminal_id": "12345678", "shopno": 101]) == [.cash])
        precondition(DeliveryPaymentRules.amount("2\u{202f}500,01") == Decimal(string: "2500.01"))
        precondition(DeliveryPaymentRules.amount("2500 rub") == nil)
        precondition(DeliveryPaymentRules.amountDue(["pay_summ": 0, "pay_sum_cancelled": "123.45"]) == Decimal(string: "123.45"))
        for method in DeliveryPaymentMethod.allCases {
            let confirmation = DeliveryPaymentConfirmation(method: method, amountDue: Decimal(string: "2500.01")!, cashReceived: 5000)
            let body = try DeliveryPaymentRules.completionBody(parcel: parcel, courierID: "7", confirmation: confirmation, terminal: terminal, flags: [100])
            precondition(body["status"] as? String == "delivered")
            precondition(body["sum_pay"] as? String == "2500.01")
            precondition(body["pay_way"] as? Int == method.payWay)
            if method == .cash {
                precondition(body["cash_received"] as? Int64 == 250001, "Cash balance uses order price in kopecks, never tendered banknote")
                precondition(body["id_terminal"] == nil)
            } else { precondition(body["id_terminal"] as? String == "12345678") }
            precondition(body["type_id"] as? Int == (method == .terminalQR ? 2 : nil))
        }
        rejects { _ = try DeliveryPaymentRules.completionBody(parcel: parcel, courierID: "7", confirmation: nil, terminal: terminal, flags: []) }
        rejects { _ = try DeliveryPaymentRules.completionBody(parcel: parcel, courierID: "7", confirmation: DeliveryPaymentConfirmation(method: .cash, amountDue: Decimal(string: "2500.01")!, cashReceived: 1000), terminal: terminal, flags: []) }
        rejects { _ = try DeliveryPaymentRules.completionBody(parcel: parcel, courierID: "7", confirmation: DeliveryPaymentConfirmation(method: .terminal, amountDue: 2500), terminal: terminal, flags: []) }
        rejects { _ = try DeliveryPaymentRules.completionBody(parcel: parcel, courierID: "7", confirmation: DeliveryPaymentConfirmation(method: .terminal, amountDue: Decimal(string: "2500.01")!), terminal: [:], flags: []) }
        var unknownPaid = parcel; unknownPaid["paid"] = "pending"
        precondition(!DeliveryPaymentRules.collectionNotRequired(unknownPaid), "Unknown paid status cannot stand in for confirmed payment")
        for way in [3, 4] {
            for paid in [false, true] {
                var row = parcel; row["pay_way"] = way; row["paid"] = paid
                row["pay_summ"] = paid ? "0" : 0
                row["pay_sum_cancelled"] = paid ? "123.45" : "0"
                precondition(DeliveryPaymentRules.collectionNotRequired(row))
                let payload = try DeliveryPaymentRules.completionBody(parcel: row, courierID: "7", confirmation: nil, terminal: [:], flags: [100])
                precondition(NSDictionary(dictionary: payload).isEqual(to: ["id_courier": "7", "id_parcel": "123", "status": "delivered", "pay_way": 4, "sum_pay": "0"]), "Exact A6e payload: no cash received, terminal ID or cancelled sum")
                rejects { _ = try DeliveryPaymentRules.completionBody(parcel: row, courierID: "7", confirmation: DeliveryPaymentConfirmation(method: .cash, amountDue: DeliveryPaymentRules.amountDue(row)!, cashReceived: 5000), terminal: [:], flags: [100]) }
            }
        }
        precondition(DeliveryPaymentRules.actualPaymentWay(["pay_way": 3]) == nil, "Planned terminal method is not evidence of actual payment after A6e")
        var hyperlink = parcel; hyperlink["pay_way"] = 9
        precondition(!DeliveryPaymentRules.collectionNotRequired(hyperlink))
        rejects { _ = try DeliveryPaymentRules.completionBody(parcel: hyperlink, courierID: "7", confirmation: DeliveryPaymentConfirmation(method: .cash, amountDue: Decimal(string: "2500.01")!, cashReceived: 5000), terminal: [:], flags: [100]) }
        let config = URLSessionConfiguration.ephemeral; config.protocolClasses = [PaymentFixtureProtocol.self]
        let transport = URLSession(configuration: config); defer { transport.invalidateAndCancel() }
        let api = CourierAPI(session: Session(token: "offline-fixture", courierID: "7"), transport: transport)
        var changes = 0, requested: [String] = []
        PaymentFixtureProtocol.handler = { request in
            let path = request.url!.path; requested.append(path)
            if path.hasSuffix("get_parcels_assigned_to_me_ext") { return ["parcels": [parcel], "checking": ["parcels_packages_inspection_after": ["123": 0]]] }
            if path.hasSuffix("get_parcel") { return ["parcel": parcel] }
            if path.hasSuffix("shops") { return ["shops": [["shopno": 101, "done_order_check": false]]] }
            if path.hasSuffix("terminal/getreturn") { return terminal }
            if path == "/v1/tasks/active" { return [100] }
            if path == "/v3/courier/change_task_status" {
                changes += 1
                let body = try Self.body(request)
                precondition(body["pay_way"] as? Int == 3 && body["id_terminal"] as? String == "12345678")
                precondition(body["type_id"] as? Int == 2)
                return [:] as [String: Any]
            }
            preconditionFailure("Unexpected payment request \(path)")
        }
        let completion = try await api.completeDelivery("123", confirmation: DeliveryPaymentConfirmation(method: .terminalQR, amountDue: Decimal(string: "2500.01")!))
        precondition(completion.needsReceipt && changes == 1)
        precondition(requested.last == "/v3/courier/change_task_status", "Do not turn a refresh failure after successful acknowledgement into re-close")
        let countBefore = changes
        do {
            _ = try await api.completeDelivery("123", confirmation: DeliveryPaymentConfirmation(method: .terminalQR, amountDue: 100))
            preconditionFailure("Price race must fail before mutation")
        } catch {}
        precondition(changes == countBefore)
        var closeAttempts = 0
        PaymentFixtureProtocol.handler = { request in
            let path = request.url!.path
            if path.hasSuffix("get_parcels_assigned_to_me_ext") { return ["parcels": [parcel], "checking": ["parcels_packages_inspection_after": ["123": 0]]] }
            if path.hasSuffix("get_parcel") {
                var refreshed = parcel
                if closeAttempts > 0 { refreshed["parcel_status"] = "delivered"; refreshed["pay_way_fact"] = 3 }
                return ["parcel": refreshed]
            }
            if path.hasSuffix("shops") { return ["shops": [["shopno": 101, "done_order_check": false]]] }
            if path.hasSuffix("terminal/getreturn") { return terminal }
            if path == "/v3/courier/change_task_status" { closeAttempts += 1; throw URLError(.timedOut) }
            preconditionFailure("Unexpected recovery request \(path)")
        }
        let recovered = try await api.completeDelivery("123", confirmation: DeliveryPaymentConfirmation(method: .terminal, amountDue: Decimal(string: "2500.01")!))
        precondition(closeAttempts == 1 && recovered.needsReceipt, "Lost response must use readback, never a repeated close")
        for zero in [false, true] {
            var paidParcel = parcel
            paidParcel["paid"] = !zero; paidParcel["pay_summ"] = zero ? 0 : "2500.01"; paidParcel["pay_sum_cancelled"] = 0
            var paidWrites = 0, terminalReads = 0
            PaymentFixtureProtocol.handler = { request in
                let path = request.url!.path
                if path.hasSuffix("get_parcels_assigned_to_me_ext") { return ["parcels": [paidParcel], "checking": ["parcels_packages_inspection_after": ["123": 0]]] }
                if path.hasSuffix("get_parcel") {
                    var refreshed = paidParcel
                    if paidWrites > 0 { refreshed["parcel_status"] = "delivered"; refreshed["pay_way_fact"] = 3 }
                    return ["parcel": refreshed]
                }
                if path.hasSuffix("shops") { return ["shops": [["shopno": 101, "done_order_check": false]]] }
                if path.hasSuffix("terminal/getreturn") { terminalReads += 1; return terminal }
                if path == "/v3/courier/change_task_status" {
                    paidWrites += 1
                    let payload = try Self.body(request)
                    precondition(NSDictionary(dictionary: payload).isEqual(to: ["id_courier": "7", "id_parcel": "123", "status": "delivered", "pay_way": 4, "sum_pay": zero ? "0" : "2500.01"]))
                    if zero { throw URLError(.timedOut) }
                    return [:] as [String: Any]
                }
                preconditionFailure("Unexpected paid branch request \(path)")
            }
            let closed = try await api.completeDelivery("123", confirmation: nil)
            precondition(paidWrites == 1 && terminalReads == 0 && closed.payWay == 3 && closed.needsReceipt, "Paid/zero A6e body must not hide actual terminal receipt or repeat a timeout")
        }
        PaymentFixtureProtocol.handler = { request in
            if request.url!.path.hasSuffix("get_parcels_assigned_to_me_ext") { return ["parcels": [hyperlink]] }
            if request.url!.path.hasSuffix("get_parcel") { return ["parcel": hyperlink] }
            preconditionFailure("Unsupported hyperlink must not request GPS rules/terminal or mutate")
        }
        do { _ = try await api.completeDelivery("123", confirmation: DeliveryPaymentConfirmation(method: .cash, amountDue: Decimal(string: "2500.01")!, cashReceived: 5000)); preconditionFailure("Hyperlink conversion accepted") } catch is CourierError {}
        PaymentFixtureProtocol.handler = { request in
            let body = try Self.body(request)
            if request.url!.path.hasSuffix("upload_parcel_receipt_photo") {
                precondition(body["id_courier"] as? String == "7" && body["format"] as? String == "jpeg")
                precondition(body["file"] as? String == "AQI", "Use unpadded base64 as the official upload contract")
                return ["id": 55]
            }
            precondition(request.url!.path.hasSuffix("change_parcel_receipt_photos"))
            precondition(body["id_parcel"] as? String == "123" && body["add"] as? [Int] == [55])
            precondition((body["remove"] as? [Any])?.isEmpty == true)
            return ["check_photo": [["id_photo": 55, "url_photo": "https://fixture.invalid/55.jpg"]]]
        }
        let id = try await api.uploadReceiptPhoto(Data([1, 2]))
        let photos = try await api.attachReceiptPhotos(parcelID: "123", uploadedIDs: [id])
        precondition(photos.map(\.id) == ["55"])
        PaymentFixtureProtocol.handler = { _ in ["check_photo": [["id_photo": 55, "url_photo": "https://fixture.invalid/55.jpg"]]] }
        do { _ = try await api.attachReceiptPhotos(parcelID: "123", uploadedIDs: ["55", "56"]); preconditionFailure("Partial photo acknowledgement accepted") } catch is CourierError {}
        try ReceiptDraftStore.save([ReceiptDraftPhoto(jpeg: Data([1, 2]), uploadedID: id)], courierID: "offline-fixture", parcelID: "123")
        precondition(ReceiptDraftStore.load(courierID: "offline-fixture", parcelID: "123").first?.uploadedID == id)
        ReceiptDraftStore.clear(courierID: "offline-fixture", parcelID: "123")
        precondition(ReceiptDraftStore.load(courierID: "offline-fixture", parcelID: "123").isEmpty)
        print("Payment contract regressions passed: cash/terminal/QR, paid/zero exact A6e payloads, actual receipt method, hyperlink rejection, price race, timeout single mutation, receipt upload/attach and persisted draft")
    }
}
