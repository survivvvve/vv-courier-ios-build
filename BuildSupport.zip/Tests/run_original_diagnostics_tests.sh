#!/bin/bash
set -euo pipefail
DIAGNOSTICS_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIAGNOSTICS_TEST_DIR="$(mktemp -d)"
trap 'rm -rf "$DIAGNOSTICS_TEST_DIR"' EXIT
cd "$DIAGNOSTICS_ROOT"
xcrun swiftc -swift-version 5 -parse-as-library Tests/OriginalDiagnosticsTests.swift -o "$DIAGNOSTICS_TEST_DIR/OriginalDiagnosticsTests"
"$DIAGNOSTICS_TEST_DIR/OriginalDiagnosticsTests"
