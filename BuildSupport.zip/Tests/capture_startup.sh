#!/bin/bash
# Offline app diagnostic on an isolated CI Mac. No account or live mutation.
set -u
STARTUP_DEVICE_ID="$1"
mkdir -p build
for STARTUP_ATTEMPT in $(seq 1 240); do
  STARTUP_APP_PID=$(pgrep -nf '[V]VCourier.app/VVCourier' || true)
  if [ -n "$STARTUP_APP_PID" ]; then
    /usr/bin/sample "$STARTUP_APP_PID" 3 -file build/startup-sample.txt >/dev/null 2>&1 || true
    xcrun simctl io "$STARTUP_DEVICE_ID" screenshot build/startup-diagnostic.png || true
    exit 0
  fi
  sleep 1
done
printf 'App process did not appear before diagnostic timeout.\n' > build/startup-sample.txt
