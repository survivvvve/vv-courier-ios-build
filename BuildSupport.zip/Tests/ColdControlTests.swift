import Foundation

// Production API extension and payload parser under test, using an explicit
// in-memory transport. No token, camera, photo, network or VV mutation is used.
struct CourierError: LocalizedError { let message: String; var statusCode: Int? = nil; var errorDescription: String? { message } }
struct Session { let courierID: String }
struct CourierAPI {
    static let root = "https://delivery-api.vkusvill.ru"
    let session: Session?
    let respond: (String, [String: Any]?) async throws -> [String: Any]
    func dictionary(_ url: String, body: [String: Any]? = nil) async throws -> [String: Any] { try await respond(url, body) }
}
final class ColdControlMock {
    var replies: [[String: Any]]
    var requests: [(String, [String: Any]?)] = []
    var failRead = false
    init(_ replies: [[String: Any]]) { self.replies = replies }
    func respond(_ url: String, _ body: [String: Any]?) async throws -> [String: Any] {
        requests.append((url, body))
        if failRead && body == nil { throw CourierError(message: "fixture readback failure") }
        precondition(!replies.isEmpty, "Unexpected extra request")
        return replies.removeFirst()
    }
}

@main enum ColdControlTests {
    static func main() async throws {
        precondition(ColdControlSignal.required(in: ["termocontrol": ["is_need_termocontrol": true]]) == true)
        precondition(ColdControlSignal.required(in: ["termocontrol": ["is_need_termocontrol": false]]) == false)
        for invalid: Any in [1, 0, "true", "false", NSNull(), ["other": true]] {
            precondition(ColdControlSignal.required(in: ["termocontrol": ["is_need_termocontrol": invalid]]) == nil)
        }
        precondition(ColdControlSignal.required(in: [:]) == nil)
        precondition(ColdControlSignal.required(from: true) == nil)
        precondition(ColdControlSignal.featureFlag == 227 && ColdControlSignal.businessError == 102)
        let pendingOwner = "offline-cold-" + UUID().uuidString
        ColdControlPendingStore.mark(courierID: pendingOwner, pending: true)
        precondition(ColdControlPendingStore.needsStatus(courierID: pendingOwner))
        precondition(!ColdControlPendingStore.needsStatus(courierID: pendingOwner + "-other"))
        ColdControlPendingStore.mark(courierID: pendingOwner, pending: false)
        precondition(!ColdControlPendingStore.needsStatus(courierID: pendingOwner))

        let image = Data([0xff, 0xd8, 0xff, 0xd9])
        let withPyro = try ColdControlRequest.body(photo: image, hasPyrometer: true, hasColdPacks: true)
        precondition(withPyro.count == 3 && withPyro["photo_file"] as? String == "/9j/2Q")
        precondition(withPyro["pirometr"] as? Bool == true && withPyro["freeze"] as? Bool == true)
        let noPyro = try ColdControlRequest.body(photo: image, hasPyrometer: false, hasColdPacks: true)
        precondition(noPyro["pirometr"] as? Bool == false && noPyro["freeze"] as? Bool == true)
        let noPacks = try ColdControlRequest.body(photo: nil, hasPyrometer: true, hasColdPacks: false)
        precondition(noPacks["photo_file"] is NSNull && noPacks["pirometr"] as? Bool == true && noPacks["freeze"] as? Bool == false)
        for input in [(nil as Data?, true, true), (Data(), true, true), (Data([1,2,3]), false, true), (image, true, false), (nil, false, false)] {
            do { _ = try ColdControlRequest.body(photo: input.0, hasPyrometer: input.1, hasColdPacks: input.2); preconditionFailure("Invalid input accepted") }
            catch is CourierError {}
        }

        let success = ColdControlMock([[:], ["clusters": [], "termocontrol": ["is_need_termocontrol": false]]])
        let client = CourierAPI(session: Session(courierID: "123"), respond: success.respond)
        let result = try await client.submitColdControl(photo: image, hasPyrometer: true, hasColdPacks: true)
        precondition(result.isComplete && success.requests.count == 2)
        precondition(success.requests[0].0 == CourierAPI.root + "/v1/courier/123/freeze_photo")
        precondition(success.requests[0].1?["photo_file"] as? String == "/9j/2Q")
        precondition(success.requests[1].0 == CourierAPI.root + "/v3/courier/queue/clusters/123" && success.requests[1].1 == nil)

        let stillRequired = ColdControlMock([[:], ["termocontrol": ["is_need_termocontrol": true]]])
        let waiting = try await CourierAPI(session: Session(courierID: "123"), respond: stillRequired.respond).submitColdControl(photo: nil, hasPyrometer: true, hasColdPacks: false)
        precondition(!waiting.isComplete && waiting.requiredAfterUpload == true && stillRequired.requests.count == 2)

        let unknown = ColdControlMock([[:]]); unknown.failRead = true
        let uncertain = try await CourierAPI(session: Session(courierID: "123"), respond: unknown.respond).submitColdControl(photo: image, hasPyrometer: true, hasColdPacks: true)
        precondition(!uncertain.isComplete && uncertain.requiredAfterUpload == nil && unknown.requests.count == 2, "Readback failure must not repeat an accepted write")

        let rejected = ColdControlMock([["business_error": 999, "message": "fixture rejection"]])
        do { _ = try await CourierAPI(session: Session(courierID: "123"), respond: rejected.respond).submitColdControl(photo: image, hasPyrometer: true, hasColdPacks: true); preconditionFailure("Nonempty response accepted") }
        catch is CourierError {}
        precondition(rejected.requests.count == 1)

        let unauthenticated = ColdControlMock([])
        do { _ = try await CourierAPI(session: nil, respond: unauthenticated.respond).submitColdControl(photo: image, hasPyrometer: true, hasColdPacks: true); preconditionFailure("Missing session accepted") }
        catch let error as CourierError { precondition(error.statusCode == 401) }
        precondition(unauthenticated.requests.isEmpty)
        print("Cold control: strict assignment signals, exact upload contract, acknowledgement/readback and retry safety checks passed")
    }
}
