import Foundation

// Compile alongside Models.swift, ParcelAddress.swift, ParcelMapModels.swift,
// Demo.swift. This standalone fixture test does not include live API credentials.
func truth(_ value: Any?) -> Bool { !["", "0", "false", "none", "<null>"].contains(string(value).lowercased()) }

@main enum ParcelAddressMapTests {
    static func main() {
        let base: [String: Any] = ["id_parcel": "fixture", "id_general_view": "12345678"]
        func parcel(_ extra: [String: Any]) -> Parcel { Parcel(base.merging(extra) { _, new in new }) }
        let legacy = parcel(["corr_addr": "Санкт-Петербург, посёлок Парголово, Полевая улица, 5к2", "user_address": "Квартира: 12; Домофон: 12Б; Подъезд: 3; Этаж: 7;"])
        precondition(legacy.address == "Полевая улица, 5к2 · кв. 12 · п 3 · эт. 7", legacy.address)
        precondition(legacy.doorphone == "12Б")
        let modern = parcel(["user_address": "", "corr_addr": "", "delivery_address": ["usable": true, "address": "Санкт-Петербург, Санкт-Петербургская улица, 8, стр. 2", "flat": "4", "entrance": "1", "floor": "0"]])
        precondition(modern.address == "Санкт-Петербургская улица, 8, стр. 2 · кв. 4 · п 1 · эт. 0", modern.address)
        let emptyModern = parcel(["user_address": "   ", "corr_addr": "Полевая улица, 5", "delivery_address": ["address": "", "flat": "9", "floor": "2"]])
        precondition(emptyModern.address == "Полевая улица, 5 · кв. 9 · эт. 2", emptyModern.address)
        let duplicate = parcel(["corr_addr": "Санкт-Петербург, Полевая улица, 5", "user_address": "Полевая улица, 5"])
        precondition(duplicate.address == "Полевая улица, 5", duplicate.address)
        let structured = parcel(["user_address": "", "delivery_address": ["street": "Улица Первого Мая", "house": "1", "corpus": "2", "structure": "3", "flat": "6"]])
        precondition(structured.address == "Улица Первого Мая, 1к2, стр. 3 · кв. 6", structured.address)
        let misleading = parcel(["corr_addr": "Городская улица, 9", "user_address": ""])
        precondition(misleading.address == "Городская улица, 9")
        precondition(ParcelCoordinate(["latitude": "60,075", "longitude": "30.33"]) == ParcelCoordinate(latitude: 60.075, longitude: 30.33))
        precondition(ParcelCoordinate(["latitude": "", "longitude": 30]) == nil)
        precondition(ParcelCoordinate(["latitude": 0, "longitude": 0]) == nil)
        precondition(ParcelCoordinate(["latitude": 91, "longitude": 30]) == nil)
        precondition(ParcelCoordinate(["latitude": "nan", "longitude": 30]) == nil)
        let mapped = parcel(["latitude": 0, "longitude": 0, "map_info": ["latitude": 60.1, "longitude": 30.2, "colour_parcel": "violet", "listNumber": "3"]])
        precondition(mapped.mapCoordinate == ParcelCoordinate(latitude: 60.1, longitude: 30.2))
        precondition(mapped.mapListNumber == 3)
        precondition(mapped.mapColorName(feed: .assembly) == "violet")
        precondition(ParcelMapColors.hex("violet") == "#A445F2")
        precondition(ParcelMapColors.hex("red") == "#E54F4F")
        precondition(ParcelMapColors.hex("green") == "#179C49")
        precondition(ParcelMapColors.hex("#abc") == "#AABBCC")
        precondition(ParcelMapColors.hex("unknown") == "#187BCC")
        for feed in Feed.allCases {
            let demo = Demo.orders(feed)
            precondition(demo.allSatisfy { $0.address.contains("улиц") || $0.address.contains("проспект") || $0.address.contains("переулок") })
            precondition(demo.allSatisfy { $0.mapCoordinate != nil })
        }
        let assembly = ParcelMapEntry.entries(Demo.orders(.assembly), feed: .assembly)
        precondition(assembly.map(\.number) == [1, 2, 1, 2])
        precondition(assembly.map(\.colorName) == ["violet", "violet", "red", "red"])
        let shopColored = parcel(["shopno": 42])
        precondition(ParcelMapEntry.entries([shopColored], feed: .available, shopColors: [42: "pink"]).first?.colorName == "pink")
        precondition(Shop(["shopno": 42, "color": "pink", "address": "", "Adress": "Полевая улица, 1"])?.color == "pink")
        precondition(Shop(["shopno": 42, "address": "", "Adress": "Полевая улица, 1"])?.address == "Полевая улица, 1")
        let shopLocation = Shop(["shopno": 42, "latitude_tt": "60,073", "longitude_tt": "30.335"])!
        precondition(shopLocation.mapCoordinate == ParcelCoordinate(latitude: 60.073, longitude: 30.335))
        precondition(Shop(["shopno": 42, "latitude": "nan", "longitude": 30])?.mapCoordinate == nil)
        precondition(Shop(["shopno": 42, "latitude": 0, "longitude": 0])?.mapCoordinate == nil)
        let restoredShop = try! JSONDecoder().decode(Shop.self, from: JSONEncoder().encode(shopLocation))
        precondition(restoredShop.mapCoordinate == shopLocation.mapCoordinate)
        let oldShop = try! JSONDecoder().decode(Shop.self, from: Data(#"{"id":42,"address":"","name":"","active":true}"#.utf8))
        precondition(oldShop.mapCoordinate == nil)
        let notes = parcel(["comment": "  Оставить у двери  ", "add_comment": "оставить   у двери", "comment_client": 4313, "comment_courier_address": "Вход со двора", "comments_address": ["comments": [["comment": " вход   со двора "], ["comment": "Не работает звонок"]]]])
        precondition(notes.buyerComments == ["Оставить у двери"])
        precondition(notes.courierComments == ["Вход со двора", "Не работает звонок"])
        precondition(parcel(["comment_client": 4312]).buyerComments == ["Оставить у двери и позвонить"])
        precondition(parcel(["comment_client": 9999]).buyerComments.isEmpty)
        precondition(parcel(["comment_client": "4311.0"]).buyerComments == ["Доставить лично"])
        print("Parcel address/map/comment fixture checks passed")
    }
}
