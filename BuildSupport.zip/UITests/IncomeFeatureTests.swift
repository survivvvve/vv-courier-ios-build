import XCTest

/// Real native/web integration with the explicit offline account only.
/// No SMS, live API, Bluetooth command or system notification is requested.
final class IncomeFeatureTests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        app = XCUIApplication()
        app.launchArguments = ["--original-ui-testing", "--ui-testing"]
        app.launch()
        XCTAssertTrue(app.webViews.buttons["Профиль"].waitForExistence(timeout: 20))
    }
    override func tearDownWithError() throws { app?.terminate() }

    private func element(_ id: String) -> XCUIElement { app.descendants(matching: .any).matching(identifier: id).firstMatch }
    private func openIncome() {
        app.webViews.buttons["Профиль"].tap()
        let income = app.webViews.buttons["Итоги смены"]
        XCTAssertTrue(income.waitForExistence(timeout: 10))
        XCTAssertTrue(income.isHittable, "Income must be visible at the top of Profile.")
        income.tap()
        XCTAssertTrue(element("income.poster").waitForExistence(timeout: 15))
    }
    private func posterContains(_ text: String) {
        let expectation = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", text), object: element("income.poster"))
        XCTAssertEqual(XCTWaiter.wait(for: [expectation], timeout: 10), .completed)
    }
    private func capture(_ name: String) {
        let image = XCTAttachment(screenshot: app.screenshot())
        image.name = name; image.lifetime = .keepAlways; add(image)
    }

    func testProfilePosterWeightAndPeriodRecalculation() {
        openIncome()
        posterContains("72,323 кг")
        posterContains("Просроки: 2")
        XCTAssertEqual(element("income.poster").frame.height / element("income.poster").frame.width, 630.0 / 1200.0, accuracy: 0.03)
        capture("EarningsTodayAnimePosterDemo")
        for (period, weight, late) in [(3, "216,969 кг", "Просроки: 6"), (5, "361,615 кг", "Просроки: 10"), (7, "506,261 кг", "Просроки: 14")] {
            element("income.period.\(period)").tap()
            posterContains(weight); posterContains(late)
        }
        capture("EarningsWeekRecalculatedDemo")
    }

    func testPosterExportsActualLandscapePNG() {
        openIncome()
        element("income.share").tap()
        // UIKit replaces the host identifier when its remote activity UI loads.
        let share = app.otherElements.matching(NSPredicate(format: "identifier IN %@", ["ActivityListView", "income.share.sheet"])).firstMatch
        XCTAssertTrue(share.waitForExistence(timeout: 15))
        XCTAssertTrue((share.value as? String ?? "").contains("1200×630"))
        let saveImage = app.descendants(matching: .any).matching(NSPredicate(format: "label IN %@", ["Save Image", "Сохранить изображение"])).firstMatch
        XCTAssertTrue(saveImage.waitForExistence(timeout: 20))
        capture("EarningsLandscapePNGShareSheet")
    }

    func testCompanionMenuKeepsIncomeAndWheelSettings() {
        app.webViews.buttons["Профиль"].tap()
        XCTAssertTrue(app.webViews.buttons["Итоги смены"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.webViews.buttons["Бот в Telegram"].exists)
        XCTAssertFalse(app.webViews.buttons["Уведомления об экспрессах"].exists)
        app.webViews.buttons["Колесо"].tap()
        app.buttons["Настройки дополнения"].tap()
        XCTAssertTrue(app.buttons["Итоги смены"].waitForExistence(timeout: 10))
        for title in ["Поправка скорости", "Плитки телеметрии", "Звуковые предупреждения"] {
            XCTAssertTrue(app.buttons[title].exists, "Wheel settings must remain available: \(title)")
        }
        XCTAssertFalse(app.buttons["Бот в Telegram"].exists)
        XCTAssertFalse(app.buttons["Экспрессы на смене"].exists)
        capture("CompanionIncomeAndWheelMenu")
    }

    func testNativeExpressBannerStillOpensFixtureOrder() {
        app.terminate()
        app.launchArguments = ["--original-ui-testing", "--ui-testing", "--original-express-preview"]
        app.launch()
        let open = element("notifications.banner.open")
        XCTAssertTrue(open.waitForExistence(timeout: 15))
        XCTAssertTrue(app.staticTexts["Экспресс готов"].exists)
        capture("ExpressReadyInAppBannerDemo")
        open.tap()
        XCTAssertTrue(app.webViews.staticTexts["Заказ из уведомления"].waitForExistence(timeout: 15))
        XCTAssertFalse(element("notifications.banner").exists)
    }
}
