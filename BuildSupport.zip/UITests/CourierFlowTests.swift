import XCTest
import UIKit

/// Every scenario uses the explicit offline demo account. No SMS, VV mutation,
/// Bluetooth scan, camera access, or command to a physical wheel is performed.
final class CourierFlowTests: XCTestCase {
    private var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        XCUIDevice.shared.orientation = .portrait
        app = XCUIApplication()
        app.launchArguments = ["--demo", "--ui-testing"]
        app.launch()
        XCTAssertTrue(app.tabBars.firstMatch.waitForExistence(timeout: 15))
        XCTAssertTrue(app.tabBars.buttons["Заказы"].waitForExistence(timeout: 15))
    }

    override func tearDownWithError() throws { app?.terminate(); app = nil }

    func testColdControlIncomingWithoutPermanentMenu() {
        app.terminate()
        app.launchArguments = ["--demo", "--ui-testing", "--demo-cold-control"]
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["Заказы"].waitForExistence(timeout: 15))
        XCTAssertTrue(element("coldcontrol.notice").waitForExistence(timeout: 15))
        capture("IncomingColdControl")
        tap(element("coldcontrol.open"))
        XCTAssertTrue(element("coldcontrol.screen").waitForExistence(timeout: 15))
        tap(element("coldcontrol.later"))
        gone(element("coldcontrol.screen"))
        XCTAssertTrue(element("coldcontrol.notice").exists, "Later must not clear the incoming assignment.")
        tap(element("coldcontrol.open"))
        tap(element("coldcontrol.start"))
        tap(scrollTo("coldcontrol.demo-photo"))
        capture("ColdControlPhotoDemo")
        tap(scrollTo("coldcontrol.submit"))
        gone(element("coldcontrol.screen"))
        gone(element("coldcontrol.notice"))
    }

    func testOrdersShopsDetailsAndIncome() {
        selectTab("Заказы")
        XCTAssertTrue(element("shift.toggle").waitForExistence(timeout: 15))
        XCTAssertTrue(element("shops.scope").exists)
        XCTAssertTrue(element("order.buyer-comments.demo-available-0").waitForExistence(timeout: 15))
        XCTAssertFalse(app.staticTexts["Демо: вход со двора."].exists, "Courier address notes belong only in the full order.")
        capture("OrdersLight")

        tap(element("shops.scope"))
        let search = element("shops.search")
        tap(search)
        search.typeText("101\n")
        tap(element("shop.101"))
        gone(search)
        tap(element("shops.scope"))
        tap(element("shops.all"))
        gone(element("shops.all"))

        let picker = element("orders.feed")
        XCTAssertTrue(picker.exists)
        selectFeed("Сборка", picker: picker)
        XCTAssertTrue(element("orders.assembly").waitForExistence(timeout: 15))
        selectFeed("Мои", picker: picker)
        selectFeed("Доступные", picker: picker)
        XCTAssertFalse(app.switches["Только до 5 кг"].exists)
        tap(scrollTo("order.demo-available-0"))
        XCTAssertTrue(element("order.detail").waitForExistence(timeout: 15))
        XCTAssertTrue(element("order.take").exists)
        let cashChange = element("order.cash-change")
        XCTAssertTrue(cashChange.waitForExistence(timeout: 15))
        XCTAssertEqual(cashChange.label.filter(\.isNumber), "250000", "Change must be 5000 minus the 2500 payment amount, never the courier reward.")
        capture("OrderDetailLight")
        let courierComments = scrollTo("order.courier-comments.detail")
        XCTAssertTrue(courierComments.staticTexts["Демо: вход со двора."].exists)
        let buyerComments = element("order.buyer-comments.detail")
        XCTAssertTrue(buyerComments.exists)
        XCTAssertFalse(buyerComments.staticTexts["Демо: вход со двора."].exists)
        capture("OrderComments")
        tap(element("order.close"))
        gone(element("order.detail"))

        selectTab("Доходы")
        XCTAssertTrue(element("income.summary").waitForExistence(timeout: 15))
        tap(app.buttons["Вчера"])
        XCTAssertTrue(element("income.summary").waitForExistence(timeout: 15))
        tap(app.buttons["Сегодня"])
        XCTAssertTrue(element("income.summary").waitForExistence(timeout: 15))
        capture("IncomeLight")
    }

    func testOrderMapAndAssemblyAddress() {
        selectTab("Заказы")
        expectShopCentered("101")
        tap(element("shops.scope"))
        tap(element("shop.202"))
        gone(element("shops.search"))
        expectShopCentered("202")
        tap(element("shops.scope"))
        tap(element("shops.all"))
        gone(element("shops.search"))
        expectShopCentered("101")
        let picker = element("orders.feed")
        selectFeed("Сборка", picker: picker)
        let assemblyOrder = scrollTo("order.demo-assembly-0")
        XCTAssertTrue(assemblyOrder.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "Тестовая улица, 5")).firstMatch.waitForExistence(timeout: 15), "Assembly must retain the street and house from corr_addr, not only flat/floor.")
        let assemblyComments = element("order.buyer-comments.demo-assembly-0")
        XCTAssertTrue(assemblyComments.waitForExistence(timeout: 15))
        XCTAssertTrue(assemblyComments.staticTexts["Демо покупателя: оставьте заказ у двери."].exists)
        XCTAssertFalse(app.staticTexts["Демо: вход со двора."].exists)
        capture("AssemblyAddress")
        XCTAssertTrue(element("orders.map.inline").exists)
        XCTAssertTrue(element("orders.map.canvas").waitForExistence(timeout: 20))
        capture("AssemblyMap")
        selectFeed("Доступные", picker: picker)
        XCTAssertTrue(element("orders.map.canvas").waitForExistence(timeout: 20))
        tap(element("map.order.demo-available-0"))
        let selectedOrder = element("order.demo-available-0")
        XCTAssertTrue(selectedOrder.waitForExistence(timeout: 15))
        XCTAssertEqual(selectedOrder.value as? String, "Выбран на карте")
        element("orders.map.canvas").pinch(withScale: 1.4, velocity: 1)
        XCTAssertTrue(element("orders.map.inline").exists)
        capture("InlineMapSelected")
    }

    func testTerminalDeliveryAndReceiptPhotoDemo() {
        selectTab("Заказы")
        selectFeed("Мои", picker: element("orders.feed"))
        tap(scrollTo("order.demo-mine-0"))
        XCTAssertTrue(element("order.detail").waitForExistence(timeout: 15))
        tap(scrollTo("order.action.deliver"))
        XCTAssertTrue(element("payment.screen").waitForExistence(timeout: 15))
        tap(element("payment.method.terminal"))
        capture("PaymentTerminalDemo")
        tap(element("payment.complete"))
        tap(app.buttons["Подтвердить доставку"])
        XCTAssertTrue(element("receipt.screen").waitForExistence(timeout: 15))
        tap(scrollTo("receipt.demo-photo"))
        capture("ReceiptDraftDemo")
        tap(scrollTo("receipt.save"))
        XCTAssertTrue(element("receipt.saved").waitForExistence(timeout: 15))
        capture("ReceiptSavedDemo")
        tap(scrollTo("receipt.done"))
        gone(element("receipt.screen"))
        gone(element("order.detail"))
        XCTAssertFalse(element("order.demo-mine-0").exists, "Completed demo delivery must leave My orders.")
    }

    func testSeparateQueuesWithSharedStore() {
        selectTab("Очередь")
        chooseQueue("demo-north")
        XCTAssertTrue(element("queue.person.demo-n1").waitForExistence(timeout: 15))
        XCTAssertTrue(element("queue.person.demo-n2").exists)
        XCTAssertFalse(element("queue.person.demo-s1").exists)
        capture("QueueNorth")

        chooseQueue("demo-south")
        XCTAssertTrue(element("queue.person.demo-s1").waitForExistence(timeout: 15))
        XCTAssertFalse(element("queue.person.demo-n1").exists, "Previous queue must be cleared when another queue is selected.")
        XCTAssertFalse(element("queue.person.demo-n2").exists)
        capture("QueueSouth")

        chooseQueue("demo-empty")
        XCTAssertTrue(element("queue.empty").waitForExistence(timeout: 15))
        XCTAssertTrue(element("queue.orders").exists, "An empty queue must still show its own order count.")
        XCTAssertFalse(element("queue.person.demo-s1").exists)
        capture("QueueEmpty")
    }

    func testTerminalAndSchedule() {
        selectTab("Профиль")
        tap(scrollTo("dashboard.terminal"))
        XCTAssertTrue(app.navigationBars["Терминал"].waitForExistence(timeout: 15))
        capture("TerminalLight")
        goBack()
        gone(app.navigationBars["Терминал"])
        tap(scrollTo("profile.schedule"))
        XCTAssertTrue(app.navigationBars["График смен"].waitForExistence(timeout: 15))
        XCTAssertTrue(app.datePickers.firstMatch.waitForExistence(timeout: 15))
        capture("ScheduleLight")
    }

    func testScheduleBookingClockChoicesAndConfirmation() {
        selectTab("Профиль")
        tap(scrollTo("shops.scope"))
        tap(element("shop.101"))
        gone(element("shops.search"))
        tap(scrollTo("profile.schedule"))
        XCTAssertTrue(app.navigationBars["График смен"].waitForExistence(timeout: 15))
        XCTAssertTrue(scrollTo("schedule.start").exists)
        XCTAssertTrue(scrollTo("schedule.end").exists)
        capture("ScheduleBookingChoices")
        tap(scrollTo("schedule.book"))
        tap(app.buttons["Подтвердить запись"])
        let saved = app.staticTexts["Демо: выход добавлен локально. В ВВ ничего не отправлено."]
        XCTAssertTrue(saved.waitForExistence(timeout: 15))
        for _ in 0..<2 { app.swipeDown() }
        XCTAssertTrue(app.staticTexts["08:00 — 21:00"].exists)
        capture("ScheduleBookingConfirmedDemo")
    }

    func testAppearanceAndWheel() {
        selectTab("Профиль")
        for id in ["profile.cash", "profile.rating", "profile.tips", "profile.tax", "profile.news", "profile.instructions"] { XCTAssertFalse(element(id).exists) }
        XCTAssertFalse(app.staticTexts["В кабинете ВВ"].exists)
        XCTAssertFalse(app.staticTexts["Кабинет и поддержка ВВ"].exists)
        tap(scrollTo("profile.appearance"))
        let appearance = scrollTo("appearance.picker")
        tap(appearance.buttons["Тёмное"])
        selected(appearance.buttons["Тёмное"])
        capture("ProfileDark")
        goBack()
        selectTab("Заказы")
        capture("OrdersDark")
        selectTab("Доходы")
        XCTAssertTrue(element("income.summary").waitForExistence(timeout: 15))
        capture("IncomeDark")

        selectTab("Профиль")
        tap(scrollTo("profile.appearance"))
        let theme = scrollTo("appearance.picker")
        tap(theme.buttons["Светлое"])
        selected(theme.buttons["Светлое"])
        capture("ProfileLight")
        goBack()
        selectTab("Колесо")
        XCTAssertTrue(element("wheel.screen").waitForExistence(timeout: 15))
        XCTAssertTrue(element("wheel.speed").waitForExistence(timeout: 15))
        XCTAssertTrue(element("wheel.pwm").exists)
        capture("WheelDemo")
        tap(scrollTo("wheel.settings"))
        XCTAssertTrue(element("wheel.settings.screen").waitForExistence(timeout: 15))
        tap(app.buttons["Педали"])
        XCTAssertTrue(element("wheel.setting.hardness").waitForExistence(timeout: 15))
        capture("WheelSettingsPedals")
        // Close the long pedals section before opening the next group; no
        // settings are written by this navigation-only scenario.
        tap(app.buttons["Педали"])
        tap(app.buttons["Скорость и защита"])
        capture("WheelSettingsSpeed")
    }

    func testLivePaletteUpdatesPreloadedScreens() {
        selectTab("Профиль")
        tap(scrollTo("profile.appearance"))
        tap(element("appearance.picker").buttons["Светлое"])
        tap(scrollTo("appearance.palette.codex"))
        goBack()

        // Warm the actual cached views before changing the palette. A root
        // identity reset would lose this period and the wheel navigation stack.
        selectTab("Доходы")
        tap(element("income.period.1"))
        selected(element("income.period.1"))
        expectColor(element("income.period.1"), hex: 0x0285FF)
        selectTab("Очередь")
        chooseQueue("demo-north")
        selectTab("Колесо")
        tap(scrollTo("wheel.dashboard"))
        XCTAssertTrue(element("wheel.dashboard.settings").waitForExistence(timeout: 15))

        for dark in [false, true] {
            selectTab("Профиль")
            tap(scrollTo("profile.appearance"))
            tap(element("appearance.picker").buttons[dark ? "Тёмное" : "Светлое"])
            tap(scrollTo("appearance.palette.pink"))
            goBack()
            for _ in 0..<3 { app.swipeDown() }
            let accent: UInt32 = dark ? 0xF69EC9 : 0xB43E79
            expectColor(scrollTo("profile.schedule"), hex: accent)
            capture(dark ? "LiveThemeProfileDark" : "LiveThemeProfileLight")

            selectTab("Доходы")
            selected(element("income.period.1"))
            expectColor(element("income.period.1"), hex: accent)
            capture(dark ? "LiveThemeIncomeDark" : "LiveThemeIncomeLight")

            selectTab("Колесо")
            XCTAssertTrue(element("wheel.dashboard.settings").waitForExistence(timeout: 15), "Theme changes must preserve an already open settings screen.")
            let speedRow = app.cells.containing(.staticText, identifier: "wheel.dashboard.metric.speed").firstMatch
            expectColor(speedRow, hex: dark ? 0x2B2A31 : 0xFCF8FA, at: CGPoint(x: 0.55, y: 0.5), tolerance: 3)
            capture(dark ? "LiveThemeWheelListDark" : "LiveThemeWheelListLight")
            goBack()
            expectColor(scrollTo("wheel.dashboard"), hex: accent)
            capture(dark ? "LiveThemeWheelMainDark" : "LiveThemeWheelMainLight")
            tap(scrollTo("wheel.dashboard"))

            selectTab("Очередь")
            XCTAssertTrue(element("queue.person.demo-n1").exists)
            expectColor(element("shops.scope"), hex: accent)
            tap(element("shops.scope"))
            XCTAssertTrue(element("shops.search").waitForExistence(timeout: 15))
            // This toolbar uses the app's primary text style. Check the sheet's
            // actual palette on a clear part of its card, not a system text tint.
            expectColor(element("shops.all"), hex: dark ? 0x2B2A31 : 0xFCF8FA, at: CGPoint(x: 0.5, y: 0.05), tolerance: 3)
            capture(dark ? "LiveThemeShopSheetDark" : "LiveThemeShopSheetLight")
            tap(app.navigationBars.buttons["Готово"])
            gone(element("shops.search"))

            selectTab("Заказы")
            expectColor(element("shift.toggle"), hex: accent)
            capture(dark ? "LiveThemeOrdersDark" : "LiveThemeOrdersLight")
        }

        selectTab("Профиль")
        tap(scrollTo("profile.appearance"))
        tap(element("appearance.picker").buttons["Светлое"])
        tap(scrollTo("appearance.palette.codex"))
        goBack()
        selectTab("Доходы")
        selected(element("income.period.1"))
        expectColor(element("income.period.1"), hex: 0x0285FF)
        capture("LiveThemeRestoredCodex")
    }

    func testBatchScannerAndPerPackageSkip() {
        app.terminate()
        app.launchArguments = ["--demo", "--ui-testing", "--demo-inspection-batch"]
        app.launch()
        XCTAssertTrue(app.tabBars.firstMatch.waitForExistence(timeout: 15))
        selectFeed("Мои", picker: element("orders.feed"))
        tap(scrollTo("departure.scan"))
        XCTAssertTrue(element("inspection.screen").waitForExistence(timeout: 15))
        tap(scrollTo("inspection.scan"))
        let first = element("inspection.demo-scan.DEMO-demo-mine-0-1")
        tap(first); gone(first)
        tap(element("inspection.camera.skip"))
        XCTAssertTrue(element("inspection.skip.screen").waitForExistence(timeout: 15))
        tap(scrollTo("inspection.skip.package.demo-mine-0:DEMO-demo-mine-0-2"))
        tap(scrollTo("inspection.skip.package.demo-mine-1:DEMO-demo-mine-1-1"))
        capture("SkipIndividualPackages")
        tap(scrollTo("inspection.skip.tt"))
        tap(app.buttons["Демо QR ТТ"])
        XCTAssertTrue(element("inspection.skip.screen").waitForExistence(timeout: 15))
        tap(scrollTo("inspection.skip.package.demo-mine-2:DEMO-demo-mine-2-1"))
        // Selection remains per package despite every demo package sharing a cell.
        XCTAssertEqual(element("inspection.skip.package.demo-mine-2:DEMO-demo-mine-2-1").value as? String, "Выбран")
        tap(scrollTo("inspection.skip.done"))
        gone(element("inspection.skip.screen"))
        tap(scrollTo("inspection.scan"))
        for _ in 0..<8 {
            let next = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "inspection.demo-scan.")).firstMatch
            if !next.exists { break }
            let identifier = next.identifier
            tap(next); gone(element(identifier))
        }
        tap(app.buttons["Готово"])
        tap(scrollTo("inspection.finish"))
        gone(element("inspection.screen"))
        tap(scrollTo("departure.start"))
        tap(app.buttons.matching(NSPredicate(format: "label == %@ AND identifier != %@", "Начать доставку", "departure.start")).firstMatch)
        gone(element("departure.start"))
        capture("BatchDepartureComplete")
    }

    func testIncomeMenuAndAuthor() {
        selectTab("Профиль")
        XCTAssertTrue(scrollTo("profile.income").exists)
        XCTAssertFalse(element("profile.notifications").exists)
        XCTAssertFalse(element("profile.telegram").exists)
        XCTAssertTrue(scrollTo("profile.customer-app").exists)
        XCTAssertTrue(scrollTo("profile.author").exists)
        XCTAssertTrue(app.staticTexts["Завайбкожено by"].exists)
        capture("ProfileBrandAndLinks")
    }

    private func chooseQueue(_ identifier: String) {
        tap(scrollTo("queue.selector"))
        let choice = element("queue.choice." + identifier)
        tap(choice)
        gone(choice)
        XCTAssertTrue(element("queue.detail").waitForExistence(timeout: 15))
    }

    private func selectFeed(_ title: String, picker: XCUIElement) {
        let button = picker.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", title)).firstMatch
        tap(button)
        selected(button)
    }

    private func element(_ id: String) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: id).firstMatch
    }

    private func selectTab(_ title: String, file: StaticString = #filePath, line: UInt = #line) {
        let button = app.tabBars.buttons[title]
        tap(button, file: file, line: line)
        selected(button, file: file, line: line)
    }

    private func selected(_ target: XCUIElement, file: StaticString = #filePath, line: UInt = #line) {
        let expectation = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in target.exists && target.isSelected }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [expectation], timeout: 15), .completed, "Selection did not update.", file: file, line: line)
    }

    private func tap(_ target: XCUIElement, file: StaticString = #filePath, line: UInt = #line) {
        let ready = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in target.exists && target.isHittable && target.isEnabled }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [ready], timeout: 15), .completed, "Element did not become tappable: \(target)", file: file, line: line)
        target.tap()
    }

    @discardableResult
    private func scrollTo(_ id: String, file: StaticString = #filePath, line: UInt = #line) -> XCUIElement {
        let target = element(id)
        for _ in 0..<7 {
            if target.exists && target.isHittable { return target }
            app.swipeUp()
        }
        XCTAssertTrue(target.waitForExistence(timeout: 15), "Missing element \(id).", file: file, line: line)
        XCTAssertTrue(target.isHittable, "Element \(id) stayed off screen.", file: file, line: line)
        return target
    }

    private func gone(_ target: XCUIElement, file: StaticString = #filePath, line: UInt = #line) {
        let absent = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in !target.exists }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [absent], timeout: 15), .completed, "Previous screen did not close.", file: file, line: line)
    }

    private func goBack(file: StaticString = #filePath, line: UInt = #line) {
        tap(app.navigationBars.buttons.firstMatch, file: file, line: line)
    }

    private func capture(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    private func expectShopCentered(_ id: String, file: StaticString = #filePath, line: UInt = #line) {
        let map = element("orders.map.canvas"), shop = element("map.shop." + id)
        let centered = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            guard map.exists, shop.exists, shop.isHittable else { return false }
            return abs(shop.frame.midX - map.frame.midX) < 10 && abs(shop.frame.maxY - map.frame.midY) < 10
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [centered], timeout: 15), .completed, "The first map camera must be centered on shop \(id).", file: file, line: line)
    }

    private func expectColor(_ target: XCUIElement, hex: UInt32, at point: CGPoint? = nil, tolerance: Int = 6, file: StaticString = #filePath, line: UInt = #line) {
        let matches = XCTNSPredicateExpectation(predicate: NSPredicate { [self] _, _ in
            target.exists && target.isHittable && screenshotContains(target, hex: hex, point: point, tolerance: tolerance)
        }, object: nil)
        let result = XCTWaiter.wait(for: [matches], timeout: 8)
        if result != .completed { capture("UnexpectedPaletteColor") }
        XCTAssertEqual(result, .completed, "Visible color did not update to \(String(hex, radix: 16)); target exists: \(target.exists).", file: file, line: line)
    }

    private func screenshotContains(_ target: XCUIElement, hex: UInt32, point: CGPoint?, tolerance: Int) -> Bool {
        let appFrame = app.frame, frame = target.frame.intersection(appFrame)
        guard !frame.isEmpty, let image = app.screenshot().image.cgImage,
              let space = CGColorSpace(name: CGColorSpace.sRGB) else { return false }
        let width = image.width, height = image.height
        var pixels = [UInt8](repeating: 0, count: width * height * 4)
        return pixels.withUnsafeMutableBytes { buffer in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8, bytesPerRow: width * 4, space: space, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue) else { return false }
            context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
            let scaleX = Double(width) / appFrame.width, scaleY = Double(height) / appFrame.height
            let region: CGRect
            if let point {
                let x = (frame.minX - appFrame.minX + frame.width * point.x) * scaleX
                let y = (frame.minY - appFrame.minY + frame.height * point.y) * scaleY
                region = CGRect(x: x - 1, y: y - 1, width: 3, height: 3)
            } else {
                region = CGRect(x: (frame.minX - appFrame.minX) * scaleX, y: (frame.minY - appFrame.minY) * scaleY, width: frame.width * scaleX, height: frame.height * scaleY)
            }
            let red = Int((hex >> 16) & 255), green = Int((hex >> 8) & 255), blue = Int(hex & 255)
            let bytes = buffer.bindMemory(to: UInt8.self)
            var count = 0
            let minX = max(0, Int(region.minX)), maxX = min(width, Int(region.maxX))
            let minY = max(0, Int(region.minY)), maxY = min(height, Int(region.maxY))
            guard minX < maxX, minY < maxY else { return false }
            for y in minY..<maxY {
                for x in minX..<maxX {
                    let index = (y * width + x) * 4
                    if abs(Int(bytes[index]) - red) <= tolerance && abs(Int(bytes[index + 1]) - green) <= tolerance && abs(Int(bytes[index + 2]) - blue) <= tolerance { count += 1 }
                    if count >= (point == nil ? 16 : 5) { return true }
                }
            }
            return false
        }
    }
}
