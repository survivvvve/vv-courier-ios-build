import XCTest

/// The offline fixture tests the real WK/native compatibility layer. It is
/// explicitly labelled and is not evidence of a real VV order or live map.
final class OriginalIntegrationTests: XCTestCase {
    private var app: XCUIApplication!
    override func setUpWithError() throws {
        continueAfterFailure = false
        XCUIDevice.shared.orientation = .portrait
        app = XCUIApplication()
    }
    private func launchFixture() {
        app.launchArguments = ["--original-ui-testing", "--ui-testing"]
        app.launch()
        XCTAssertTrue(app.webViews.staticTexts["Тест подключения · без данных ВВ"].waitForExistence(timeout: 20))
        XCTAssertTrue(app.webViews.buttons["Колесо"].waitForExistence(timeout: 15))
    }
    func testSixVisibleTabsAndNativeWheelKeepsWebState() {
        launchFixture()
        let web = app.webViews.firstMatch
        for name in ["Мои", "Доступные", "Сборка", "Очередь", "Профиль", "Колесо"] {
            XCTAssertTrue(web.buttons[name].isHittable, "The six hotbar buttons must fit on iPhone: \(name)")
        }
        web.buttons["Сборка"].tap()
        XCTAssertTrue(web.staticTexts["Сборка"].firstMatch.waitForExistence(timeout: 10))
        capture("OriginalBridgeSixTabsFixture")
        web.buttons["Колесо"].tap()
        let close = app.buttons["original.wheel.close"]
        XCTAssertTrue(close.waitForExistence(timeout: 15))
        capture("OriginalBridgeNativeWheelFixture")
        close.tap()
        XCTAssertTrue(web.staticTexts["Сборка"].firstMatch.waitForExistence(timeout: 10))
        XCTAssertFalse(app.tabBars.buttons["More"].exists)
        web.buttons["Профиль"].tap()
        XCTAssertTrue(web.staticTexts["Профиль"].firstMatch.waitForExistence(timeout: 10))
        XCTAssertTrue(web.buttons["Итоги заработка"].isHittable)
        XCTAssertTrue(web.buttons["Уведомления об экспрессах"].isHittable)
        XCTAssertEqual(app.webViews.matching(identifier: "original.web").count, 1, "Wheel and courier must share one persistent native web surface.")
    }
    func testWheelRemainsAvailableWhenCourierSiteCannotLoad() {
        app.launchArguments = ["--original-ui-testing", "--ui-testing", "--original-offline-ui-testing"]
        app.launch()
        let error = app.descendants(matching: .any).matching(identifier: "original.web.error").firstMatch
        XCTAssertTrue(error.waitForExistence(timeout: 15))
        app.buttons["Колесо"].tap()
        let close = app.buttons["original.wheel.close"]
        XCTAssertTrue(close.waitForExistence(timeout: 15))
        XCTAssertFalse(error.exists, "A network error must not cover the native wheel screen.")
        capture("OriginalBridgeWheelWithoutCourierNetwork")
        close.tap()
        XCTAssertTrue(error.waitForExistence(timeout: 10))
    }
    func testCameraPermissionQueryUsesNativeBridgeOnWebPlatform() {
        launchFixture()
        let web = app.webViews.firstMatch
        web.buttons["Проверить мост камеры"].tap()
        let result = web.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "Камера:")).firstMatch
        XCTAssertTrue(result.waitForExistence(timeout: 10))
        XCTAssertTrue(result.label.contains("platform: web"))
        XCTAssertFalse(result.label.contains("undefined"))
        capture("OriginalBridgeCameraPermissionFixture")
    }
    func testIncomeReportStaysInsideOriginalIncomeSection() {
        launchFixture()
        let web = app.webViews.firstMatch
        web.buttons["Доходы"].tap()
        let summary = web.buttons["Итоги заработка"]
        if !summary.isHittable { web.swipeUp() }
        XCTAssertTrue(summary.waitForExistence(timeout: 10))
        summary.tap()
        let close = app.buttons["original.income.close"]
        XCTAssertTrue(close.waitForExistence(timeout: 15))
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "income.summary").firstMatch.waitForExistence(timeout: 15))
        capture("OriginalBridgeIncomeReportFixture")
        close.tap()
        XCTAssertTrue(web.staticTexts["Доходы"].firstMatch.waitForExistence(timeout: 10))
    }
    func testNotificationReceivedBeforeWebLoadOpensAfterRuntimeReady() {
        app.launchArguments = ["--original-ui-testing", "--ui-testing", "--original-notification-preload"]
        app.launch()
        XCTAssertTrue(app.webViews.staticTexts["Заказ из уведомления"].waitForExistence(timeout: 20))
        capture("OriginalBridgeColdStartNotificationFixture")
    }
    func testOriginalPublicLoginLoadsWithoutRequestingSMS() {
        app.launchArguments = ["--ui-testing", "--original-public-ui-testing"]
        app.launch()
        let login = app.webViews.buttons["Войти"]
        XCTAssertTrue(login.waitForExistence(timeout: 45), "Public original login must load in the actual WKWebView.")
        XCTAssertTrue(app.webViews.buttons["Регистрация"].exists)
        capture("OriginalPublicLoginReadOnly")
    }
    private func capture(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }
}
