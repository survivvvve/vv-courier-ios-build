import XCTest
import UIKit

/// The offline fixture tests the real WK/native compatibility layer. It is
/// explicitly labelled and is not evidence of a real VV order or live map.
final class OriginalIntegrationTests: XCTestCase {
    private var app: XCUIApplication!
    override func setUpWithError() throws {
        continueAfterFailure = false
        XCUIDevice.shared.orientation = .portrait
        app = XCUIApplication()
    }
    private func launchFixture() {
        app.launchArguments = ["--original-ui-testing", "--ui-testing"]
        app.launch()
        XCTAssertTrue(app.webViews.staticTexts["Тест подключения · без данных ВВ"].waitForExistence(timeout: 20))
        XCTAssertTrue(app.webViews.buttons["Колесо"].waitForExistence(timeout: 15))
    }
    func testSixVisibleTabsAndNativeWheelKeepsWebState() {
        launchFixture()
        let web = app.webViews.firstMatch
        for name in ["Мои", "Доступные", "Сборка", "Очередь", "Профиль", "Колесо"] {
            XCTAssertTrue(web.buttons[name].isHittable, "The six hotbar buttons must fit on iPhone: \(name)")
        }
        web.buttons["Сборка"].tap()
        XCTAssertTrue(web.staticTexts["Сборка"].firstMatch.waitForExistence(timeout: 10))
        capture("OriginalBridgeSixTabsFixture")
        web.buttons["Колесо"].tap()
        let close = app.buttons["original.wheel.close"]
        XCTAssertTrue(close.waitForExistence(timeout: 15))
        capture("OriginalBridgeNativeWheelFixture")
        close.tap()
        XCTAssertTrue(web.staticTexts["Сборка"].firstMatch.waitForExistence(timeout: 10))
        XCTAssertFalse(app.tabBars.buttons["More"].exists)
        web.buttons["Профиль"].tap()
        XCTAssertTrue(web.staticTexts["Профиль"].firstMatch.waitForExistence(timeout: 10))
        XCTAssertTrue(web.buttons["Итоги смены"].isHittable)
        XCTAssertFalse(web.buttons["Уведомления об экспрессах"].exists)
        XCTAssertFalse(web.buttons["Бот в Telegram"].exists)
        XCTAssertEqual(app.webViews.matching(identifier: "original.web").count, 1, "Wheel and courier must share one persistent native web surface.")
    }
    func testWheelRemainsAvailableWhenCourierSiteCannotLoad() {
        app.launchArguments = ["--original-ui-testing", "--ui-testing", "--original-offline-ui-testing"]
        app.launch()
        let error = app.descendants(matching: .any).matching(identifier: "original.web.error").firstMatch
        XCTAssertTrue(error.waitForExistence(timeout: 15))
        app.buttons["Колесо"].tap()
        let close = app.buttons["original.wheel.close"]
        XCTAssertTrue(close.waitForExistence(timeout: 15))
        XCTAssertFalse(error.exists, "A network error must not cover the native wheel screen.")
        capture("OriginalBridgeWheelWithoutCourierNetwork")
        close.tap()
        XCTAssertTrue(error.waitForExistence(timeout: 10))
    }
    func testCameraPermissionQueryUsesNativeBridgeOnWebPlatform() {
        launchFixture()
        let web = app.webViews.firstMatch
        web.buttons["Проверить мост камеры"].tap()
        let result = web.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "Камера:")).firstMatch
        XCTAssertTrue(result.waitForExistence(timeout: 10))
        XCTAssertTrue(result.label.contains("platform: web"))
        XCTAssertFalse(result.label.contains("undefined"))
        capture("OriginalBridgeCameraPermissionFixture")
    }
    func testIncomeReportStaysInsideOriginalIncomeSection() {
        launchFixture()
        let web = app.webViews.firstMatch
        web.buttons["Доходы"].tap()
        let summary = web.buttons["Итоги смены"]
        if !summary.isHittable { web.swipeUp() }
        XCTAssertTrue(summary.waitForExistence(timeout: 10))
        summary.tap()
        let close = app.buttons["original.income.close"]
        XCTAssertTrue(close.waitForExistence(timeout: 15))
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "income.summary").firstMatch.waitForExistence(timeout: 15))
        capture("OriginalBridgeIncomeReportFixture")
        close.tap()
        XCTAssertTrue(web.staticTexts["Доходы"].firstMatch.waitForExistence(timeout: 10))
    }
    func testNotificationReceivedBeforeWebLoadOpensAfterRuntimeReady() {
        app.launchArguments = ["--original-ui-testing", "--ui-testing", "--original-notification-preload"]
        app.launch()
        XCTAssertTrue(app.webViews.staticTexts["Заказ из уведомления"].waitForExistence(timeout: 20))
        capture("OriginalBridgeColdStartNotificationFixture")
    }
    func testWebsiteBoundaryKeepsMyOrdersAndWheelAvailable() {
        launchFixture()
        let web = app.webViews.firstMatch
        let probe = web.buttons["Проверить восстановление заказов"]
        if !probe.isHittable { web.swipeUp() }
        XCTAssertTrue(probe.waitForExistence(timeout: 10))
        probe.tap()
        let recovery = app.descendants(matching: .any).matching(identifier: "original.web.runtime-error").firstMatch
        XCTAssertTrue(recovery.waitForExistence(timeout: 15), "The official-style error boundary must not strand the user.")
        XCTAssertTrue(app.buttons["original.recovery.orders"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["original.recovery.orders"].isHittable)
        capture("OriginalWebsiteBoundaryRecovery")
        app.buttons["original.recovery.orders"].tap()
        let close = app.buttons["original.orders-recovery.close"]
        XCTAssertTrue(close.waitForExistence(timeout: 15))
        let orders = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "order.")).firstMatch
        XCTAssertTrue(orders.waitForExistence(timeout: 15), "Already assigned demo orders must remain accessible without the broken web screen.")
        orders.tap()
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "order.detail").firstMatch.waitForExistence(timeout: 15))
        capture("OriginalBoundaryAssignedOrderDetail")
        app.buttons["order.close"].tap()
        XCTAssertTrue(close.waitForExistence(timeout: 10))
        close.tap()
        XCTAssertTrue(recovery.waitForExistence(timeout: 10))
        app.buttons["original.recovery.wheel"].tap()
        let closeWheel = app.buttons["original.wheel.close"]
        XCTAssertTrue(closeWheel.waitForExistence(timeout: 15))
        closeWheel.tap()
        XCTAssertTrue(recovery.waitForExistence(timeout: 10))
        app.buttons["original.recovery.reload"].tap()
        XCTAssertTrue(web.buttons["Колесо"].waitForExistence(timeout: 15))
        XCTAssertFalse(recovery.exists)
        XCTAssertEqual(app.webViews.matching(identifier: "original.web").count, 1)
    }
    func testOriginalPublicLoginLoadsWithoutRequestingSMS() {
        app.launchArguments = ["--ui-testing", "--original-public-ui-testing"]
        app.launch()
        let login = app.webViews.buttons["Войти"]
        // The public module graph is external to the offline integration cases.
        // Keep a strict visibility assertion, with room for a cold CI network.
        let loaded = login.waitForExistence(timeout: 90)
        capture(loaded ? "OriginalPublicLoginReadOnly" : "OriginalPublicLoginLoadingTimeout")
        XCTAssertTrue(loaded, "Public original login must load in the actual WKWebView within 90 seconds.")
        XCTAssertTrue(app.webViews.buttons["Регистрация"].exists)
    }
    func testWebsiteBackgroundFillsBothSafeAreasAndReturnsAfterWheel() {
        app.launchArguments = ["--original-ui-testing", "--ui-testing", "--original-appearance-ui-testing"]
        app.launch()
        let web = app.webViews.matching(identifier: "original.web").firstMatch
        XCTAssertTrue(web.buttons["Чёрный фон"].waitForExistence(timeout: 20))
        assertChrome(web: web, gray: 255)
        web.buttons["Чёрный фон"].tap()
        assertChrome(web: web, gray: 0)
        capture("OriginalBlackPageWithoutGraySafeAreaBars")
        web.buttons["Колесо"].tap()
        let close = app.buttons["original.wheel.close"]
        XCTAssertTrue(close.waitForExistence(timeout: 15))
        capture("NativeWheelAfterBlackWebsite")
        close.tap()
        assertChrome(web: web, gray: 0)
        web.buttons["Белый фон"].tap()
        assertChrome(web: web, gray: 255)
        capture("OriginalWhitePageWithoutGraySafeAreaBars")
    }

    func testFirstShiftTapWaitsForActualCheckBodyAndDoesNotAutoStart() {
        app.launchArguments = ["--original-ui-testing", "--ui-testing", "--original-shift-ui-testing"]
        app.launch()
        let web = app.webViews.firstMatch
        let start = web.buttons["Начать смену"]
        XCTAssertTrue(start.waitForExistence(timeout: 20))
        start.tap()
        let notice = app.alerts["Проверки перед сменой"]
        XCTAssertTrue(notice.waitForExistence(timeout: 10))
        XCTAssertFalse(web.staticTexts["Общая ошибка сайта"].exists)
        notice.buttons["Понятно"].tap()
        web.buttons["Загрузить проверки"].tap()
        XCTAssertTrue(web.staticTexts["Проверки запрашиваются"].waitForExistence(timeout: 10))
        start.tap()
        XCTAssertTrue(notice.waitForExistence(timeout: 10))
        capture("FirstShiftTapWhileChecksLoad")
        notice.buttons["Понятно"].tap()
        web.buttons["Получить проверки"].tap()
        XCTAssertTrue(web.staticTexts["Проверки загружены"].waitForExistence(timeout: 10))
        XCTAssertFalse(web.staticTexts["Подтверждение сайта — без открытия смены"].exists, "Loading checks cannot replay a shift-start click.")
        start.tap()
        XCTAssertTrue(web.staticTexts["Подтверждение сайта — без открытия смены"].waitForExistence(timeout: 10))
        web.buttons["Ответ с ошибкой"].tap()
        start.tap()
        XCTAssertTrue(notice.waitForExistence(timeout: 10))
        XCTAssertTrue(notice.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "429")).firstMatch.exists)
        XCTAssertFalse(notice.buttons["Обновить экран"].exists)
        capture("FirstShiftChecksRejectedWithReadableCode")
        notice.buttons["Скопировать код ошибки"].tap()
        XCTAssertFalse(notice.exists)
    }

    private func assertChrome(web: XCUIElement, gray: UInt8) {
        let ready = XCTNSPredicateExpectation(predicate: NSPredicate { [unowned self] _, _ in
            guard let image = UIImage(data: self.app.screenshot().pngRepresentation)?.cgImage else { return false }
            let frame = web.frame, screen = self.app.frame
            guard frame.minY > 4, frame.maxY + 4 < screen.height else { return false }
            let scale = CGFloat(image.width) / screen.width
            let points = [CGPoint(x: 20, y: frame.minY - 3), CGPoint(x: 20, y: frame.minY + 3), CGPoint(x: 20, y: frame.maxY + 4)]
            return points.allSatisfy { point in
                guard let crop = image.cropping(to: CGRect(x: (point.x * scale).rounded(.down), y: (point.y * scale).rounded(.down), width: 1, height: 1)) else { return false }
                var rgba = [UInt8](repeating: 0, count: 4)
                let drawn = rgba.withUnsafeMutableBytes { bytes -> Bool in
                    guard let context = CGContext(data: bytes.baseAddress, width: 1, height: 1, bitsPerComponent: 8, bytesPerRow: 4,
                        space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGBitmapInfo.byteOrder32Big.rawValue | CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
                    context.draw(crop, in: CGRect(x: 0, y: 0, width: 1, height: 1)); return true
                }
                return drawn && rgba.prefix(3).allSatisfy { abs(Int($0) - Int(gray)) <= 2 }
            }
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [ready], timeout: 10), .completed, "Status/home areas must match the website, including a theme change without reload.")
    }
    private func capture(_ name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }
}
